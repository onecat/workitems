
  SciTE Jump V1.13.36.40

-----------------------------

Website: http://softwarespot.wordpress.com/code/scite-jump/
Language: Multi-language

  Description
-----------------------------
SciTE Jump is a useful addition to SciTE4AutoIt3 as it allows you to quickly navigate between functions and regions in an AutoIt script. This is especially ideal because it allows you to export your code to HTML, PDF or Text and you can also export the list of functions contained in your code.

Use the hotkey F1 to display the in-built help file.

Note: Now officially included in the SciTE4AutoIt3 package.


How to Install
-----------------------------
SciTE Jump can be run 'straight out of the box' but if you wish to integrate into SciTE then right click on the titlebar and select 'Add to SciTE.' This will then allow you to access SciTE Jump by calling the hotkey Ctrl + Alt + J.


  GUI
-----------------------------
The GUI is designed to be simple thus allowing you to create code quickly and efficiently. The inputs at the top are for searching the function list as well as navigating to a specific line within the code. The input in the lower portion of the GUI is for searching a keyword within an AutoIt script, you can change the location to search by selecting the folder icon. This addition is great if you only know a portion of the function you wish to use.

The following HotKeys are supported:
Ctrl + F - Automatically highlight the search input to search the function list. 


  Extended Functionality
-----------------------------
None


  Thanks
-----------------------------
I would like to extend a big thank you to all who took the time to test the application in it's infancy. I would also like to aknowledge Ashalshaikh, Melba23 & wakillon for their individual efforts in creating this application.

This program wouldn't have been possible without the wonderful community on the AutoIt Forums [http://www.autoitscript.com/forum/]


  License
-----------------------------
SciTE Jump is released under GPLv3 (please see License.txt for more details) and all credit should be made towards the original authors where applicable.


  ChangeLog
-----------------------------
Version 1.13.36.40 [07-04-2012]
- ADDED: Automatically convert the INI file if currently not unicode.
- FIXED: Issue where the height of the taskbar was fixed at 30px rather than finding the working area when checking if the GUI was on the screen.
- FIXED: SciTE Jump not loading the correct help file when entering F1.
- IMPROVED: INI file is now encoded as a unicode file if it doesn't exist already.

Version 1.12.35.37 [21-03-2012]
- ADDED: Additional information to the title on whether or not the application is running the x64 version of SciTE Jump.
- ADDED: Cue banners to the search and 'find in files' input boxes.
- FIXED: Clearing the search in functions input when changing files. (Thanks LoWang)
- FIXED: Incorrect CRC32 value being created. (Thanks JFX)
- FIXED: Issue where functions wouldn't be sorted on first run if enabled.
- FIXED: Missing '$' in the export function list for Global variables.
- IMPROVED: Overall memory consumption and CPU usage.
- IMPROVED: Speed of sorting the function list, now uses sort.exe instead.

Version 1.11.32.31 [08-03-2012]
- ADDED: Additional information when creating a function list, these include Local & Global variables as well as include files being used. (Thanks to Xenobiologist & James1337)
- ADDED: CRC32 (by trancexx) hash to the function list for checking the integrity of your scripts.
- ADDED: Dropping an au3 file onto the SciTE Jump UI, will open the file in SciTE.
- ADDED: Export options to the right-click menu.
- ADDED: HelpFile.chm which gives an overview of SciTE Jump.
- ADDED: Option in the right-click menu to retrieve the function so it can be added as a snippet.
- ADDED: Option in the right-click menu to toggle the fold of the function.
- ADDED: Support for parsing 'Functions' used in NSIS scripts and VBScripts.
- FIXED: When searching within files and then searching through the list would hide the treeview if the value was blank.
- IMPROVED: Asking whether or not to upgrade a previously installed SciTE Jump, now it will only ask you once.
- REMOVED: Invalid contextmenu items when using the 'finding in files' option.

Version 1.10.26.29 [01-02-2012]
- ADDED: SciTE Jump help section to the settings menu, which can be accessed by selecting the titlebar icon.
- ADDED: Shortcut F1 to access the SciTE Jump help section.
- FIXED: Automatically updating SciTE Jump if already installed in the SciTE folder.
- FIXED: Issue where the function list was incorrectly being saved to the SciTE Jump folder.
- UPDATED: Reporting functions and regions when there weren't any to report.

Version 1.9.24.26 [31-01-2012]
- ADDED: Creating a function header via the right-click contextmenu.
- ADDED: Refreshing the function list when changing the option of whether or not to sort functions.
- ADDED: Right-click contextmenu with additional options.
- FIXED: Issue which appeared when I fixed removing the previous keyword for 'searching within files'.
- IMPROVED: The speed of sorting functions.
- UPDATED: Exporting of functions by adding regions as well as header information about the AutoIt script. (Thanks to JohnOne)

Version 1.8.21.23 [11-01-2012]
- ADDED: German translation. (Thanks to burnell)
- ADDED: Sorting of functions, this can be selected by selecting the titlebar icon.
- FIXED: Clearing the 'Find in Files' input when selecting 'Refresh'.
- FIXED: Issue where SciTE Jump would wait indefinitely until the SciTE process existed.

Version 1.7.19.21 [23-12-2011]
- UPDATED: Compiled using the latest version of AutoIt V3.3.8.0.

Version 1.6.19.20 [23-11-2011]
- FIXED: Issue with automatically starting SciTE if not currently running on the system. (Thanks to MvGulik)

Version 1.5.19.19 [22-11-2011]
- FIXED: Issue when searching.
- FIXED: Issue with the refresh button.
- REMOVED: Previous addition of additional 'custom' comments.

Version 1.4.20.17 [16-11-2011]
- ADDED: Additional lookup for the comments ;<plusspace> and ;<minusspace>.
- ADDED: Change the working directory of SciTE to the directory of the file currently being edited.
- ADDED: Exporting to Latex.
- ADDED: GUI out of bounds check (Thanks to wraithdu)
- ADDED: List unused functions in the export functions feature.
- ADDED: Restart option to the system menu for restarting SciTE Jump and SciTE. The session will be resumed once SciTE has succesfully loaded.
- ADDED: Right click selection of an item.
- ADDED: Search within the 'finding in files' results to narrow down the search.
- ADDED: Start SciTE if currently not available. (This works if SciTE Jump has been run once when SciTE was open.)
- ADDED: The ability to cancel when finding text inside files.
- FIXED: GUI would be inactive if started with an empty document in SciTE.
- FIXED: Issue with array out of bounds when nothing was found using _FindInFile.
- IMPROVED: Interaction with SciTE.

Version 1.3.9.15 [02-11-2011]
- ADDED: Dropping a folder onto the GUI to add to the combobox for searching within files.
- ADDED: x64 version of SciTE Jump.
- FIXED: Issue with the SciTE Jump not closing if SciTE was closed and the application was minimised.
- FIXED: Issue with images not showing on the buttons in Windows XP. (Thanks to MvGulik)
- IMPROVED: The finding in files feature, now it won't read the file until the find input box is empty or the refresh button is selected.

Version 1.2.7.11 [10-10-2011]
- FIXED: Issue with the treeview appearing out of bounds when the application was minimised.
- IMPROVED: Source code with the issue fixed above.

Version 1.1.7.9 [08-10-2011]
- ADDED: Update feature, so when you download a new version of SciTE Jump and run the application it will detect if SciTE Jump is on the system and update accordingly. (This does not connect to the Internet.)
- FIXED: Issue with functions not being exported correctly.
- IMPROVED: Checking if using the portable or installed version of AutoIt.
- IMPROVED: Source code with UI tweaks and speed enhancements.

Version 1.0.0.2 [12-08-2011]
- ADDED: HotKey Ctrl + F to set focus to the search input.
- ADDED: Multi-language support with on the fly updating.
- ADDED: Re-sizing of the GUI.
- ADDED: Search within files for a chosen keyword, great if you forget the exact name of a function.
- CHANGED: Name from SciTE Hopper to SciTE Jump.
- IMPROVED: Several UI tweaks.
- IMPROVED: Source code with speed enhancements.
- IMPROVED: The speed of reading a file e.g. a 6005 line file can now be read in 0.09 seconds compared to 0.72 seconds.

Version 1.0.0.1 [14-07-2011]
- ADDED: Bold highlighting of the Function TreeView Item.
- FIXED: Error when SciTE Jump was first loaded with a file that didn't include any Functions.
- FIXED: File not being copied to SciTE directory when 'Added to SciTE.'

Version 1.0.0.0 [03-07-2011]
- Initial release.

-----------------------------