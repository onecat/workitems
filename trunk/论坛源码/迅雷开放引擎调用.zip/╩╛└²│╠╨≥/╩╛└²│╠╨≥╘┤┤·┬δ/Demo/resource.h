//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Demo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTPROJECT2_DIALOG         102
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_TEST_BALLOON_TIP            1000
#define IDC_PROGRESS1                   1003
#define IDC_EDIT_URL                    1004
#define IDC_EDIT_FILE_PATH              1005
#define IDC_BUTTON_OPEN_FILE_DIALOG     1006
#define IDC_TEXT_PROGRESS               1007
#define IDC_EDIT_REFER_URL              1008
#define IDC_BUTTON_DOWNLOAD             1009
#define IDC_BUTTON3                     1010
#define IDC_BUTTON_STOP                 1010
#define IDC_BUTTON_PAUSE                1011
#define IDC_BUTTON2                     1012
#define IDC_BUTTON_CONTINUE             1012
#define IDC_TEXT_PROGRESS2              1013
#define IDC_EDIT_FILE_NAME              1014
#define IDC_TD_FILE_NAME                1015
#define IDC_OPEN_TD_FILE                1016
#define IDC_CHECK1                      1017
#define IDC_LOAD_FROM_TD                1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
