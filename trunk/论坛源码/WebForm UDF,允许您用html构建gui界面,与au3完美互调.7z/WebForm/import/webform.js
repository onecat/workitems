/*
Drunk Frame 1.0 , 基于jQuery扩展版

PS : webForm引擎在最下面的部分
*/

(function(){
if(typeof jQuery === "undefined")return alert("本框架需要jQuery支持") ;


var userAgent = navigator.userAgent ,
	location = document.location
	Drunk = jQuery || {} ,
	regFilter = /([\^\$\(\)\[\]\{\}\.\*\+\?\\\|])/g ,
	window.Alert = alert ;

Drunk.plug = Drunk.fn.plug = function(){
	var target = arguments[0] ,
		length = arguments.length ,
		i = 0 ,
		parameter , expland , cover = true ;
	
	if(length > 1){
		expland = true ;
		cover = Drunk.isUsefulObj(target) || $.isFunction(target) ? true : false ;
		if(cover){
			i += 1 ;
		}else{
			target = arguments[1] ;
			i += 2 ;
		}
	}else if(length == 1){
		target = this ;
	}
		
	for( ; i<length ; i++){
		parameter = arguments[i] ;
		for(name in parameter){
			if(typeof target[name] === "undefined"){
				target[name] = parameter[name] ;
			}else if($.isPlainObject(parameter[name])){
				target[name] = Drunk.plug(target[name],parameter[name]) ;
			}else if(cover){
				target[name] = parameter[name] ;
			}
		}
	}
	return target ;
}

Drunk.fn.plug({
	imgSize : function(width,height,flag, pos,callback){
		return Drunk.imgSize(this, width, height, flag, pos, callback) ;
	} ,
	// 判断或设置某元素是否可选中
	contentSelect : function(boolean){
		var me = Drunk($.browser.mozilla && this[0] === document ? document.body : this[0]) ;
		if(Drunk.isUndef(boolean)){
			return $.browser.mozilla ? (me.css("-moz-user-select") === "none" ? false : true) :
				!me[0].onselectstart || me[0].onselectstart()
		}else{
			if($.browser.mozilla)return me.css("-moz-user-select", boolean ? "all" : "none") ;
			me.each(function(index, element){
				element.onselectstart = function(){return boolean ;}
			}) ;
		}
	}
}) ;

Drunk.plug({
	Cache : {} ,
	// 格式化输出时间
	date : function(format , time){
		format = format ? format : "S" ;

		var timenew = time ? new Date(time) : new Date() ,
			stamp = timenew.getTime() ;

		if(0 == stamp || isNaN(stamp))return time ;

		var year = timenew.getFullYear() ,
			month = timenew.getMonth() + 1 ,
			date = timenew.getDate() ,
			hour = timenew.getHours() ,
			minute = timenew.getMinutes() ,
			secound = timenew.getSeconds() ,
			milliSec = timenew.getMilliseconds() ,
			formatDic = {
				y : String(year).substr(2) ,
				m : String(month).fill(2) ,
				d : String(date).fill(2) ,
				h : String(hour ? hour % 12 : 12).fill(2) ,
				i : String(minute).fill(2) ,
				s : String(secound).fill(2) ,
				Y : year ,
				H : String(hour).fill(2) ,
				M : String(milliSec).fill(3) ,
				S : stamp
			} ;

		return format.replace(/([ymdhisYHSM])/g,function($0, $1){return formatDic[$1] ;}) ;
	} ,
	
	// 返回所有相关的客户端尺寸信息
	clientSize : function(){
		var	body = document.body ,
			size = [screen.availWidth ,screen.availHeight ,
				document.documentElement.clientWidth ,document.documentElement.clientHeight ,
				body.offsetWidth, body.offsetHeight ,
				body.scrollWidth, body.scrollHeight
			]

		return {
			screen : {width : size[0], height : size[1]} ,
			window : {width : size[2], height : size[3]} ,
			body : {width : size[4], height : size[5] ,
				sWidth : size[6] < size[2] ? size[2] : size[6] , sHeight : size[7] < size[3] ? size[3] : size[7]
			}
		} ;
	} ,
	
	objParse : function(object){
		try{
			eval("var variable = "+object) ;
		}catch(err){
			var variable = null ;
		}
		return variable ;
	} ,

	isNum : function(object){ return !isNaN(parseFloat(object)) && isFinite(object) ;} ,
	
	isInt : function(object){ return !isNaN(parseInt(object)) && isFinite(object) ;} ,
	
	isStr : function(object){ return typeof object === "string" ;} ,
	
	isObj : function(object){ return typeof object === "object" ;} ,

	isUsefulObj : function(object){ return object && typeof object !== "boolean" && Drunk.isObj(object) ;} ,
	
	isUndef : function(object){ return typeof object === "undefined" ;} ,

	isReg : function(object){ return Object.prototype.toString.call(object) === "[object RegExp]"} ,
	
	isElem : function(object , tag){
		if(!object || !Drunk.isObj(object))return false ;
		return object.nodeType === 1 ? (D.isStr(tag) ? object.tagName.toLowerCase() == tag.toLowerCase() : object.tagName) : false ;
	} ,
	
	imgReady : function(image){return Drunk.ie ? image.readyState == "complete" : image.complete} ,
	
	currentEvent : function(){return window.event || arguments.callee.caller.arguments[0]} ,
	
	eventTarget : function(evt){evt = evt || Drunk.currentEvent() ;return Drunk.ie ? evt.srcElement : evt.target ;} ,
	
	isContain : function(parent, child){
		if (parent.contains)return parent === child || parent.contains(child) ;
		if (parent.compareDocumentPosition)return parent === child || parent.compareDocumentPosition(child) & 16;
	} ,
	
	ie : /MSIE/i.test(userAgent) ,
	
	ie6 : (/MSIE\s*(\d+)|$/i.exec(userAgent)[1] || 8) < 7 || false ,



	imgSize : function(image, width, height, flag, pos, callback){
		if(!(image instanceof jQuery))return imgSize(image, width, height, flag, pos, callback) ;
		image.each(function(i, img){imgSize(img, width, height, flag, pos, callback) ;}) ;
	},
	
	// 反解析对象,返回对象内容的Json形式字符串
	objDump : function(object, maxLevel, level){
		var i = 0, name, value, term, array = [], quot , overflow ;
		if(Drunk.isNum(maxLevel)){
			if(!Drunk.isNum(level))level = 0 ;
			level ++ ;
			overflow = level > maxLevel ;
		}
		
		if($.isArray(object)){
			for(;i<object.length;i++)array[i] = Drunk.objDump(object[i], maxLevel, level) ;
			return "[" + array.join(",") + "]" ;
		}

		if(!D.isUsefulObj(object) || overflow){
			quot = Drunk.isStr(object) ? '"' : "" ;
			return quot + String(object).convert() + quot ;
		}

		for(name in object){
			value = object[name];
			term = '"' + String(name).convert() + '":' ;
			if($.isArray(value) || D.isUsefulObj(value)){
				term += Drunk.objDump(value, maxLevel, level) ;
			}else{
				quot = Drunk.isStr(value) ? '"' : "" ;
				term += quot + String(value).convert() + quot ;
			}
			array[array.length] = term;
		}
		return "{" + array.join(",") + "}";
	} ,
	
	// 搜索数组或对象,无限级深度搜索,返回下标或匹配到的数组,可用正则对比或者直接比较,如果有定义count,则当对象为对象时,附加一个length属性
	objSearch : function(object, value, column, matchall, count){
		var isArray = $.isArray(object) || (Drunk.isUsefulObj(object) ? false : null) ;
		if(isArray === null)return -1 ;
		var	isReg = Drunk.isReg(value) ,
			i , index = 0 , result , length = length || 0 ,
			width = $.isArray(column) ? column.length : 0 ,
			children = $.isArray(matchall) ? matchall.length : 0 ,
			group = matchall ? (isArray || children ? [] : {}) : -1 ,
			recursive = function(object, level, width, index){
				return index < width - 1 && !Drunk.isUndef(object[level[index]]) ? 
					recursive(object[level[index]], level, width, index + 1) : object[level[index]] ;
			}

		for(i in object){
			if(isArray && !Drunk.isInt(i) || width && Drunk.isUndef(result= recursive(object[i],column,width,index)))continue ;
			if(width ? (isReg ? value.test(result) : result == value) : (isReg ? value.test(object[i]) : object[i] == value)){
				if(!matchall)return i ;
				length ++ ;
				if(children){
					group.push(recursive(object[i], matchall, children, index)) ;
				}else{
					isArray ? group.push(object[i]) : group[i] = object[i] ;
				}
			}
		}
		if(!isArray && count)group.length = length ;
		return group ;
	}
}) ;


// 调整图片尺寸
// flag : 缩放方式(0:全图模式,1:平铺模式) , pos : 相对坐标(兼容CSS坐标) , callback : 回调函数
var imgSize = function(image, width, height, flag, pos, callback){
	if(!Drunk.isElem(image, "img") || isNaN(width) || image.adjusted)return false ;

	height = height < 0 ? width : height ;

	var iW = image.offsetWidth ,
		iH = image.offsetHeight ;

	if(!Drunk.imgReady(image) || !iW)return image.onload = function(){imgSize(image, width, height, flag, pos, callback);}
	
	if(flag == 1){
		iH = width * iH / iW ;iW = width ;
		if(height &&　iH < height){iW = height * iW / iH ;iH = height ;}
	}else{
		if(iW > width){iH = width * iH / iW ;iW = width ;}
		if(height && iH > height){iW = height * iW / iH ;iH = height ;}
	} 

	image.style.width = Math.round(iW)+"px" ;
	image.style.height = Math.round(iH)+"px" ;
	image.adjusted = true ;
	
	pos = Drunk.posParse(pos, iW, iH, width, height) ;
	image.style.marginLeft = pos[0] + "px" ;
	image.style.marginTop = pos[1] + "px" ;

	if($.isFunction(callback))callback(image, width, height, flag, iW, iH) ;
}
	
window.D = window.Drunk = Drunk ;





// -------------------------------------------- Prototype扩展部分 -------------------------------------------- \\
String.prototype.Match = function(reg, index){
	var matches , group = [] , i = 0 ;
	matches = this.match(reg) || [] ;
	if(!isNaN(index) && index !== "" && index !== null){
		for( ;i<matches.length;i++)group[i] = new RegExp(reg).exec(matches[i])[index] ;
	}else{
		for( ;i<matches.length;i++)group[i] = new RegExp(reg).exec(matches[i]) ;
	}
	return group ;
}

// 字符串基本扩展
// 填充字符串,常用于数字前面补零
String.prototype.fill = function(length, fill, to){
	fill = fill ? String(fill) : "0" ;
	var less = length - this.length ,
		str = this ,
		i = 0;
	for(;i<less;i++)str = to ? str + fill : fill + str ;
	return str ;
}

// 返回字符串所占字节数
String.prototype.byte = function(ratio){
	ratio = ratio || 3 ;
	var match = this.match(/[^\x00-\xff]/g) ;
	return this.length + (match ? match.length : 0) * (ratio - 1)
}

// 去掉头尾指定字符串
String.prototype.trim = function(place, sign){
	sign = Drunk.isUndef(sign) ? " " : sign ;
	place = new RegExp(place ? (place == 1 ? "^("+sign+")+" : "("+sign+")+$") : "^("+sign+")+|("+sign+")+$") ;
	return this.replace(place, "") ;
}

// Url形式字符串参数读写,兼容PHP可以设置PHP数组形式键,如key[].没有指定val的话则执行url取参,匹配到多个返回数组,单个返回对应值
String.prototype.url = function(key, val, array){
	var keyReg = key.replace(regFilter,"\\$1") , connector , reg , matches ;
	reg = new RegExp("(\\?" + keyReg + "=|&" + keyReg + "=)([^&]*)","gi") ;
	if(Drunk.isUndef(val)){
		matches = this.Match(reg, 2) ;
		return matches.length > 1 ? matches : (matches.length == 1 ? matches[0] : undefined) ;
	}else{
		connector = this.search(/\?/) == -1 ? "?" : "&" ;
		return this.search(reg) == -1 ? (
			this + connector + key + "=" + val
		) : (
			array ? this + connector + key + "=" + val  : this.replace(reg, "$1" + val)
		) ;
	}
};

// 字符串转码{mode:{1:解码,0:编码} , prefix : 转换的前缀形式}
String.prototype.convert = function(mode, prefix){
	prefix = String(prefix || "\\u") ;
	if(mode){
		return unescape(this.replace(new RegExp(prefix,"g"), "%u")) ;
	}else{
		return this.replace(/([\u0255-\uffff])/g, function($0, $1){
			return prefix + $1.charCodeAt().toString(16) ;}
		) ;
	}
}

// 数组扩展
// 移除数组中重复值元素, 如果指定了column参数并且该参数为大于0的正整数, 则尝试从子数组的column列对比移除重复值元素
Array.prototype.unique = function(column){
	var object = {} , index = this.length-1 , name , object2 = {} , clone = this.slice(0) ,
		isChildSearch = (Drunk.isInt(column) && column > -1) || false ;

	if(isChildSearch){
		for( ; index > -1; index--)
			if(Drunk.isUndef(object2[this[index][column]])){object[this[index]] = index ; object2[this[index][column]] = 1 ;} ;
	}else{
		for( ; index > -1; index--)if(Drunk.isUndef(object[this[index]]))object[this[index]] = index;
	}
	this.length = 0;
	for(val in object)this[this.length] = clone[object[val]] ;
	return this ;
}

// 在数组中搜索给定的值,返回其下标或者匹配到的元素
Array.prototype.search = function(value, column, matches){return Drunk.objSearch(this, value, column, matches) ;}

// 扩展alert功能,使其支持多参输出,主用于调试
window.alert = function(){
	var argLen = arguments.length , content = "" , i = 0 ;
	if(!argLen)return Alert("undefined") ;
	for( ;i<argLen;i++)content += (argLen == 1 ? " " : "\n" + i + " : ") + arguments[i] ;
	return Alert(content.substr(1)) ;
}








// 以下为webform引擎

$(function(){
	webFormEvent() ;
	$("iframe").add("frame").load(function(){window.top.importKernel(this.contentWindow);}).each(function(i,e){window.top.importKernel(e.contentWindow);}) ;
}) ;

})() ;

var methodParseReg = /([a-z_]+)\s*(:\s*(([a-z_]+)\((.*?)\)))?(\s*;\s*(?=\w+\s*(:|;|$))|[;\s]*$)/gi ;


/*
*	webFormFire		调用au3函数
*
*	method				au3函数名或者完整调用方法,如WebFormCreate或WebFormCreate('about:blank','标题')
*	parameters			调用的au3函数参数,如"'about:blank','标题'",如果此参数传入false或者不填,则将method参数直接传递au3调用.如果有传入此参数,则会在传递之前做解析.字符串不会变,js变量或者函数,会解析成变量值或者返回结果来传递,您也可以传入au3函数或者变量当参数,须在前面加"$"符号,如au3func($consolewrite('test'),$$webform,$@crlf).只需在最外层参数加.
*	callback			1.0版本中无效,有能力的朋友可以先自己扩展
*	evt					貌似这个东东没什么用,在考虑要不要移除.
*/
var webFormFire = function(method, parameters, callback, evt){
	evt = evt || null ;
	if(parameters !== false && parameters !== undefined)method = method + "("+ webFormParametersParseWithJs(parameters) +")" ;
	window.top.message.push({
		event : evt ,
		method : method 
		// 回调功能暂时搁置,	callback : typeof callback == "function" ? callback : function(){}
	}) ;
}

/*
*	webFormBindEvent	动态创建html元素后绑定webform事件用
*
*	elements		创建的(或需要更新事件的)元素的jquery对象或者js对象
*	events			事件集,语法同直接写入html属性用的语法一样,如"mouseover:consolewrite('mouseover'&@crlf);mouseout:consolewrite('mouseout'&@crlf);"
*/
var webFormBindEvent = function(elements, events){
	var elem , oldEvents ;
	elements = elements && Drunk.isElem(elements) || elements instanceof jQuery ? $(elements) : $(document) ;
	elements.each(function(index, element) {
		elem = $(element) ;
		oldEvents = elem.attr("webform") ;
        if(!oldEvents){
			elem.attr("webform", events) ;
		}else{
			events += ";" + webFormAttrStrMethodRemove(oldEvents, events)[0] ;
			elem.attr("webform", events) ;
		}
		webFormEvent(elements) ;
    });
}

/*
*	webFormEvent		您可以用此函数解除元素所绑定的webform事件
*
*	container		需要解除webform事件的元素的jquery对象或者js对象
*	events			事件集,语法同直接写入html属性用的语法一样,不需要带参数.如"mousedown;mouseup;click"
*/
var webFormEvent = function(container, unbindEvents){
	container = container && Drunk.isElem(container) || container instanceof jQuery ? container : document ;
	var events, elem , doc = $(document) , defaultPos , move , up , oldEvents , unbindParse ;
	
	$(container).find("[webform]").andSelf().each(function(index, element) {
        elem = $(element) ;
		oldEvents = elem.attr("webform") || "" ;
		events = oldEvents.Match(methodParseReg) ;
		if(!events.length)return true ;
		down = function(evt){Drunk(document).contentSelect(false) ;defaultPos = [evt.clientX, evt.clientY] ;doc.on("mousemove", move) ;doc.on("mouseup", up) ;return false ;}
		if(unbindEvents){
			unbindParse = webFormAttrStrMethodRemove(oldEvents, unbindEvents) ;
			elem.attr("webform", unbindParse[0]) ;
			for(var i=0;i<unbindParse[1].length;i++){
				switch(unbindParse[1][i]){
					case "move" :
						elem.unbind("mousedown") ;
					break ;
					default :
						elem.unbind(unbindParse[1][i]) ;
					break ;
				}
			}
		}else{
			for(var i=0;i<events.length;i++){
				switch(events[i][1]){
					case "move" :
						elem.bind("mousedown", down) ;
					break ;
					default :
						elem.bind(events[i][1], {method : events[i][4], parameters : events[i][5]}, function(evt){
							if(!evt.data.method)return ;
							webFormFire(evt.data.method, evt.data.parameters, 0, evt) ;
							return false ;
						}) ;
					break ;
				}
			}
			move = function(evt){if(!window.top.message.length)webFormFire("_WebFormMove("+(evt.clientX - defaultPos[0])+","+(evt.clientY - defaultPos[1])+")", false, 0, evt) ;}
			up = function(){Drunk(document).contentSelect(true);doc.off("mousemove", move);doc.off("mouseup", up)}
		}
    });
}


// 下面的东东你可能用不到,不作解释

var webFormParseParameters = function(parametersStr, callback){
	var currentStr , bracket = {"(" : 0, ")" : 0 , "[" : 0, "]" : 0, "{" : 0, "}" : 0, "'" : 0, "\"" : 0} ,
		parameters = [] , parameter = "" , parametersStrLength = parametersStr.length , i = 0 ;
		
	for(;i<parametersStrLength;i++){
		currentStr = parametersStr.substr(i,1) ;
		if("(){}[]'\"".indexOf(currentStr) != -1)bracket[currentStr] ++ ;
		if((currentStr == "," || (parametersStrLength == i +1 && (parameter += currentStr))) && bracket["("] == bracket[")"] && bracket["["] == bracket["]"] && bracket["{"] == bracket["}"] && !(bracket["'"]%2) && !(bracket["\""]%2)){
			parameters.push(typeof callback == "function" ? callback(parameter) : parameter) ;
			parameter = "" ;
		}else{
			parameter += currentStr ;
		}
	}
	return parameters ;
}

var webFormParametersParseWithJs = function(parametersStr){
	var firstStr , tmpStr ;
	return webFormParseParameters(parametersStr, function(parameter){
		firstStr = parameter.substr(0,1) ;
		if(firstStr == "$" && "(.".indexOf(parameter.substr(1,1)) == -1){
			return parameter.substr(1) ;
		}else if("'\"".indexOf(firstStr) == -1 && !Drunk.isNum(parameter)){
			tmpStr = eval(parameter) ;
			return tmpStr ;
		}else{
			return parameter ;
		}
	}).join() ;
}

var webFormAttrStrMethodRemove = function(attrStrMethod, toRemoveMethod){
	var eventsParse = toRemoveMethod.Match(methodParseReg, 1) ;
	for(var i=0;i<eventsParse.length;i++){attrStrMethod = attrStrMethod.replace(new RegExp(eventsParse[i]+"\\s*(:\\s*.+\\(.*?\\))?(\s*;\\s*(?=\\w+\\s*(:|;|$))|[;\\s]*$)","gi"),"") ;}
	return [attrStrMethod,eventsParse] ;
}