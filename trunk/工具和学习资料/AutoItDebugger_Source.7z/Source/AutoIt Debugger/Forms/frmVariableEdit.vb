Imports System.Windows.Forms

<System.Runtime.InteropServices.ComVisible(False)> Public Class frmVariableEdit

#Region " Variables "

    Friend VariableName As String
    Friend VariableValue As String

#End Region

#Region " Base Class Events "

    Private Sub frmVariableEdit_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblVariable.Text = "Enter a new value for '" & VariableName & "'."
        txtVariableValue.Text = VariableValue
        txtVariableValue.Focus()
        txtVariableValue.SelectAll()
    End Sub

#End Region

#Region " Form Controls Event Handlers "

    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        VariableValue = txtVariableValue.Text
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

#End Region

#Region " Menu Events "

#Region " Main Menu Events "

#End Region

#Region " File Menu Item Events "

#End Region

#Region " Edit Menu Item Events "

#End Region

#Region " Tools Menu Item Events "

#End Region

#Region " Window Menu Item Events "

#End Region

#Region " Help Menu Item Events "

#End Region

#End Region

#Region " Miscellaneous Code "

#End Region

End Class