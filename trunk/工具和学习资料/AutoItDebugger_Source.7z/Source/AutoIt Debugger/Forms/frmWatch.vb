Option Strict On
Option Explicit On

Imports WeifenLuo.WinFormsUI.Docking
Imports Aga.Controls.Tree
Imports Aga.Controls.Tree.NodeControls
Imports System.Windows.Forms
Imports System.Drawing

<System.Runtime.InteropServices.ComVisible(False)> Public Class frmWatch
    Inherits DockContent

    Event ChangeVariable(ByVal VariableName As String, ByVal VariableValue As String)

#Region " Variables "

    Public MyTree As New treeadvtest

#End Region

#Region " Base Class Events "

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        TreeViewAdv1.Model = MyTree
        MyTree.ParentTreeviewAdv = TreeViewAdv1
        'TreeViewAdv1.Model = New SortedTreeModel(MyTree)
        AddHandler NodeTextBox1.DrawText, AddressOf _nodeTextBox_DrawText
        AddHandler NodeTextBox2.DrawText, AddressOf _nodeTextBox_DrawText
    End Sub

    Private Sub _nodeTextBox_DrawText(ByVal sender As Object, ByVal e As DrawEventArgs)
        Dim MyVariable As clsTAdvVariable = TryCast(e.Node.Tag, clsTAdvVariable)
        Dim MyArrayVariable As clsTAdvArrayVariable = TryCast(e.Node.Tag, clsTAdvArrayVariable)
        If Not MyVariable Is Nothing Then
            If MyVariable.ValueChanged Then
                e.TextColor = Color.Red
            Else
                e.TextColor = Color.Black
            End If
        ElseIf Not MyArrayVariable Is Nothing Then
            If MyArrayVariable.ValueChanged Then
                e.TextColor = Color.Red
            Else
                e.TextColor = Color.Black
            End If
        End If
    End Sub

#End Region

#Region " Form Controls Event Handlers "

    Private Sub mnuAddVariable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAddVariable.Click
        Dim NewVariable As String = InputBox("Enter the variable name to watch")

        MyTree.AddVariable(NewVariable, True)
    End Sub

    Private Sub mnuListViewDeleteVariable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuListViewDeleteVariable.Click
        mnuDeleteVariables_Click(Me, New EventArgs)
    End Sub

    Private Sub mnuDeleteVariables_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDeleteVariables.Click

        'Generate list of variables to remove
        Dim NodeNames As New List(Of String)
        For Each MyNode As TreeNodeAdv In TreeViewAdv1.SelectedNodes
            NodeNames.Add(CType(MyNode.Tag, clsTAdvVariable).VariableName)
        Next

        'Delete nodes
        For Each MyString As String In NodeNames
            MyTree.HideVariable(MyString)
        Next

    End Sub

    Private Sub mnuListViewCopyValue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuListViewCopyValue.Click
        Dim sValue As String = ""

        For Each MyNode As TreeNodeAdv In TreeViewAdv1.SelectedNodes
            Dim MyVariable As clsTAdvVariable = TryCast(MyNode.Tag, clsTAdvVariable)
            If Not MyVariable Is Nothing Then
                If sValue = "" Then
                    sValue = CStr(MyVariable.VariableValue)
                Else
                    sValue = sValue & vbNewLine & CStr(MyVariable.VariableValue)
                End If
            End If
        Next

        'Copy data to clipboard
        Clipboard.Clear()
        Clipboard.SetText(sValue, TextDataFormat.Text)

    End Sub

    Private Sub TreeViewAdv1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeViewAdv1.DoubleClick

        Dim sReturnValue As String

        'Make sure only 1 item is selected
        If TreeViewAdv1.SelectedNodes.Count = 1 Then
            'Find the variable in the variable list
            Dim MyVariable As clsTAdvVariable = TryCast(TreeViewAdv1.SelectedNodes(0).Tag, clsTAdvVariable)
            If Not MyVariable Is Nothing Then
                'Show the change variable message box
                Dim fVariableEdit As New frmVariableEdit
                fVariableEdit.VariableName = MyVariable.VariableName
                fVariableEdit.VariableValue = CStr(MyVariable.VariableValue)
                If fVariableEdit.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    sReturnValue = fVariableEdit.VariableValue

                    'Check if the return value is different
                    If sReturnValue <> CStr(MyVariable.VariableValue) Then
                        'Store the new variable
                        MyVariable.VariableValue = sReturnValue

                        'Raise event for the variable change
                        RaiseEvent ChangeVariable(MyVariable.VariableName, sReturnValue)
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub TreeViewAdv1_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TreeViewAdv1.DragDrop
        Dim VariableName As String
        VariableName = CStr(e.Data.GetData(DataFormats.Text, True))
        If VariableName.StartsWith("$") Or VariableName.StartsWith("@") Then
            MyTree.AddVariable(VariableName, True)
        End If
    End Sub

    Private Sub TreeViewAdv1_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TreeViewAdv1.DragEnter
        e.Effect = DragDropEffects.Copy
    End Sub

    Private Sub TreeViewAdv1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TreeViewAdv1.KeyDown
        If e.KeyValue = Keys.Delete Then
            mnuDeleteVariables_Click(Me, New EventArgs)
        End If
    End Sub

#End Region

#Region " Miscellaneous Code "

    Public Sub DeleteAllVariables()
        'Clear the table
        MyTree.Variables.Clear()
    End Sub

    ''' <summary>
    ''' Updates a variables value from the running AutoIt script
    ''' </summary>
    ''' <param name="VariableName"></param>
    ''' <param name="VariableValue"></param>
    ''' <remarks></remarks>
    Public Sub VariableChanged(ByVal VariableName As String, ByVal VariableValue As Object)
        Dim sBaseVariableName As String = ExtractVariableName(VariableName)
        Dim sBaseVariableArrayIndex As String = ExtractArrayIndex(VariableName)
        Dim bArrayVariable As Boolean = VariableName.Contains("[")

        If Not bArrayVariable Then 'Non-array variable
            If MyTree.VariableExists(VariableName) Then
                MyTree.UpdateVariable(VariableName, VariableValue)
                If MyTree.GetVariable(VariableName).Show Then
                    TreeViewAdv1.EnsureVisible(TreeViewAdv1.FindNode(MyTree.GetPath(MyTree.GetVariable(VariableName))))
                End If
            Else
                MyTree.AddVariable(VariableName, False)
                MyTree.UpdateVariable(VariableName, VariableValue)
            End If
        Else 'Array variable
            If MyTree.VariableExists(sBaseVariableName) Then
                If MyTree.ArrayVariableExists(sBaseVariableName, VariableName) Then
                    'Update existing variable
                    Dim MyTAdvVariable As clsTAdvVariable = MyTree.GetVariable(sBaseVariableName)
                    MyTree.UpdateArrayVariable(sBaseVariableName, VariableName, VariableValue)

                    Dim MyTreeNodeAdv As TreeNodeAdv = TreeViewAdv1.FindNode(MyTree.GetPath(MyTree.GetArrayVariable(MyTAdvVariable, VariableName)))
                    If MyTree.GetVariable(sBaseVariableName).Show Then
                        TreeViewAdv1.EnsureVisible(MyTreeNodeAdv)
                    End If
                Else
                    'Not found, add array variable
                    Dim MyTAdvVariable As clsTAdvVariable = MyTree.GetVariable(sBaseVariableName)
                    Dim oNewArrayVariable2 As clsTAdvArrayVariable = MyTree.AddArrayVariable(MyTAdvVariable, VariableName, VariableValue)

                    Dim MyTreeNodeAdv As TreeNodeAdv = TreeViewAdv1.FindNode(MyTree.GetPath(oNewArrayVariable2))
                    If MyTree.GetVariable(sBaseVariableName).Show Then
                        TreeViewAdv1.EnsureVisible(MyTreeNodeAdv)
                    End If
                End If
            Else
                    'Add the variable
                    Dim MyTAdvVariable As clsTAdvVariable
                    MyTAdvVariable = MyTree.AddVariable(sBaseVariableName, False)
                    MyTree.AddArrayVariable(MyTAdvVariable, VariableName, VariableValue)
            End If
        End If

    End Sub

    ''' <summary>
    ''' Populates the Variables list from a comma separated variables list.
    ''' </summary>
    ''' <param name="VariablesString">The string containing the variable names.</param>
    ''' <remarks></remarks>
    Public Sub LoadVariablesFromString(ByVal VariablesString As String)
        If VariablesString <> "" Then
            Dim sNewVariableArray() As String = VariablesString.Split(CChar(","))

            For Each MyString As String In sNewVariableArray
                MyTree.AddVariable(MyString, True)
            Next
        End If
    End Sub

    ''' <summary>
    ''' Returns a comma separated string of the contents of the Variables list
    ''' </summary>
    ''' <returns>A string containing the variable names</returns>
    ''' <remarks></remarks>
    Public Function CreateVariablesString() As String
        Dim sVariables As String = ""

        'For Each MyVariables As clsTAdvVariable In MyTree.Variables
        '    sVariables = sVariables & MyVariables.VariableName & ","
        'Next

        'Write variables in the order on the tree, not in the model
        For Each MyNode As TreeNodeAdv In TreeViewAdv1.AllNodes
            Dim MyVariable As clsTAdvVariable = TryCast(MyNode.Tag, clsTAdvVariable)
            If Not MyVariable Is Nothing Then
                sVariables = sVariables & MyVariable.VariableName & ","
            End If
        Next

        sVariables = sVariables.Trim(CChar(","))

        Return sVariables
    End Function

    ''' <summary>
    ''' Extracts a variable name from a string that may contain an array offset
    ''' </summary>
    ''' <param name="Name">The string to test for a variable name</param>
    ''' <returns>The variable name less the array reference</returns>
    ''' <remarks></remarks>
    Private Function ExtractVariableName(ByVal Name As String) As String
        If Name.Contains("[") Then
            ExtractVariableName = Name.Substring(0, Name.IndexOf("["))
        Else
            ExtractVariableName = Name
        End If
    End Function

    Private Function ExtractArrayIndex(ByVal Name As String) As String
        If Name.Contains("[") Then
            ExtractArrayIndex = Name.Substring(Name.IndexOf("["))
        Else
            ExtractArrayIndex = ""
        End If
    End Function

#End Region

    Public Class treeadvtest
        Implements ITreeModel

        Private oVariables As New List(Of clsTAdvVariable)
        Friend ParentTreeviewAdv As TreeViewAdv

        Public ReadOnly Property Variables() As List(Of clsTAdvVariable)
            Get
                Return oVariables
            End Get
        End Property

        Public Function AddVariable(ByVal Name As String, ByVal Visible As Boolean) As clsTAdvVariable
            If Not VariableExists(Name) Then
                'Just add variable
                Dim MyVariable As clsTAdvVariable = New clsTAdvVariable(Name, "", Visible)
                oVariables.Add(MyVariable)

                If Visible Then
                    OnVariableInserted(MyVariable)
                End If

                Return MyVariable
            Else
                'It does exist, check if it should be visible
                Dim MyVariable As clsTAdvVariable = GetVariable(Name)
                If Visible Then
                    MyVariable.Show = True
                    OnVariableInserted(MyVariable)
                End If

                Return MyVariable
            End If

        End Function

        Public Function AddArrayVariable(ByRef Variable As clsTAdvVariable, ByVal Name As String, ByVal Value As Object) As clsTAdvArrayVariable
            Dim MyArrayVariable As clsTAdvArrayVariable = New clsTAdvArrayVariable
            MyArrayVariable.VariableName = Name
            MyArrayVariable.VariableValue = Value
            MyArrayVariable.ParentItem = Variable

            Variable.VariableValue = ""

            Variable.ArrayVariables.Add(MyArrayVariable)

            If Variable.Show Then
                OnArrayVariableInserted(Variable, MyArrayVariable)
            End If

            Return MyArrayVariable
        End Function

        ''' <summary>
        ''' Removes a Variable by Variable reference
        ''' </summary>
        ''' <param name="Variable"></param>
        ''' <remarks></remarks>
        Public Sub RemoveVariable(ByVal Variable As clsTAdvVariable)
            Dim path As TreePath = GetPath(Variable.ParentItem)

            oVariables.Remove(Variable)

            RaiseEvent NodesRemoved(Me, New TreeModelEventArgs(path, New Object() {Variable}))
        End Sub

        ''' <summary>
        ''' Removes a Variable by name
        ''' </summary>
        ''' <param name="Name"></param>
        ''' <remarks></remarks>
        Public Sub HideVariable(ByVal Name As String)
            Dim item As clsTAdvVariable = GetVariable(Name)
            Dim path As TreePath = GetPath(item.ParentItem)
            item.Show = False

            RaiseEvent NodesRemoved(Me, New TreeModelEventArgs(path, New Object() {item}))

        End Sub

        Public Sub UpdateVariable(ByVal Name As String, ByVal Value As Object)
            Dim item As clsTAdvVariable = GetVariable(Name)
            Dim path As TreePath = GetPath(item.ParentItem)

            If Not item Is Nothing Then
                item.VariableValue = Value

                If item.Show Then
                    RaiseEvent NodesChanged(Me, New TreeModelEventArgs(path, New Object() {item}))
                    ParentTreeviewAdv.AutoSizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
                End If
            End If

        End Sub

        Public Sub UpdateArrayVariable(ByVal VariableName As String, ByVal ArrayVariableName As String, ByVal Value As Object)
            Dim MyVariable As clsTAdvVariable = GetVariable(VariableName)
            Dim MyVariablePath As TreePath = GetPath(MyVariable.ParentItem)
            Dim MyArrayVariable As clsTAdvArrayVariable = GetArrayVariable(MyVariable, ArrayVariableName)
            Dim MyArrayVariablePath As TreePath = GetPath(MyVariable)

            MyArrayVariable.VariableValue = Value

            RaiseEvent NodesChanged(Me, New TreeModelEventArgs(MyArrayVariablePath, New Object() {MyArrayVariable}))
        End Sub

        ''' <summary>
        ''' Returns a variable based on a name
        ''' </summary>
        ''' <param name="Name"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetVariable(ByVal Name As String) As clsTAdvVariable
            GetVariable = Nothing
            For Each MyVariable As clsTAdvVariable In oVariables
                If MyVariable.VariableName = Name Then
                    GetVariable = MyVariable
                    Exit For
                End If
            Next
        End Function

        Public Function VariableExists(ByVal Name As String) As Boolean
            VariableExists = False
            If Not GetVariable(Name) Is Nothing Then VariableExists = True
        End Function

        Public Function ArrayVariableExists(ByVal VariableName As String, ByVal ArrayVariablename As String) As Boolean
            ArrayVariableExists = False
            If VariableExists(VariableName) Then
                If Not GetArrayVariable(GetVariable(VariableName), ArrayVariablename) Is Nothing Then ArrayVariableExists = True
            End If
        End Function

        ''' <summary>
        ''' Returns an array variable based on a name
        ''' </summary>
        ''' <param name="Variable"></param>
        ''' <param name="Name"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetArrayVariable(ByVal Variable As clsTAdvVariable, ByVal Name As String) As clsTAdvArrayVariable
            GetArrayVariable = Nothing
            For Each MyVariable As clsTAdvArrayVariable In Variable.ArrayVariables
                If MyVariable.VariableName = Name Then
                    GetArrayVariable = MyVariable
                    Exit For
                End If
            Next
        End Function

        Public Sub ClearAllChangeStatusFlags()
            'Clear the change status flags
            For Each Variable As clsTAdvVariable In oVariables
                Variable.ValueChanged = False
                For Each ArrayVariable As clsTAdvArrayVariable In Variable.ArrayVariables
                    ArrayVariable.ValueChanged = False
                Next
            Next
        End Sub

        Public Sub Clear()

            'Clear all lines
            oVariables.Clear()

            'Refresh tree
            RaiseEvent StructureChanged(Me, New TreePathEventArgs())

        End Sub

        Public Function GetChildren(ByVal treePath As TreePath) As System.Collections.IEnumerable Implements ITreeModel.GetChildren
            If treePath.IsEmpty() Then
                Dim nodes As New List(Of clsTAdvVariable)

                For Each MyVariable As clsTAdvVariable In oVariables
                    If MyVariable.Show Then
                        nodes.Add(MyVariable)
                    End If
                Next
                nodes.Sort() 'Using the CompareTo function of the class

                'Return all variables
                Return nodes
            Else
                If TypeOf treePath.LastNode Is clsTAdvVariable Then
                    'Dim TraceVariableItems = New List(Of VariableItem)
                    Return CType(treePath.LastNode, clsTAdvVariable).ArrayVariables
                End If
            End If
            Return Nothing
        End Function

        Public Function IsLeaf(ByVal treePath As TreePath) As Boolean Implements ITreeModel.IsLeaf

            If TypeOf treePath.LastNode Is clsTAdvArrayVariable Then
                Return True
            ElseIf TypeOf treePath.LastNode Is clsTAdvVariable Then
                Dim objAsTAdvVariable As clsTAdvVariable = CType(treePath.LastNode, clsTAdvVariable)
                If objAsTAdvVariable.ArrayVariables.Count > 0 Then
                    Return False
                Else
                    Return True
                End If
            End If
        End Function

        Friend Function GetPath(ByVal item As BaseItem) As TreePath
            If item Is Nothing Then
                Return TreePath.Empty
            Else
                Dim MyStack As New Stack
                'While Not TypeOf item Is LineItem
                While Not item Is Nothing
                    MyStack.Push(item)
                    item = item.ParentItem
                End While
                Return New TreePath(MyStack.ToArray())
            End If
        End Function 'GetPath

        Public Event NodesChanged(ByVal sender As Object, ByVal e As TreeModelEventArgs) Implements ITreeModel.NodesChanged

        Public Event NodesInserted(ByVal sender As Object, ByVal e As TreeModelEventArgs) Implements ITreeModel.NodesInserted

        Public Event NodesRemoved(ByVal sender As Object, ByVal e As TreeModelEventArgs) Implements ITreeModel.NodesRemoved

        Public Event StructureChanged(ByVal sender As Object, ByVal e As TreePathEventArgs) Implements ITreeModel.StructureChanged

        Friend Sub OnVariableInserted(ByVal item As clsTAdvVariable)
            Dim path As TreePath = GetPath(item.ParentItem)
            RaiseEvent NodesInserted(Me, New TreeModelEventArgs(path, New Integer() {oVariables.Count + 1}, New Object() {item}))

            For Each MyArrayVariable As clsTAdvArrayVariable In item.ArrayVariables
                OnArrayVariableInserted(item, MyArrayVariable)
            Next

            RaiseEvent StructureChanged(Me, New TreePathEventArgs(path))
            ParentTreeviewAdv.AutoSizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
        End Sub

        Friend Sub OnArrayVariableInserted(ByVal item As clsTAdvVariable, ByVal arrayitem As clsTAdvArrayVariable)
            Dim path As TreePath = GetPath(arrayitem.ParentItem)
            RaiseEvent NodesInserted(Me, New TreeModelEventArgs(path, New Integer() {item.ArrayVariables.Count + 1}, New Object() {arrayitem}))

            RaiseEvent StructureChanged(Me, New TreePathEventArgs(path))
            ParentTreeviewAdv.AutoSizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
        End Sub

    End Class

    Public MustInherit Class BaseItem

        Private _column1 As String = ""
        Private _column2 As String = ""

        Public Property Column1() As String
            Get
                Return _column1
            End Get
            Set(ByVal value As String)
                _column1 = value
            End Set
        End Property

        Public Property Column2() As String
            Get
                Return _column2
            End Get
            Set(ByVal value As String)
                _column2 = value
            End Set
        End Property

        Private _parent As BaseItem

        Public Property ParentItem() As BaseItem
            Get
                Return _parent
            End Get
            Set(ByVal value As BaseItem)
                _parent = value
            End Set
        End Property

    End Class

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Class clsTAdvVariable
        Inherits BaseItem
        Implements IComparable(Of clsTAdvVariable)

        Public sName As String
        Public oValue As Object
        Private bValueChanged As Boolean
        Public Show As Boolean
        Public ArrayVariables As New List(Of clsTAdvArrayVariable)

        Public Sub New()
            bValueChanged = False
            VariableValue = "Not declared"

            bValueChanged = False
        End Sub

        Public Sub New(ByVal Name As String, ByVal Value As Object, ByVal ShowInListview As Boolean)
            bValueChanged = False
            VariableValue = "Not declared"
            VariableName = Name
            Show = ShowInListview

            bValueChanged = False
        End Sub

        Public Property VariableName() As String
            Get
                VariableName = sName
            End Get
            Set(ByVal value As String)
                sName = value
                Column1 = sName
            End Set
        End Property

        Public Property VariableValue() As Object
            Get
                VariableValue = oValue
            End Get
            Set(ByVal value As Object)
                Try
                    'If the data type of the current and new variable are different an exception is thown
                    If CStr(oValue) <> CStr(value) Then
                        oValue = value
                        Column2 = CStr(value)
                        bValueChanged = True
                    Else
                        bValueChanged = False
                    End If
                Catch ex As Exception
                    'Variables are of different types, so use the new one
                    oValue = value
                    Column2 = CStr(value)
                    bValueChanged = True
                End Try
            End Set
        End Property

        Public Property ValueChanged() As Boolean
            Get
                ValueChanged = bValueChanged
            End Get
            Set(ByVal value As Boolean)
                bValueChanged = value
            End Set
        End Property

        ''' <summary>
        ''' Returns if the variable represents an array
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property IsArrayVariable() As Boolean
            Get
                If ArrayVariables.Count = 0 Then
                    Return False
                Else
                    Return True
                End If
            End Get
        End Property

        Public Function CompareTo(ByVal other As clsTAdvVariable) As Integer _
        Implements IComparable(Of clsTAdvVariable).CompareTo

            Return sName.CompareTo(other.VariableName)

        End Function

    End Class

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Class clsTAdvArrayVariable
        Inherits BaseItem

        Public sName As String
        Public oValue As Object
        Private bValueChanged As Boolean

        Public Sub New()
            bValueChanged = False
            VariableValue = "Not declared"

            bValueChanged = False
        End Sub

        Public Sub New(ByVal Name As String)
            bValueChanged = False
            VariableName = Name
            VariableValue = "Not declared"

            bValueChanged = False
        End Sub

        Public Property VariableName() As String
            Get
                VariableName = sName
            End Get
            Set(ByVal value As String)
                sName = value
                Column1 = sName
            End Set
        End Property

        Public Property VariableValue() As Object
            Get
                VariableValue = oValue
            End Get
            Set(ByVal value As Object)
                Try
                    'If the data type of the current and new variable are different an exception is thown
                    If CStr(oValue) <> CStr(value) Then
                        oValue = value
                        Column2 = CStr(value)
                        bValueChanged = True
                    Else
                        bValueChanged = False
                    End If
                Catch ex As Exception
                    'Variables are of different types, so use the new one
                    oValue = value
                    Column2 = CStr(value)
                    bValueChanged = True
                End Try
            End Set
        End Property

        Public Property ValueChanged() As Boolean
            Get
                ValueChanged = bValueChanged
            End Get
            Set(ByVal value As Boolean)
                bValueChanged = value
            End Set
        End Property

    End Class

End Class