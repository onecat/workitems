Imports System.Drawing
Imports Aga.Controls.Tree
Imports WeifenLuo.WinFormsUI.Docking

<System.Runtime.InteropServices.ComVisible(False)> Public Class frmTrace
    Inherits DockContent

    Public Enum LineType
        AfterLine
        BeforeLine
    End Enum

    'Dim tlvCurrentTreeListNode As Windows.Forms.TreeListViewItem
    Public MyTree As New treeadvtest

    Public Class treeadvtest
        Implements ITreeModel

        Dim CodeLineItems = New List(Of LineItem)
        Dim CurrentLineItem As New LineItem

        Public Sub AddLine(ByVal Filename As String, ByVal LineNumber As String, ByVal Code As String, _
            ByVal NewLineType As LineType)

            'Check if this line was already logged as a new line
            Static LastLineItem As LineItem

            If LastLineItem Is Nothing Then
                If NewLineType = LineType.BeforeLine Then
                    'Store the current line
                    LastLineItem = New LineItem(Filename, LineNumber, ">", Code, Nothing, NewLineType)
                ElseIf NewLineType = LineType.AfterLine Then
                    'Add the line
                    CurrentLineItem = New LineItem(Filename, LineNumber, "<", Code, Nothing, NewLineType)
                    CodeLineItems.Add(CurrentLineItem)
                    OnLineInserted(CurrentLineItem)
                    LastLineItem = CurrentLineItem
                End If
            Else
                If NewLineType = LineType.BeforeLine Then
                    'This is the next line
                    If LastLineItem.LineType = LineType.BeforeLine Then
                        'The last line must have finished
                        'Add the last line to the list
                        CodeLineItems.Add(LastLineItem)
                        OnLineInserted(LastLineItem)
                        LastLineItem = New LineItem(Filename, LineNumber, ">", Code, Nothing, NewLineType)
                    ElseIf LastLineItem.LineType = LineType.AfterLine Then
                        'Store the current line
                        LastLineItem = New LineItem(Filename, LineNumber, ">", Code, Nothing, NewLineType)
                    End If
                ElseIf NewLineType = LineType.AfterLine Then
                    'This is the previous line
                    If LastLineItem.LineType = LineType.BeforeLine Then
                        'Check if this is the same line that passed
                        If LastLineItem.Filename = Filename And LastLineItem.LineNumber = LineNumber And _
                            LastLineItem.Code = Code Then
                            'Add the line
                            CurrentLineItem = New LineItem(Filename, LineNumber, ">&<", Code, Nothing, NewLineType)
                            CodeLineItems.Add(CurrentLineItem)
                            OnLineInserted(CurrentLineItem)
                            LastLineItem = CurrentLineItem
                        Else
                            'Add the last line
                            CodeLineItems.Add(LastLineItem)
                            OnLineInserted(LastLineItem)
                            'Add this line 
                            CurrentLineItem = New LineItem(Filename, LineNumber, "<", Code, Nothing, NewLineType)
                            CodeLineItems.Add(CurrentLineItem)
                            OnLineInserted(CurrentLineItem)
                            LastLineItem = CurrentLineItem
                        End If
                    ElseIf LastLineItem.LineType = LineType.AfterLine Then
                        'Add the new line
                        CurrentLineItem = New LineItem(Filename, LineNumber, "<", Code, Nothing, NewLineType)
                        CodeLineItems.Add(CurrentLineItem)
                        OnLineInserted(CurrentLineItem)
                        LastLineItem = CurrentLineItem
                    End If
                End If
            End If
        End Sub

        Public Sub ClearTrace()

            'Clear all lines
            CodeLineItems.Clear()

            'Refresh tree
            RaiseEvent StructureChanged(Me, New TreePathEventArgs())

        End Sub

        Public Sub AddVariable(ByVal VariableName As String, ByVal VariableValue As Object)
            'If Not IsNothing(CurrentLineItem) Then
            Dim VariableNode As New VariableItem(VariableName, VariableValue, CurrentLineItem)
            CurrentLineItem.AddVariable(VariableNode)

            OnVariableInserted(VariableNode)
            'End If
        End Sub

        Public Function GetChildren(ByVal treePath As TreePath) As System.Collections.IEnumerable Implements ITreeModel.GetChildren
            If treePath.IsEmpty() Then
                'For i As Integer = 1 To 5
                '    Dim item As New LineItem("MyFile", i, "This is the text", Nothing)
                '    CodeLineItems.Add(item)
                'Next
                Return CodeLineItems
            Else
                If TypeOf treePath.LastNode Is LineItem Then
                    'Dim TraceVariableItems = New List(Of VariableItem)
                    Return CType(treePath.LastNode, LineItem).GetVariables
                End If
            End If
            Return Nothing
        End Function

        Public Function IsLeaf(ByVal treePath As TreePath) As Boolean Implements ITreeModel.IsLeaf
            If TypeOf treePath.LastNode Is LineItem Then
                Return False
            Else
                Return True
            End If
        End Function

        Private Function GetPath(ByVal item As BaseItem) As TreePath
            If item Is Nothing Then
                Return TreePath.Empty
            Else
                Dim MyStack As New Stack
                'While Not TypeOf item Is LineItem
                While Not item Is Nothing
                    MyStack.Push(item)
                    item = item.ParentItem
                End While
                Return New TreePath(MyStack.ToArray())
            End If
        End Function 'GetPath

        Public Event NodesChanged(ByVal sender As Object, ByVal e As TreeModelEventArgs) Implements ITreeModel.NodesChanged

        Public Event NodesInserted(ByVal sender As Object, ByVal e As TreeModelEventArgs) Implements ITreeModel.NodesInserted

        Public Event NodesRemoved(ByVal sender As Object, ByVal e As TreeModelEventArgs) Implements ITreeModel.NodesRemoved

        Public Event StructureChanged(ByVal sender As Object, ByVal e As TreePathEventArgs) Implements ITreeModel.StructureChanged

        'Friend Sub OnStructureChanged(ByVal item As BaseItem)
        '    Dim path As TreePath = GetPath(item.ParentItem)
        '    RaiseEvent StructureChanged(Me, New TreeModelEventArgs(path, New Object() {item}))
        'End Sub

        Friend Sub OnVariableInserted(ByVal item As VariableItem)
            Dim path As TreePath = GetPath(item.ParentLine)
            RaiseEvent NodesInserted(Me, New TreeModelEventArgs(path, New Integer() {item.ParentLine.GetVariables.Count + 1}, New Object() {item}))
        End Sub

        Friend Sub OnLineInserted(ByVal item As LineItem)
            Dim path As TreePath = GetPath(item.ParentItem)
            RaiseEvent NodesInserted(Me, New TreeModelEventArgs(path, New Integer() {CodeLineItems.Count + 1}, New Object() {item}))
        End Sub

    End Class

    Public MustInherit Class BaseItem

        Private _column1 As String = ""
        Private _column2 As String = ""
        Private _column3 As String = ""
        Private _column4 As String = ""

        Public Property Column1() As String
            Get
                Return _column1
            End Get
            Set(ByVal value As String)
                _column1 = value
            End Set
        End Property

        Public Property Column2() As String
            Get
                Return _column2
            End Get
            Set(ByVal value As String)
                _column2 = value
            End Set
        End Property

        Public Property Column3() As String
            Get
                Return _column3
            End Get
            Set(ByVal value As String)
                _column3 = value
            End Set
        End Property

        Public Property Column4() As String
            Get
                Return _column4
            End Get
            Set(ByVal value As String)
                _column4 = value
            End Set
        End Property

        Private _parent As BaseItem

        Public Property ParentItem() As BaseItem
            Get
                Return _parent
            End Get
            Set(ByVal value As BaseItem)
                _parent = value
            End Set
        End Property
    End Class

    Public Class LineItem
        Inherits BaseItem

        Dim VariableList As New List(Of VariableItem)
        Dim LineItemLineType As LineType

        Public Sub AddVariable(ByVal Name As String, ByVal Value As Object, ByRef Parent As LineItem)
            Dim NewTraceVariable As New VariableItem(Name, Value, Parent)
            VariableList.Add(NewTraceVariable)
        End Sub

        Public Sub AddVariable(ByRef Variable As VariableItem)
            VariableList.Add(Variable)
        End Sub

        Public Function GetVariables() As List(Of VariableItem)
            Return VariableList
        End Function

        Public Sub New(ByVal File As String, ByVal Line As String, ByVal InOut As String, ByVal Code As String, _
            ByVal Parent As BaseItem, ByVal LineType As LineType)

            Column1 = File
            Column2 = InOut
            Column3 = Line
            Column4 = Code
            LineItemLineType = LineType
        End Sub

        Public Property Filename()
            Get
                Return Column1
            End Get
            Set(ByVal value)
                Column1 = value
            End Set
        End Property

        Public Property LineNumber()
            Get
                Return Column3
            End Get
            Set(ByVal value)
                Column3 = value
            End Set
        End Property

        Public Property Code()
            Get
                Return Column4
            End Get
            Set(ByVal value)
                Column4 = value
            End Set
        End Property

        Public Property LineType()
            Get
                Return LineItemLineType
            End Get
            Set(ByVal value)
                LineItemLineType = value
            End Set
        End Property

        Public Sub New()
        End Sub

    End Class 'RootItem

    Public Class VariableItem
        Inherits BaseItem

        Public Sub New(ByVal Name As String, ByVal Value As Object, ByVal Parent As LineItem)
            Column1 = "Variables:"
            Column2 = ""
            Column3 = Name
            Column4 = CStr(Value)
            ParentLine = Parent
        End Sub

        Private _parent As LineItem

        Public Property ParentLine() As LineItem
            Get
                Return _parent
            End Get
            Set(ByVal value As LineItem)
                _parent = value
            End Set
        End Property

    End Class 'SubItem

    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        TreeViewAdv1.Model = MyTree
    End Sub

    Private Sub frmTrace_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        TreeViewAdv1.Dock = Windows.Forms.DockStyle.Fill
    End Sub
End Class