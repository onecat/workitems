Imports System.Windows.Forms
Imports System.Text

<System.Runtime.InteropServices.ComVisible(False)> Public Class frmOptions

#Region " Base Class Events "

    Private Sub frmOptions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ftbAutoItRelease.ShowRelativePath = True
        ftbAutoItBeta.ShowRelativePath = True
        ftbReleaseIncludeFolder.ShowRelativePath = True
        ftbBetaIncludeFolder.ShowRelativePath = True
        ftbSciTEInstallFolder.ShowRelativePath = True

        ftbAutoItRelease.BasePath = System.Windows.Forms.Application.StartupPath
        ftbAutoItBeta.BasePath = System.Windows.Forms.Application.StartupPath
        ftbReleaseIncludeFolder.BasePath = System.Windows.Forms.Application.StartupPath
        ftbBetaIncludeFolder.BasePath = System.Windows.Forms.Application.StartupPath
        ftbSciTEInstallFolder.BasePath = System.Windows.Forms.Application.StartupPath

        'Check paths
        ftbAutoItRelease.CheckPath()
        ftbAutoItBeta.CheckPath()
        ftbReleaseIncludeFolder.CheckPath()
        ftbBetaIncludeFolder.CheckPath()
        ftbSciTEInstallFolder.CheckPath()
    End Sub

#End Region

#Region " Form Controls Event Handlers "

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

#End Region

#Region " Miscellaneous Code "

#End Region

End Class
