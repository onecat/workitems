Imports WeifenLuo.WinFormsUI.Docking
Imports Aga.Controls.Tree

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWatch
    Inherits DockContent

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWatch))
        Me.mnuListView = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuListViewDeleteVariable = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuListViewCopyValue = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.mnuAddVariable = New System.Windows.Forms.ToolStripButton
        Me.mnuDeleteVariables = New System.Windows.Forms.ToolStripButton
        Me.TreeViewAdv1 = New Aga.Controls.Tree.TreeViewAdv
        Me.TreeColumn1 = New Aga.Controls.Tree.TreeColumn
        Me.TreeColumn2 = New Aga.Controls.Tree.TreeColumn
        Me.NodeTextBox1 = New Aga.Controls.Tree.NodeControls.NodeTextBox
        Me.NodeTextBox2 = New Aga.Controls.Tree.NodeControls.NodeTextBox
        Me.mnuListView.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuListView
        '
        Me.mnuListView.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuListViewDeleteVariable, Me.mnuListViewCopyValue})
        Me.mnuListView.Name = "mnuListView"
        Me.mnuListView.Size = New System.Drawing.Size(158, 48)
        '
        'mnuListViewDeleteVariable
        '
        Me.mnuListViewDeleteVariable.Name = "mnuListViewDeleteVariable"
        Me.mnuListViewDeleteVariable.Size = New System.Drawing.Size(157, 22)
        Me.mnuListViewDeleteVariable.Text = "&Delete Variable"
        '
        'mnuListViewCopyValue
        '
        Me.mnuListViewCopyValue.Name = "mnuListViewCopyValue"
        Me.mnuListViewCopyValue.Size = New System.Drawing.Size(157, 22)
        Me.mnuListViewCopyValue.Text = "&Copy Value"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAddVariable, Me.mnuDeleteVariables})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(327, 25)
        Me.ToolStrip1.TabIndex = 7
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'mnuAddVariable
        '
        Me.mnuAddVariable.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.mnuAddVariable.Image = CType(resources.GetObject("mnuAddVariable.Image"), System.Drawing.Image)
        Me.mnuAddVariable.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mnuAddVariable.Name = "mnuAddVariable"
        Me.mnuAddVariable.Size = New System.Drawing.Size(23, 22)
        Me.mnuAddVariable.Text = "Add Variable..."
        '
        'mnuDeleteVariables
        '
        Me.mnuDeleteVariables.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.mnuDeleteVariables.Image = CType(resources.GetObject("mnuDeleteVariables.Image"), System.Drawing.Image)
        Me.mnuDeleteVariables.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mnuDeleteVariables.Name = "mnuDeleteVariables"
        Me.mnuDeleteVariables.Size = New System.Drawing.Size(23, 22)
        Me.mnuDeleteVariables.Text = "Delete Selected Variable(s)"
        '
        'TreeViewAdv1
        '
        Me.TreeViewAdv1.AllowDrop = True
        Me.TreeViewAdv1.BackColor = System.Drawing.SystemColors.Window
        Me.TreeViewAdv1.Columns.Add(Me.TreeColumn1)
        Me.TreeViewAdv1.Columns.Add(Me.TreeColumn2)
        Me.TreeViewAdv1.ContextMenuStrip = Me.mnuListView
        Me.TreeViewAdv1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TreeViewAdv1.DefaultToolTipProvider = Nothing
        Me.TreeViewAdv1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TreeViewAdv1.DragDropMarkColor = System.Drawing.Color.Black
        Me.TreeViewAdv1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeViewAdv1.FullRowSelect = True
        Me.TreeViewAdv1.GridLineStyle = CType((Aga.Controls.Tree.GridLineStyle.Horizontal Or Aga.Controls.Tree.GridLineStyle.Vertical), Aga.Controls.Tree.GridLineStyle)
        Me.TreeViewAdv1.LineColor = System.Drawing.SystemColors.ControlDark
        Me.TreeViewAdv1.Location = New System.Drawing.Point(0, 25)
        Me.TreeViewAdv1.Model = Nothing
        Me.TreeViewAdv1.Name = "TreeViewAdv1"
        Me.TreeViewAdv1.NodeControls.Add(Me.NodeTextBox1)
        Me.TreeViewAdv1.NodeControls.Add(Me.NodeTextBox2)
        Me.TreeViewAdv1.SelectedNode = Nothing
        Me.TreeViewAdv1.SelectionMode = Aga.Controls.Tree.TreeSelectionMode.Multi
        Me.TreeViewAdv1.Size = New System.Drawing.Size(327, 190)
        Me.TreeViewAdv1.TabIndex = 8
        Me.TreeViewAdv1.Text = "TreeViewAdv1"
        Me.TreeViewAdv1.UseColumns = True
        '
        'TreeColumn1
        '
        Me.TreeColumn1.Header = "Variable"
        Me.TreeColumn1.SortOrder = System.Windows.Forms.SortOrder.Ascending
        Me.TreeColumn1.TooltipText = Nothing
        Me.TreeColumn1.Width = 200
        '
        'TreeColumn2
        '
        Me.TreeColumn2.Header = "Value"
        Me.TreeColumn2.SortOrder = System.Windows.Forms.SortOrder.None
        Me.TreeColumn2.TooltipText = Nothing
        Me.TreeColumn2.Width = 100
        '
        'NodeTextBox1
        '
        Me.NodeTextBox1.DataPropertyName = "Column1"
        Me.NodeTextBox1.IncrementalSearchEnabled = True
        Me.NodeTextBox1.LeftMargin = 3
        Me.NodeTextBox1.ParentColumn = Me.TreeColumn1
        '
        'NodeTextBox2
        '
        Me.NodeTextBox2.DataPropertyName = "Column2"
        Me.NodeTextBox2.IncrementalSearchEnabled = True
        Me.NodeTextBox2.LeftMargin = 3
        Me.NodeTextBox2.ParentColumn = Me.TreeColumn2
        '
        'frmWatch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 215)
        Me.Controls.Add(Me.TreeViewAdv1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HideOnClose = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmWatch"
        Me.TabText = "Watch"
        Me.Text = "Watch"
        Me.mnuListView.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents mnuAddVariable As System.Windows.Forms.ToolStripButton
    Friend WithEvents mnuListView As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuListViewDeleteVariable As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDeleteVariables As System.Windows.Forms.ToolStripButton
    Friend WithEvents mnuListViewCopyValue As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreeViewAdv1 As TreeViewAdv
    Friend WithEvents TreeColumn1 As TreeColumn
    Friend WithEvents TreeColumn2 As TreeColumn
    Friend WithEvents NodeTextBox1 As NodeControls.NodeTextBox
    Friend WithEvents NodeTextBox2 As NodeControls.NodeTextBox
End Class
