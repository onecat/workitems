Imports WeifenLuo.WinFormsUI
Imports WeifenLuo.WinFormsUI.Docking

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Dim DockPanelSkin7 As WeifenLuo.WinFormsUI.Docking.DockPanelSkin = New WeifenLuo.WinFormsUI.Docking.DockPanelSkin
        Dim AutoHideStripSkin7 As WeifenLuo.WinFormsUI.Docking.AutoHideStripSkin = New WeifenLuo.WinFormsUI.Docking.AutoHideStripSkin
        Dim DockPanelGradient19 As WeifenLuo.WinFormsUI.Docking.DockPanelGradient = New WeifenLuo.WinFormsUI.Docking.DockPanelGradient
        Dim TabGradient43 As WeifenLuo.WinFormsUI.Docking.TabGradient = New WeifenLuo.WinFormsUI.Docking.TabGradient
        Dim DockPaneStripSkin7 As WeifenLuo.WinFormsUI.Docking.DockPaneStripSkin = New WeifenLuo.WinFormsUI.Docking.DockPaneStripSkin
        Dim DockPaneStripGradient7 As WeifenLuo.WinFormsUI.Docking.DockPaneStripGradient = New WeifenLuo.WinFormsUI.Docking.DockPaneStripGradient
        Dim TabGradient44 As WeifenLuo.WinFormsUI.Docking.TabGradient = New WeifenLuo.WinFormsUI.Docking.TabGradient
        Dim DockPanelGradient20 As WeifenLuo.WinFormsUI.Docking.DockPanelGradient = New WeifenLuo.WinFormsUI.Docking.DockPanelGradient
        Dim TabGradient45 As WeifenLuo.WinFormsUI.Docking.TabGradient = New WeifenLuo.WinFormsUI.Docking.TabGradient
        Dim DockPaneStripToolWindowGradient7 As WeifenLuo.WinFormsUI.Docking.DockPaneStripToolWindowGradient = New WeifenLuo.WinFormsUI.Docking.DockPaneStripToolWindowGradient
        Dim TabGradient46 As WeifenLuo.WinFormsUI.Docking.TabGradient = New WeifenLuo.WinFormsUI.Docking.TabGradient
        Dim TabGradient47 As WeifenLuo.WinFormsUI.Docking.TabGradient = New WeifenLuo.WinFormsUI.Docking.TabGradient
        Dim DockPanelGradient21 As WeifenLuo.WinFormsUI.Docking.DockPanelGradient = New WeifenLuo.WinFormsUI.Docking.DockPanelGradient
        Dim TabGradient48 As WeifenLuo.WinFormsUI.Docking.TabGradient = New WeifenLuo.WinFormsUI.Docking.TabGradient
        Dim TabGradient49 As WeifenLuo.WinFormsUI.Docking.TabGradient = New WeifenLuo.WinFormsUI.Docking.TabGradient
        Me.DockPanel1 = New WeifenLuo.WinFormsUI.Docking.DockPanel
        Me.hlpMain = New System.Windows.Forms.HelpProvider
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.sblCurrentLineNumber = New System.Windows.Forms.ToolStripStatusLabel
        Me.sblAutoItVersion = New System.Windows.Forms.ToolStripStatusLabel
        Me.Ribbon1 = New System.Windows.Forms.Ribbon
        Me.OrmMenuNew = New System.Windows.Forms.RibbonOrbMenuItem
        Me.OrbMenuOpen = New System.Windows.Forms.RibbonOrbMenuItem
        Me.OrbMenuSave = New System.Windows.Forms.RibbonOrbMenuItem
        Me.OrbMenuSaveAll = New System.Windows.Forms.RibbonOrbMenuItem
        Me.OrbMenuReloadDoc = New System.Windows.Forms.RibbonOrbMenuItem
        Me.RibbonSeparator2 = New System.Windows.Forms.RibbonSeparator
        Me.OrbMenuClose = New System.Windows.Forms.RibbonOrbMenuItem
        Me.OrbOptionButtonExit = New System.Windows.Forms.RibbonOrbOptionButton
        Me.OrbOptionButtonOptions = New System.Windows.Forms.RibbonOrbOptionButton
        Me.QATMenuSave = New System.Windows.Forms.RibbonButton
        Me.QATMenuSaveAll = New System.Windows.Forms.RibbonButton
        Me.ribHome = New System.Windows.Forms.RibbonTab
        Me.ribHomeEdit = New System.Windows.Forms.RibbonPanel
        Me.ribHomeEditGoto = New System.Windows.Forms.RibbonButton
        Me.ribHomeEditGroup1 = New System.Windows.Forms.RibbonItemGroup
        Me.ribHomeEditFind = New System.Windows.Forms.RibbonButton
        Me.ribHomeEditReplace = New System.Windows.Forms.RibbonButton
        Me.ribHomeEditGroup2 = New System.Windows.Forms.RibbonItemGroup
        Me.ribHomeEditComment = New System.Windows.Forms.RibbonButton
        Me.ribHomeEditUnComment = New System.Windows.Forms.RibbonButton
        Me.ribHomeView = New System.Windows.Forms.RibbonPanel
        Me.ribHomeViewNavBack = New System.Windows.Forms.RibbonButton
        Me.ribHomeViewNavFwd = New System.Windows.Forms.RibbonButton
        Me.ribHomeViewUserCallTips = New System.Windows.Forms.RibbonButton
        Me.ribHomeDebug = New System.Windows.Forms.RibbonPanel
        Me.ribHomeDebugStart = New System.Windows.Forms.RibbonButton
        Me.ribHomeDebugStop = New System.Windows.Forms.RibbonButton
        Me.ribHomeDebugStepInto = New System.Windows.Forms.RibbonButton
        Me.ribHomeDebugStepOver = New System.Windows.Forms.RibbonButton
        Me.ribHomeTools = New System.Windows.Forms.RibbonPanel
        Me.ribHomeToolsBeta = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsRelease = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsRunScript = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsCompile = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsContextCheck = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsTidySource = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsKoda = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsCompileWithOptions = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsCodeWizard = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsOpenInSciTE = New System.Windows.Forms.RibbonButton
        Me.ribHomeToolsExplore = New System.Windows.Forms.RibbonButton
        Me.RibbonTab1 = New System.Windows.Forms.RibbonTab
        Me.ribWindowWindows = New System.Windows.Forms.RibbonPanel
        Me.ribWindowWatch = New System.Windows.Forms.RibbonButton
        Me.ribWindowWindowTrace = New System.Windows.Forms.RibbonButton
        Me.ribWindowWindowOutput = New System.Windows.Forms.RibbonButton
        Me.ribWindowWindowWeb = New System.Windows.Forms.RibbonButton
        Me.ribWindowVariables = New System.Windows.Forms.RibbonButton
        Me.RibbonButton8 = New System.Windows.Forms.RibbonButton
        Me.ribWindowWindowErrorList = New System.Windows.Forms.RibbonButton
        Me.ribWindowToolChest = New System.Windows.Forms.RibbonButton
        Me.RibbonButton6 = New System.Windows.Forms.RibbonButton
        Me.RibbonButton7 = New System.Windows.Forms.RibbonButton
        Me.ribWindowFunctions = New System.Windows.Forms.RibbonButton
        Me.RibbonButton9 = New System.Windows.Forms.RibbonButton
        Me.RibbonButton10 = New System.Windows.Forms.RibbonButton
        Me.ribWindowIncludes = New System.Windows.Forms.RibbonButton
        Me.ribWindowTidy = New System.Windows.Forms.RibbonButton
        Me.ribWIP = New System.Windows.Forms.RibbonTab
        Me.ribWIPMain = New System.Windows.Forms.RibbonPanel
        Me.RibbonButton2 = New System.Windows.Forms.RibbonButton
        Me.RibbonButton3 = New System.Windows.Forms.RibbonButton
        Me.RibbonButton4 = New System.Windows.Forms.RibbonButton
        Me.RibbonButton5 = New System.Windows.Forms.RibbonButton
        Me.ribHelp = New System.Windows.Forms.RibbonTab
        Me.ribHelpHelp = New System.Windows.Forms.RibbonPanel
        Me.ribHelpContents = New System.Windows.Forms.RibbonButton
        Me.ribHelpIndex = New System.Windows.Forms.RibbonButton
        Me.ribHelpSearch = New System.Windows.Forms.RibbonButton
        Me.RibbonSeparator1 = New System.Windows.Forms.RibbonSeparator
        Me.ribHelpAbout = New System.Windows.Forms.RibbonButton
        Me.ribHelpForum = New System.Windows.Forms.RibbonButton
        Me.ribHelpReport = New System.Windows.Forms.RibbonButton
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.RibbonPanel1 = New System.Windows.Forms.RibbonPanel
        Me.RibbonPanel2 = New System.Windows.Forms.RibbonPanel
        Me.RibbonButton1 = New System.Windows.Forms.RibbonButton
        Me.RibbonSeparator3 = New System.Windows.Forms.RibbonSeparator
        Me.RibbonSeparator4 = New System.Windows.Forms.RibbonSeparator
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DockPanel1
        '
        Me.DockPanel1.AccessibleDescription = Nothing
        Me.DockPanel1.AccessibleName = Nothing
        Me.DockPanel1.ActiveAutoHideContent = Nothing
        Me.DockPanel1.AllowDrop = True
        resources.ApplyResources(Me.DockPanel1, "DockPanel1")
        Me.DockPanel1.BackgroundImage = Nothing
        Me.DockPanel1.DockBackColor = System.Drawing.SystemColors.Control
        Me.DockPanel1.DocumentStyle = WeifenLuo.WinFormsUI.Docking.DocumentStyle.DockingWindow
        Me.hlpMain.SetHelpKeyword(Me.DockPanel1, Nothing)
        Me.hlpMain.SetHelpNavigator(Me.DockPanel1, CType(resources.GetObject("DockPanel1.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.hlpMain.SetHelpString(Me.DockPanel1, Nothing)
        Me.DockPanel1.Name = "DockPanel1"
        Me.hlpMain.SetShowHelp(Me.DockPanel1, CType(resources.GetObject("DockPanel1.ShowHelp"), Boolean))
        DockPanelGradient19.EndColor = System.Drawing.SystemColors.ControlLight
        DockPanelGradient19.StartColor = System.Drawing.SystemColors.ControlLight
        AutoHideStripSkin7.DockStripGradient = DockPanelGradient19
        TabGradient43.EndColor = System.Drawing.SystemColors.Control
        TabGradient43.StartColor = System.Drawing.SystemColors.Control
        TabGradient43.TextColor = System.Drawing.SystemColors.ControlDarkDark
        AutoHideStripSkin7.TabGradient = TabGradient43
        DockPanelSkin7.AutoHideStripSkin = AutoHideStripSkin7
        TabGradient44.EndColor = System.Drawing.SystemColors.ControlLightLight
        TabGradient44.StartColor = System.Drawing.SystemColors.ControlLightLight
        TabGradient44.TextColor = System.Drawing.SystemColors.ControlText
        DockPaneStripGradient7.ActiveTabGradient = TabGradient44
        DockPanelGradient20.EndColor = System.Drawing.SystemColors.Control
        DockPanelGradient20.StartColor = System.Drawing.SystemColors.Control
        DockPaneStripGradient7.DockStripGradient = DockPanelGradient20
        TabGradient45.EndColor = System.Drawing.SystemColors.ControlLight
        TabGradient45.StartColor = System.Drawing.SystemColors.ControlLight
        TabGradient45.TextColor = System.Drawing.SystemColors.ControlText
        DockPaneStripGradient7.InactiveTabGradient = TabGradient45
        DockPaneStripSkin7.DocumentGradient = DockPaneStripGradient7
        TabGradient46.EndColor = System.Drawing.SystemColors.ActiveCaption
        TabGradient46.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        TabGradient46.StartColor = System.Drawing.SystemColors.GradientActiveCaption
        TabGradient46.TextColor = System.Drawing.SystemColors.ActiveCaptionText
        DockPaneStripToolWindowGradient7.ActiveCaptionGradient = TabGradient46
        TabGradient47.EndColor = System.Drawing.SystemColors.Control
        TabGradient47.StartColor = System.Drawing.SystemColors.Control
        TabGradient47.TextColor = System.Drawing.SystemColors.ControlText
        DockPaneStripToolWindowGradient7.ActiveTabGradient = TabGradient47
        DockPanelGradient21.EndColor = System.Drawing.SystemColors.ControlLight
        DockPanelGradient21.StartColor = System.Drawing.SystemColors.ControlLight
        DockPaneStripToolWindowGradient7.DockStripGradient = DockPanelGradient21
        TabGradient48.EndColor = System.Drawing.SystemColors.GradientInactiveCaption
        TabGradient48.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical
        TabGradient48.StartColor = System.Drawing.SystemColors.GradientInactiveCaption
        TabGradient48.TextColor = System.Drawing.SystemColors.ControlText
        DockPaneStripToolWindowGradient7.InactiveCaptionGradient = TabGradient48
        TabGradient49.EndColor = System.Drawing.Color.Transparent
        TabGradient49.StartColor = System.Drawing.Color.Transparent
        TabGradient49.TextColor = System.Drawing.SystemColors.ControlDarkDark
        DockPaneStripToolWindowGradient7.InactiveTabGradient = TabGradient49
        DockPaneStripSkin7.ToolWindowGradient = DockPaneStripToolWindowGradient7
        DockPanelSkin7.DockPaneStripSkin = DockPaneStripSkin7
        Me.DockPanel1.Skin = DockPanelSkin7
        '
        'hlpMain
        '
        resources.ApplyResources(Me.hlpMain, "hlpMain")
        '
        'StatusStrip1
        '
        Me.StatusStrip1.AccessibleDescription = Nothing
        Me.StatusStrip1.AccessibleName = Nothing
        resources.ApplyResources(Me.StatusStrip1, "StatusStrip1")
        Me.StatusStrip1.BackgroundImage = Nothing
        Me.StatusStrip1.Font = Nothing
        Me.hlpMain.SetHelpKeyword(Me.StatusStrip1, Nothing)
        Me.hlpMain.SetHelpNavigator(Me.StatusStrip1, CType(resources.GetObject("StatusStrip1.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.hlpMain.SetHelpString(Me.StatusStrip1, Nothing)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.sblCurrentLineNumber, Me.sblAutoItVersion})
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.hlpMain.SetShowHelp(Me.StatusStrip1, CType(resources.GetObject("StatusStrip1.ShowHelp"), Boolean))
        '
        'sblCurrentLineNumber
        '
        Me.sblCurrentLineNumber.AccessibleDescription = Nothing
        Me.sblCurrentLineNumber.AccessibleName = Nothing
        resources.ApplyResources(Me.sblCurrentLineNumber, "sblCurrentLineNumber")
        Me.sblCurrentLineNumber.BackgroundImage = Nothing
        Me.sblCurrentLineNumber.Name = "sblCurrentLineNumber"
        Me.sblCurrentLineNumber.Spring = True
        '
        'sblAutoItVersion
        '
        Me.sblAutoItVersion.AccessibleDescription = Nothing
        Me.sblAutoItVersion.AccessibleName = Nothing
        resources.ApplyResources(Me.sblAutoItVersion, "sblAutoItVersion")
        Me.sblAutoItVersion.BackgroundImage = Nothing
        Me.sblAutoItVersion.Name = "sblAutoItVersion"
        '
        'Ribbon1
        '
        Me.Ribbon1.AccessibleDescription = Nothing
        Me.Ribbon1.AccessibleName = Nothing
        resources.ApplyResources(Me.Ribbon1, "Ribbon1")
        Me.Ribbon1.BackgroundImage = Nothing
        Me.hlpMain.SetHelpKeyword(Me.Ribbon1, Nothing)
        Me.hlpMain.SetHelpNavigator(Me.Ribbon1, CType(resources.GetObject("Ribbon1.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.hlpMain.SetHelpString(Me.Ribbon1, Nothing)
        Me.Ribbon1.Minimized = False
        Me.Ribbon1.Name = "Ribbon1"
        '
        '
        '
        Me.Ribbon1.OrbDropDown.AccessibleDescription = Nothing
        Me.Ribbon1.OrbDropDown.AccessibleName = Nothing
        Me.Ribbon1.OrbDropDown.Anchor = CType(resources.GetObject("Ribbon1.OrbDropDown.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.Ribbon1.OrbDropDown.BackgroundImage = Nothing
        Me.Ribbon1.OrbDropDown.BackgroundImageLayout = CType(resources.GetObject("Ribbon1.OrbDropDown.BackgroundImageLayout"), System.Windows.Forms.ImageLayout)
        Me.Ribbon1.OrbDropDown.BorderRoundness = 8
        Me.Ribbon1.OrbDropDown.Dock = CType(resources.GetObject("Ribbon1.OrbDropDown.Dock"), System.Windows.Forms.DockStyle)
        Me.Ribbon1.OrbDropDown.Font = Nothing
        Me.Ribbon1.OrbDropDown.ImeMode = CType(resources.GetObject("Ribbon1.OrbDropDown.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Ribbon1.OrbDropDown.Location = CType(resources.GetObject("Ribbon1.OrbDropDown.Location"), System.Drawing.Point)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.OrmMenuNew)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.OrbMenuOpen)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.OrbMenuSave)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.OrbMenuSaveAll)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.OrbMenuReloadDoc)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonSeparator2)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.OrbMenuClose)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonSeparator3)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonSeparator4)
        Me.Ribbon1.OrbDropDown.Name = ""
        Me.Ribbon1.OrbDropDown.OptionItems.Add(Me.OrbOptionButtonExit)
        Me.Ribbon1.OrbDropDown.OptionItems.Add(Me.OrbOptionButtonOptions)
        Me.Ribbon1.OrbDropDown.RightToLeft = CType(resources.GetObject("Ribbon1.OrbDropDown.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.Ribbon1.OrbDropDown.Size = CType(resources.GetObject("Ribbon1.OrbDropDown.Size"), System.Drawing.Size)
        Me.Ribbon1.OrbDropDown.TabIndex = CType(resources.GetObject("Ribbon1.OrbDropDown.TabIndex"), Integer)
        Me.Ribbon1.OrbImage = Nothing
        '
        '
        '
        Me.Ribbon1.QuickAcessToolbar.AltKey = Nothing
        Me.Ribbon1.QuickAcessToolbar.Image = Nothing
        Me.Ribbon1.QuickAcessToolbar.Items.Add(Me.QATMenuSave)
        Me.Ribbon1.QuickAcessToolbar.Items.Add(Me.QATMenuSaveAll)
        Me.Ribbon1.QuickAcessToolbar.Tag = Nothing
        Me.Ribbon1.QuickAcessToolbar.Text = Nothing
        Me.Ribbon1.QuickAcessToolbar.ToolTip = Nothing
        Me.Ribbon1.QuickAcessToolbar.ToolTipImage = Nothing
        Me.Ribbon1.QuickAcessToolbar.ToolTipTitle = Nothing
        Me.hlpMain.SetShowHelp(Me.Ribbon1, CType(resources.GetObject("Ribbon1.ShowHelp"), Boolean))
        Me.Ribbon1.Tabs.Add(Me.ribHome)
        Me.Ribbon1.Tabs.Add(Me.RibbonTab1)
        Me.Ribbon1.Tabs.Add(Me.ribWIP)
        Me.Ribbon1.Tabs.Add(Me.ribHelp)
        Me.Ribbon1.TabSpacing = 6
        '
        'OrmMenuNew
        '
        Me.OrmMenuNew.AltKey = Nothing
        Me.OrmMenuNew.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.OrmMenuNew.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrmMenuNew.Image = CType(resources.GetObject("OrmMenuNew.Image"), System.Drawing.Image)
        Me.OrmMenuNew.SmallImage = CType(resources.GetObject("OrmMenuNew.SmallImage"), System.Drawing.Image)
        Me.OrmMenuNew.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrmMenuNew.Tag = Nothing
        resources.ApplyResources(Me.OrmMenuNew, "OrmMenuNew")
        Me.OrmMenuNew.ToolTip = Nothing
        Me.OrmMenuNew.ToolTipImage = Nothing
        Me.OrmMenuNew.ToolTipTitle = Nothing
        '
        'OrbMenuOpen
        '
        Me.OrbMenuOpen.AltKey = Nothing
        Me.OrbMenuOpen.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.OrbMenuOpen.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrbMenuOpen.Image = CType(resources.GetObject("OrbMenuOpen.Image"), System.Drawing.Image)
        Me.OrbMenuOpen.SmallImage = CType(resources.GetObject("OrbMenuOpen.SmallImage"), System.Drawing.Image)
        Me.OrbMenuOpen.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrbMenuOpen.Tag = Nothing
        resources.ApplyResources(Me.OrbMenuOpen, "OrbMenuOpen")
        Me.OrbMenuOpen.ToolTip = Nothing
        Me.OrbMenuOpen.ToolTipImage = Nothing
        Me.OrbMenuOpen.ToolTipTitle = Nothing
        '
        'OrbMenuSave
        '
        Me.OrbMenuSave.AltKey = Nothing
        Me.OrbMenuSave.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.OrbMenuSave.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrbMenuSave.Enabled = False
        Me.OrbMenuSave.Image = CType(resources.GetObject("OrbMenuSave.Image"), System.Drawing.Image)
        Me.OrbMenuSave.SmallImage = CType(resources.GetObject("OrbMenuSave.SmallImage"), System.Drawing.Image)
        Me.OrbMenuSave.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrbMenuSave.Tag = Nothing
        resources.ApplyResources(Me.OrbMenuSave, "OrbMenuSave")
        Me.OrbMenuSave.ToolTip = Nothing
        Me.OrbMenuSave.ToolTipImage = Nothing
        Me.OrbMenuSave.ToolTipTitle = Nothing
        '
        'OrbMenuSaveAll
        '
        Me.OrbMenuSaveAll.AltKey = Nothing
        Me.OrbMenuSaveAll.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.OrbMenuSaveAll.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrbMenuSaveAll.Enabled = False
        Me.OrbMenuSaveAll.Image = CType(resources.GetObject("OrbMenuSaveAll.Image"), System.Drawing.Image)
        Me.OrbMenuSaveAll.SmallImage = CType(resources.GetObject("OrbMenuSaveAll.SmallImage"), System.Drawing.Image)
        Me.OrbMenuSaveAll.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrbMenuSaveAll.Tag = Nothing
        resources.ApplyResources(Me.OrbMenuSaveAll, "OrbMenuSaveAll")
        Me.OrbMenuSaveAll.ToolTip = Nothing
        Me.OrbMenuSaveAll.ToolTipImage = Nothing
        Me.OrbMenuSaveAll.ToolTipTitle = Nothing
        '
        'OrbMenuReloadDoc
        '
        Me.OrbMenuReloadDoc.AltKey = Nothing
        Me.OrbMenuReloadDoc.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.OrbMenuReloadDoc.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrbMenuReloadDoc.Enabled = False
        Me.OrbMenuReloadDoc.Image = CType(resources.GetObject("OrbMenuReloadDoc.Image"), System.Drawing.Image)
        Me.OrbMenuReloadDoc.SmallImage = CType(resources.GetObject("OrbMenuReloadDoc.SmallImage"), System.Drawing.Image)
        Me.OrbMenuReloadDoc.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrbMenuReloadDoc.Tag = Nothing
        resources.ApplyResources(Me.OrbMenuReloadDoc, "OrbMenuReloadDoc")
        Me.OrbMenuReloadDoc.ToolTip = Nothing
        Me.OrbMenuReloadDoc.ToolTipImage = Nothing
        Me.OrbMenuReloadDoc.ToolTipTitle = Nothing
        '
        'RibbonSeparator2
        '
        Me.RibbonSeparator2.AltKey = Nothing
        Me.RibbonSeparator2.Image = Nothing
        Me.RibbonSeparator2.Tag = Nothing
        Me.RibbonSeparator2.Text = Nothing
        Me.RibbonSeparator2.ToolTip = Nothing
        Me.RibbonSeparator2.ToolTipImage = Nothing
        Me.RibbonSeparator2.ToolTipTitle = Nothing
        '
        'OrbMenuClose
        '
        Me.OrbMenuClose.AltKey = Nothing
        Me.OrbMenuClose.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.OrbMenuClose.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrbMenuClose.Enabled = False
        Me.OrbMenuClose.Image = CType(resources.GetObject("OrbMenuClose.Image"), System.Drawing.Image)
        Me.OrbMenuClose.SmallImage = CType(resources.GetObject("OrbMenuClose.SmallImage"), System.Drawing.Image)
        Me.OrbMenuClose.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrbMenuClose.Tag = Nothing
        resources.ApplyResources(Me.OrbMenuClose, "OrbMenuClose")
        Me.OrbMenuClose.ToolTip = Nothing
        Me.OrbMenuClose.ToolTipImage = Nothing
        Me.OrbMenuClose.ToolTipTitle = Nothing
        '
        'OrbOptionButtonExit
        '
        Me.OrbOptionButtonExit.AltKey = Nothing
        Me.OrbOptionButtonExit.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.OrbOptionButtonExit.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrbOptionButtonExit.Image = CType(resources.GetObject("OrbOptionButtonExit.Image"), System.Drawing.Image)
        Me.OrbOptionButtonExit.SmallImage = CType(resources.GetObject("OrbOptionButtonExit.SmallImage"), System.Drawing.Image)
        Me.OrbOptionButtonExit.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrbOptionButtonExit.Tag = Nothing
        resources.ApplyResources(Me.OrbOptionButtonExit, "OrbOptionButtonExit")
        Me.OrbOptionButtonExit.ToolTip = Nothing
        Me.OrbOptionButtonExit.ToolTipImage = Nothing
        Me.OrbOptionButtonExit.ToolTipTitle = Nothing
        '
        'OrbOptionButtonOptions
        '
        Me.OrbOptionButtonOptions.AltKey = Nothing
        Me.OrbOptionButtonOptions.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.OrbOptionButtonOptions.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.OrbOptionButtonOptions.Image = CType(resources.GetObject("OrbOptionButtonOptions.Image"), System.Drawing.Image)
        Me.OrbOptionButtonOptions.SmallImage = CType(resources.GetObject("OrbOptionButtonOptions.SmallImage"), System.Drawing.Image)
        Me.OrbOptionButtonOptions.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.OrbOptionButtonOptions.Tag = Nothing
        resources.ApplyResources(Me.OrbOptionButtonOptions, "OrbOptionButtonOptions")
        Me.OrbOptionButtonOptions.ToolTip = Nothing
        Me.OrbOptionButtonOptions.ToolTipImage = Nothing
        Me.OrbOptionButtonOptions.ToolTipTitle = Nothing
        '
        'QATMenuSave
        '
        Me.QATMenuSave.AltKey = Nothing
        Me.QATMenuSave.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.QATMenuSave.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.QATMenuSave.Image = CType(resources.GetObject("QATMenuSave.Image"), System.Drawing.Image)
        Me.QATMenuSave.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.QATMenuSave.SmallImage = CType(resources.GetObject("QATMenuSave.SmallImage"), System.Drawing.Image)
        Me.QATMenuSave.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.QATMenuSave.Tag = Nothing
        resources.ApplyResources(Me.QATMenuSave, "QATMenuSave")
        Me.QATMenuSave.ToolTip = Nothing
        Me.QATMenuSave.ToolTipImage = Nothing
        Me.QATMenuSave.ToolTipTitle = Nothing
        '
        'QATMenuSaveAll
        '
        Me.QATMenuSaveAll.AltKey = Nothing
        Me.QATMenuSaveAll.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.QATMenuSaveAll.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.QATMenuSaveAll.Image = CType(resources.GetObject("QATMenuSaveAll.Image"), System.Drawing.Image)
        Me.QATMenuSaveAll.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.QATMenuSaveAll.SmallImage = CType(resources.GetObject("QATMenuSaveAll.SmallImage"), System.Drawing.Image)
        Me.QATMenuSaveAll.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.QATMenuSaveAll.Tag = Nothing
        resources.ApplyResources(Me.QATMenuSaveAll, "QATMenuSaveAll")
        Me.QATMenuSaveAll.ToolTip = Nothing
        Me.QATMenuSaveAll.ToolTipImage = Nothing
        Me.QATMenuSaveAll.ToolTipTitle = Nothing
        '
        'ribHome
        '
        Me.ribHome.Panels.Add(Me.ribHomeEdit)
        Me.ribHome.Panels.Add(Me.ribHomeView)
        Me.ribHome.Panels.Add(Me.ribHomeDebug)
        Me.ribHome.Panels.Add(Me.ribHomeTools)
        Me.ribHome.Tag = Nothing
        resources.ApplyResources(Me.ribHome, "ribHome")
        '
        'ribHomeEdit
        '
        Me.ribHomeEdit.ButtonMoreVisible = False
        Me.ribHomeEdit.Items.Add(Me.ribHomeEditGoto)
        Me.ribHomeEdit.Items.Add(Me.ribHomeEditGroup1)
        Me.ribHomeEdit.Items.Add(Me.ribHomeEditGroup2)
        Me.ribHomeEdit.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEdit, "ribHomeEdit")
        '
        'ribHomeEditGoto
        '
        Me.ribHomeEditGoto.AltKey = Nothing
        Me.ribHomeEditGoto.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeEditGoto.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeEditGoto.Image = CType(resources.GetObject("ribHomeEditGoto.Image"), System.Drawing.Image)
        Me.ribHomeEditGoto.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeEditGoto.SmallImage = CType(resources.GetObject("ribHomeEditGoto.SmallImage"), System.Drawing.Image)
        Me.ribHomeEditGoto.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeEditGoto.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEditGoto, "ribHomeEditGoto")
        Me.ribHomeEditGoto.ToolTip = Nothing
        Me.ribHomeEditGoto.ToolTipImage = Nothing
        Me.ribHomeEditGoto.ToolTipTitle = Nothing
        '
        'ribHomeEditGroup1
        '
        Me.ribHomeEditGroup1.AltKey = Nothing
        Me.ribHomeEditGroup1.Enabled = False
        Me.ribHomeEditGroup1.Image = Nothing
        Me.ribHomeEditGroup1.Items.Add(Me.ribHomeEditFind)
        Me.ribHomeEditGroup1.Items.Add(Me.ribHomeEditReplace)
        Me.ribHomeEditGroup1.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEditGroup1, "ribHomeEditGroup1")
        Me.ribHomeEditGroup1.ToolTip = Nothing
        Me.ribHomeEditGroup1.ToolTipImage = Nothing
        Me.ribHomeEditGroup1.ToolTipTitle = Nothing
        '
        'ribHomeEditFind
        '
        Me.ribHomeEditFind.AltKey = Nothing
        Me.ribHomeEditFind.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeEditFind.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeEditFind.Image = CType(resources.GetObject("ribHomeEditFind.Image"), System.Drawing.Image)
        Me.ribHomeEditFind.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeEditFind.SmallImage = CType(resources.GetObject("ribHomeEditFind.SmallImage"), System.Drawing.Image)
        Me.ribHomeEditFind.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeEditFind.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEditFind, "ribHomeEditFind")
        Me.ribHomeEditFind.ToolTipImage = Nothing
        Me.ribHomeEditFind.ToolTipTitle = Nothing
        '
        'ribHomeEditReplace
        '
        Me.ribHomeEditReplace.AltKey = Nothing
        Me.ribHomeEditReplace.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeEditReplace.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeEditReplace.Image = CType(resources.GetObject("ribHomeEditReplace.Image"), System.Drawing.Image)
        Me.ribHomeEditReplace.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeEditReplace.SmallImage = CType(resources.GetObject("ribHomeEditReplace.SmallImage"), System.Drawing.Image)
        Me.ribHomeEditReplace.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeEditReplace.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEditReplace, "ribHomeEditReplace")
        Me.ribHomeEditReplace.ToolTipImage = Nothing
        Me.ribHomeEditReplace.ToolTipTitle = Nothing
        '
        'ribHomeEditGroup2
        '
        Me.ribHomeEditGroup2.AltKey = Nothing
        Me.ribHomeEditGroup2.Enabled = False
        Me.ribHomeEditGroup2.Image = Nothing
        Me.ribHomeEditGroup2.Items.Add(Me.ribHomeEditComment)
        Me.ribHomeEditGroup2.Items.Add(Me.ribHomeEditUnComment)
        Me.ribHomeEditGroup2.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEditGroup2, "ribHomeEditGroup2")
        Me.ribHomeEditGroup2.ToolTip = Nothing
        Me.ribHomeEditGroup2.ToolTipImage = Nothing
        Me.ribHomeEditGroup2.ToolTipTitle = Nothing
        '
        'ribHomeEditComment
        '
        Me.ribHomeEditComment.AltKey = Nothing
        Me.ribHomeEditComment.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeEditComment.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeEditComment.Image = CType(resources.GetObject("ribHomeEditComment.Image"), System.Drawing.Image)
        Me.ribHomeEditComment.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeEditComment.SmallImage = CType(resources.GetObject("ribHomeEditComment.SmallImage"), System.Drawing.Image)
        Me.ribHomeEditComment.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeEditComment.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEditComment, "ribHomeEditComment")
        Me.ribHomeEditComment.ToolTipImage = Nothing
        Me.ribHomeEditComment.ToolTipTitle = Nothing
        '
        'ribHomeEditUnComment
        '
        Me.ribHomeEditUnComment.AltKey = Nothing
        Me.ribHomeEditUnComment.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeEditUnComment.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeEditUnComment.Image = CType(resources.GetObject("ribHomeEditUnComment.Image"), System.Drawing.Image)
        Me.ribHomeEditUnComment.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeEditUnComment.SmallImage = CType(resources.GetObject("ribHomeEditUnComment.SmallImage"), System.Drawing.Image)
        Me.ribHomeEditUnComment.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeEditUnComment.Tag = Nothing
        resources.ApplyResources(Me.ribHomeEditUnComment, "ribHomeEditUnComment")
        Me.ribHomeEditUnComment.ToolTipImage = Nothing
        Me.ribHomeEditUnComment.ToolTipTitle = Nothing
        '
        'ribHomeView
        '
        Me.ribHomeView.ButtonMoreVisible = False
        Me.ribHomeView.Items.Add(Me.ribHomeViewNavBack)
        Me.ribHomeView.Items.Add(Me.ribHomeViewNavFwd)
        Me.ribHomeView.Items.Add(Me.ribHomeViewUserCallTips)
        Me.ribHomeView.Tag = Nothing
        resources.ApplyResources(Me.ribHomeView, "ribHomeView")
        '
        'ribHomeViewNavBack
        '
        Me.ribHomeViewNavBack.AltKey = Nothing
        Me.ribHomeViewNavBack.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeViewNavBack.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeViewNavBack.Image = CType(resources.GetObject("ribHomeViewNavBack.Image"), System.Drawing.Image)
        Me.ribHomeViewNavBack.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeViewNavBack.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeViewNavBack.SmallImage = CType(resources.GetObject("ribHomeViewNavBack.SmallImage"), System.Drawing.Image)
        Me.ribHomeViewNavBack.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeViewNavBack.Tag = Nothing
        resources.ApplyResources(Me.ribHomeViewNavBack, "ribHomeViewNavBack")
        Me.ribHomeViewNavBack.ToolTip = Nothing
        Me.ribHomeViewNavBack.ToolTipImage = Nothing
        Me.ribHomeViewNavBack.ToolTipTitle = Nothing
        '
        'ribHomeViewNavFwd
        '
        Me.ribHomeViewNavFwd.AltKey = Nothing
        Me.ribHomeViewNavFwd.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeViewNavFwd.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeViewNavFwd.Image = CType(resources.GetObject("ribHomeViewNavFwd.Image"), System.Drawing.Image)
        Me.ribHomeViewNavFwd.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeViewNavFwd.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeViewNavFwd.SmallImage = CType(resources.GetObject("ribHomeViewNavFwd.SmallImage"), System.Drawing.Image)
        Me.ribHomeViewNavFwd.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeViewNavFwd.Tag = Nothing
        resources.ApplyResources(Me.ribHomeViewNavFwd, "ribHomeViewNavFwd")
        Me.ribHomeViewNavFwd.ToolTip = Nothing
        Me.ribHomeViewNavFwd.ToolTipImage = Nothing
        Me.ribHomeViewNavFwd.ToolTipTitle = Nothing
        '
        'ribHomeViewUserCallTips
        '
        Me.ribHomeViewUserCallTips.AltKey = Nothing
        Me.ribHomeViewUserCallTips.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeViewUserCallTips.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeViewUserCallTips.Image = Nothing
        Me.ribHomeViewUserCallTips.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeViewUserCallTips.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeViewUserCallTips.SmallImage = CType(resources.GetObject("ribHomeViewUserCallTips.SmallImage"), System.Drawing.Image)
        Me.ribHomeViewUserCallTips.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeViewUserCallTips.Tag = Nothing
        resources.ApplyResources(Me.ribHomeViewUserCallTips, "ribHomeViewUserCallTips")
        Me.ribHomeViewUserCallTips.ToolTip = Nothing
        Me.ribHomeViewUserCallTips.ToolTipImage = Nothing
        Me.ribHomeViewUserCallTips.ToolTipTitle = Nothing
        '
        'ribHomeDebug
        '
        Me.ribHomeDebug.ButtonMoreVisible = False
        Me.ribHomeDebug.Items.Add(Me.ribHomeDebugStart)
        Me.ribHomeDebug.Items.Add(Me.ribHomeDebugStop)
        Me.ribHomeDebug.Items.Add(Me.ribHomeDebugStepInto)
        Me.ribHomeDebug.Items.Add(Me.ribHomeDebugStepOver)
        Me.ribHomeDebug.Tag = Nothing
        resources.ApplyResources(Me.ribHomeDebug, "ribHomeDebug")
        '
        'ribHomeDebugStart
        '
        Me.ribHomeDebugStart.AltKey = Nothing
        Me.ribHomeDebugStart.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeDebugStart.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeDebugStart.Image = Nothing
        Me.ribHomeDebugStart.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeDebugStart.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeDebugStart.SmallImage = CType(resources.GetObject("ribHomeDebugStart.SmallImage"), System.Drawing.Image)
        Me.ribHomeDebugStart.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeDebugStart.Tag = Nothing
        resources.ApplyResources(Me.ribHomeDebugStart, "ribHomeDebugStart")
        Me.ribHomeDebugStart.ToolTipImage = Nothing
        Me.ribHomeDebugStart.ToolTipTitle = Nothing
        '
        'ribHomeDebugStop
        '
        Me.ribHomeDebugStop.AltKey = Nothing
        Me.ribHomeDebugStop.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeDebugStop.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeDebugStop.Image = CType(resources.GetObject("ribHomeDebugStop.Image"), System.Drawing.Image)
        Me.ribHomeDebugStop.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeDebugStop.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeDebugStop.SmallImage = CType(resources.GetObject("ribHomeDebugStop.SmallImage"), System.Drawing.Image)
        Me.ribHomeDebugStop.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeDebugStop.Tag = Nothing
        resources.ApplyResources(Me.ribHomeDebugStop, "ribHomeDebugStop")
        Me.ribHomeDebugStop.ToolTipImage = Nothing
        Me.ribHomeDebugStop.ToolTipTitle = Nothing
        '
        'ribHomeDebugStepInto
        '
        Me.ribHomeDebugStepInto.AltKey = Nothing
        Me.ribHomeDebugStepInto.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeDebugStepInto.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeDebugStepInto.Image = CType(resources.GetObject("ribHomeDebugStepInto.Image"), System.Drawing.Image)
        Me.ribHomeDebugStepInto.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeDebugStepInto.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeDebugStepInto.SmallImage = CType(resources.GetObject("ribHomeDebugStepInto.SmallImage"), System.Drawing.Image)
        Me.ribHomeDebugStepInto.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeDebugStepInto.Tag = Nothing
        resources.ApplyResources(Me.ribHomeDebugStepInto, "ribHomeDebugStepInto")
        Me.ribHomeDebugStepInto.ToolTipImage = Nothing
        Me.ribHomeDebugStepInto.ToolTipTitle = Nothing
        '
        'ribHomeDebugStepOver
        '
        Me.ribHomeDebugStepOver.AltKey = Nothing
        Me.ribHomeDebugStepOver.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeDebugStepOver.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeDebugStepOver.Image = CType(resources.GetObject("ribHomeDebugStepOver.Image"), System.Drawing.Image)
        Me.ribHomeDebugStepOver.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeDebugStepOver.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeDebugStepOver.SmallImage = CType(resources.GetObject("ribHomeDebugStepOver.SmallImage"), System.Drawing.Image)
        Me.ribHomeDebugStepOver.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeDebugStepOver.Tag = Nothing
        resources.ApplyResources(Me.ribHomeDebugStepOver, "ribHomeDebugStepOver")
        Me.ribHomeDebugStepOver.ToolTipImage = Nothing
        Me.ribHomeDebugStepOver.ToolTipTitle = Nothing
        '
        'ribHomeTools
        '
        Me.ribHomeTools.ButtonMoreVisible = False
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsBeta)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsRelease)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsRunScript)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsCompile)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsContextCheck)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsTidySource)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsKoda)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsCompileWithOptions)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsCodeWizard)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsOpenInSciTE)
        Me.ribHomeTools.Items.Add(Me.ribHomeToolsExplore)
        Me.ribHomeTools.Tag = Nothing
        resources.ApplyResources(Me.ribHomeTools, "ribHomeTools")
        '
        'ribHomeToolsBeta
        '
        Me.ribHomeToolsBeta.AltKey = Nothing
        Me.ribHomeToolsBeta.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsBeta.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsBeta.Image = CType(resources.GetObject("ribHomeToolsBeta.Image"), System.Drawing.Image)
        Me.ribHomeToolsBeta.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsBeta.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsBeta.SmallImage = CType(resources.GetObject("ribHomeToolsBeta.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsBeta.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsBeta.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsBeta, "ribHomeToolsBeta")
        Me.ribHomeToolsBeta.ToolTip = Nothing
        Me.ribHomeToolsBeta.ToolTipImage = Nothing
        Me.ribHomeToolsBeta.ToolTipTitle = Nothing
        '
        'ribHomeToolsRelease
        '
        Me.ribHomeToolsRelease.AltKey = Nothing
        Me.ribHomeToolsRelease.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsRelease.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsRelease.Image = CType(resources.GetObject("ribHomeToolsRelease.Image"), System.Drawing.Image)
        Me.ribHomeToolsRelease.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsRelease.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsRelease.SmallImage = CType(resources.GetObject("ribHomeToolsRelease.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsRelease.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsRelease.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsRelease, "ribHomeToolsRelease")
        Me.ribHomeToolsRelease.ToolTip = Nothing
        Me.ribHomeToolsRelease.ToolTipImage = Nothing
        Me.ribHomeToolsRelease.ToolTipTitle = Nothing
        '
        'ribHomeToolsRunScript
        '
        Me.ribHomeToolsRunScript.AltKey = Nothing
        Me.ribHomeToolsRunScript.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsRunScript.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsRunScript.Image = CType(resources.GetObject("ribHomeToolsRunScript.Image"), System.Drawing.Image)
        Me.ribHomeToolsRunScript.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsRunScript.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsRunScript.SmallImage = CType(resources.GetObject("ribHomeToolsRunScript.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsRunScript.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsRunScript.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsRunScript, "ribHomeToolsRunScript")
        Me.ribHomeToolsRunScript.ToolTip = Nothing
        Me.ribHomeToolsRunScript.ToolTipImage = Nothing
        Me.ribHomeToolsRunScript.ToolTipTitle = Nothing
        '
        'ribHomeToolsCompile
        '
        Me.ribHomeToolsCompile.AltKey = Nothing
        Me.ribHomeToolsCompile.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsCompile.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsCompile.Image = CType(resources.GetObject("ribHomeToolsCompile.Image"), System.Drawing.Image)
        Me.ribHomeToolsCompile.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsCompile.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsCompile.SmallImage = CType(resources.GetObject("ribHomeToolsCompile.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsCompile.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsCompile.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsCompile, "ribHomeToolsCompile")
        Me.ribHomeToolsCompile.ToolTip = Nothing
        Me.ribHomeToolsCompile.ToolTipImage = Nothing
        Me.ribHomeToolsCompile.ToolTipTitle = Nothing
        '
        'ribHomeToolsContextCheck
        '
        Me.ribHomeToolsContextCheck.AltKey = Nothing
        Me.ribHomeToolsContextCheck.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsContextCheck.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsContextCheck.Image = CType(resources.GetObject("ribHomeToolsContextCheck.Image"), System.Drawing.Image)
        Me.ribHomeToolsContextCheck.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsContextCheck.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsContextCheck.SmallImage = CType(resources.GetObject("ribHomeToolsContextCheck.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsContextCheck.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsContextCheck.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsContextCheck, "ribHomeToolsContextCheck")
        Me.ribHomeToolsContextCheck.ToolTip = Nothing
        Me.ribHomeToolsContextCheck.ToolTipImage = Nothing
        Me.ribHomeToolsContextCheck.ToolTipTitle = Nothing
        '
        'ribHomeToolsTidySource
        '
        Me.ribHomeToolsTidySource.AltKey = Nothing
        Me.ribHomeToolsTidySource.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsTidySource.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsTidySource.Image = CType(resources.GetObject("ribHomeToolsTidySource.Image"), System.Drawing.Image)
        Me.ribHomeToolsTidySource.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsTidySource.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsTidySource.SmallImage = CType(resources.GetObject("ribHomeToolsTidySource.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsTidySource.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsTidySource.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsTidySource, "ribHomeToolsTidySource")
        Me.ribHomeToolsTidySource.ToolTip = Nothing
        Me.ribHomeToolsTidySource.ToolTipImage = Nothing
        Me.ribHomeToolsTidySource.ToolTipTitle = Nothing
        '
        'ribHomeToolsKoda
        '
        Me.ribHomeToolsKoda.AltKey = Nothing
        Me.ribHomeToolsKoda.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsKoda.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsKoda.Image = CType(resources.GetObject("ribHomeToolsKoda.Image"), System.Drawing.Image)
        Me.ribHomeToolsKoda.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsKoda.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsKoda.SmallImage = CType(resources.GetObject("ribHomeToolsKoda.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsKoda.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsKoda.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsKoda, "ribHomeToolsKoda")
        Me.ribHomeToolsKoda.ToolTip = Nothing
        Me.ribHomeToolsKoda.ToolTipImage = Nothing
        Me.ribHomeToolsKoda.ToolTipTitle = Nothing
        '
        'ribHomeToolsCompileWithOptions
        '
        Me.ribHomeToolsCompileWithOptions.AltKey = Nothing
        Me.ribHomeToolsCompileWithOptions.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsCompileWithOptions.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsCompileWithOptions.Image = CType(resources.GetObject("ribHomeToolsCompileWithOptions.Image"), System.Drawing.Image)
        Me.ribHomeToolsCompileWithOptions.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsCompileWithOptions.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsCompileWithOptions.SmallImage = CType(resources.GetObject("ribHomeToolsCompileWithOptions.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsCompileWithOptions.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsCompileWithOptions.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsCompileWithOptions, "ribHomeToolsCompileWithOptions")
        Me.ribHomeToolsCompileWithOptions.ToolTip = Nothing
        Me.ribHomeToolsCompileWithOptions.ToolTipImage = Nothing
        Me.ribHomeToolsCompileWithOptions.ToolTipTitle = Nothing
        '
        'ribHomeToolsCodeWizard
        '
        Me.ribHomeToolsCodeWizard.AltKey = Nothing
        Me.ribHomeToolsCodeWizard.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsCodeWizard.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsCodeWizard.Image = Nothing
        Me.ribHomeToolsCodeWizard.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsCodeWizard.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsCodeWizard.SmallImage = CType(resources.GetObject("ribHomeToolsCodeWizard.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsCodeWizard.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsCodeWizard.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsCodeWizard, "ribHomeToolsCodeWizard")
        Me.ribHomeToolsCodeWizard.ToolTip = Nothing
        Me.ribHomeToolsCodeWizard.ToolTipImage = Nothing
        Me.ribHomeToolsCodeWizard.ToolTipTitle = Nothing
        '
        'ribHomeToolsOpenInSciTE
        '
        Me.ribHomeToolsOpenInSciTE.AltKey = Nothing
        Me.ribHomeToolsOpenInSciTE.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsOpenInSciTE.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsOpenInSciTE.Image = CType(resources.GetObject("ribHomeToolsOpenInSciTE.Image"), System.Drawing.Image)
        Me.ribHomeToolsOpenInSciTE.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsOpenInSciTE.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsOpenInSciTE.SmallImage = CType(resources.GetObject("ribHomeToolsOpenInSciTE.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsOpenInSciTE.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsOpenInSciTE.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsOpenInSciTE, "ribHomeToolsOpenInSciTE")
        Me.ribHomeToolsOpenInSciTE.ToolTip = Nothing
        Me.ribHomeToolsOpenInSciTE.ToolTipImage = Nothing
        Me.ribHomeToolsOpenInSciTE.ToolTipTitle = Nothing
        '
        'ribHomeToolsExplore
        '
        Me.ribHomeToolsExplore.AltKey = Nothing
        Me.ribHomeToolsExplore.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHomeToolsExplore.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHomeToolsExplore.Image = CType(resources.GetObject("ribHomeToolsExplore.Image"), System.Drawing.Image)
        Me.ribHomeToolsExplore.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHomeToolsExplore.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHomeToolsExplore.SmallImage = CType(resources.GetObject("ribHomeToolsExplore.SmallImage"), System.Drawing.Image)
        Me.ribHomeToolsExplore.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHomeToolsExplore.Tag = Nothing
        resources.ApplyResources(Me.ribHomeToolsExplore, "ribHomeToolsExplore")
        Me.ribHomeToolsExplore.ToolTip = Nothing
        Me.ribHomeToolsExplore.ToolTipImage = Nothing
        Me.ribHomeToolsExplore.ToolTipTitle = Nothing
        '
        'RibbonTab1
        '
        Me.RibbonTab1.Panels.Add(Me.ribWindowWindows)
        Me.RibbonTab1.Tag = Nothing
        resources.ApplyResources(Me.RibbonTab1, "RibbonTab1")
        '
        'ribWindowWindows
        '
        Me.ribWindowWindows.ButtonMoreVisible = False
        Me.ribWindowWindows.Items.Add(Me.ribWindowWatch)
        Me.ribWindowWindows.Items.Add(Me.ribWindowWindowTrace)
        Me.ribWindowWindows.Items.Add(Me.ribWindowWindowOutput)
        Me.ribWindowWindows.Items.Add(Me.ribWindowWindowWeb)
        Me.ribWindowWindows.Items.Add(Me.ribWindowVariables)
        Me.ribWindowWindows.Items.Add(Me.ribWindowWindowErrorList)
        Me.ribWindowWindows.Items.Add(Me.ribWindowToolChest)
        Me.ribWindowWindows.Items.Add(Me.ribWindowFunctions)
        Me.ribWindowWindows.Items.Add(Me.ribWindowIncludes)
        Me.ribWindowWindows.Items.Add(Me.ribWindowTidy)
        Me.ribWindowWindows.Tag = Nothing
        resources.ApplyResources(Me.ribWindowWindows, "ribWindowWindows")
        '
        'ribWindowWatch
        '
        Me.ribWindowWatch.AltKey = Nothing
        Me.ribWindowWatch.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowWatch.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowWatch.Image = CType(resources.GetObject("ribWindowWatch.Image"), System.Drawing.Image)
        Me.ribWindowWatch.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowWatch.SmallImage = CType(resources.GetObject("ribWindowWatch.SmallImage"), System.Drawing.Image)
        Me.ribWindowWatch.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowWatch.Tag = Nothing
        resources.ApplyResources(Me.ribWindowWatch, "ribWindowWatch")
        Me.ribWindowWatch.ToolTip = Nothing
        Me.ribWindowWatch.ToolTipImage = Nothing
        Me.ribWindowWatch.ToolTipTitle = Nothing
        '
        'ribWindowWindowTrace
        '
        Me.ribWindowWindowTrace.AltKey = Nothing
        Me.ribWindowWindowTrace.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowWindowTrace.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowWindowTrace.Image = CType(resources.GetObject("ribWindowWindowTrace.Image"), System.Drawing.Image)
        Me.ribWindowWindowTrace.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowWindowTrace.SmallImage = CType(resources.GetObject("ribWindowWindowTrace.SmallImage"), System.Drawing.Image)
        Me.ribWindowWindowTrace.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowWindowTrace.Tag = Nothing
        resources.ApplyResources(Me.ribWindowWindowTrace, "ribWindowWindowTrace")
        Me.ribWindowWindowTrace.ToolTip = Nothing
        Me.ribWindowWindowTrace.ToolTipImage = Nothing
        Me.ribWindowWindowTrace.ToolTipTitle = Nothing
        '
        'ribWindowWindowOutput
        '
        Me.ribWindowWindowOutput.AltKey = Nothing
        Me.ribWindowWindowOutput.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowWindowOutput.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowWindowOutput.Image = CType(resources.GetObject("ribWindowWindowOutput.Image"), System.Drawing.Image)
        Me.ribWindowWindowOutput.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowWindowOutput.SmallImage = CType(resources.GetObject("ribWindowWindowOutput.SmallImage"), System.Drawing.Image)
        Me.ribWindowWindowOutput.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowWindowOutput.Tag = Nothing
        resources.ApplyResources(Me.ribWindowWindowOutput, "ribWindowWindowOutput")
        Me.ribWindowWindowOutput.ToolTip = Nothing
        Me.ribWindowWindowOutput.ToolTipImage = Nothing
        Me.ribWindowWindowOutput.ToolTipTitle = Nothing
        '
        'ribWindowWindowWeb
        '
        Me.ribWindowWindowWeb.AltKey = Nothing
        Me.ribWindowWindowWeb.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowWindowWeb.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowWindowWeb.Image = CType(resources.GetObject("ribWindowWindowWeb.Image"), System.Drawing.Image)
        Me.ribWindowWindowWeb.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowWindowWeb.SmallImage = CType(resources.GetObject("ribWindowWindowWeb.SmallImage"), System.Drawing.Image)
        Me.ribWindowWindowWeb.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowWindowWeb.Tag = Nothing
        resources.ApplyResources(Me.ribWindowWindowWeb, "ribWindowWindowWeb")
        Me.ribWindowWindowWeb.ToolTip = Nothing
        Me.ribWindowWindowWeb.ToolTipImage = Nothing
        Me.ribWindowWindowWeb.ToolTipTitle = Nothing
        '
        'ribWindowVariables
        '
        Me.ribWindowVariables.AltKey = Nothing
        Me.ribWindowVariables.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowVariables.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowVariables.DropDownItems.Add(Me.RibbonButton8)
        Me.ribWindowVariables.Image = CType(resources.GetObject("ribWindowVariables.Image"), System.Drawing.Image)
        Me.ribWindowVariables.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowVariables.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribWindowVariables.SmallImage = CType(resources.GetObject("ribWindowVariables.SmallImage"), System.Drawing.Image)
        Me.ribWindowVariables.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowVariables.Tag = Nothing
        resources.ApplyResources(Me.ribWindowVariables, "ribWindowVariables")
        Me.ribWindowVariables.ToolTip = Nothing
        Me.ribWindowVariables.ToolTipImage = Nothing
        Me.ribWindowVariables.ToolTipTitle = Nothing
        '
        'RibbonButton8
        '
        Me.RibbonButton8.AltKey = Nothing
        Me.RibbonButton8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton8.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton8.Image = CType(resources.GetObject("RibbonButton8.Image"), System.Drawing.Image)
        Me.RibbonButton8.SmallImage = CType(resources.GetObject("RibbonButton8.SmallImage"), System.Drawing.Image)
        Me.RibbonButton8.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton8.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton8, "RibbonButton8")
        Me.RibbonButton8.ToolTip = Nothing
        Me.RibbonButton8.ToolTipImage = Nothing
        Me.RibbonButton8.ToolTipTitle = Nothing
        '
        'ribWindowWindowErrorList
        '
        Me.ribWindowWindowErrorList.AltKey = Nothing
        Me.ribWindowWindowErrorList.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowWindowErrorList.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowWindowErrorList.Image = CType(resources.GetObject("ribWindowWindowErrorList.Image"), System.Drawing.Image)
        Me.ribWindowWindowErrorList.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowWindowErrorList.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribWindowWindowErrorList.SmallImage = CType(resources.GetObject("ribWindowWindowErrorList.SmallImage"), System.Drawing.Image)
        Me.ribWindowWindowErrorList.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowWindowErrorList.Tag = Nothing
        resources.ApplyResources(Me.ribWindowWindowErrorList, "ribWindowWindowErrorList")
        Me.ribWindowWindowErrorList.ToolTip = Nothing
        Me.ribWindowWindowErrorList.ToolTipImage = Nothing
        Me.ribWindowWindowErrorList.ToolTipTitle = Nothing
        '
        'ribWindowToolChest
        '
        Me.ribWindowToolChest.AltKey = Nothing
        Me.ribWindowToolChest.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowToolChest.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowToolChest.DropDownItems.Add(Me.RibbonButton6)
        Me.ribWindowToolChest.DropDownItems.Add(Me.RibbonButton7)
        Me.ribWindowToolChest.Image = CType(resources.GetObject("ribWindowToolChest.Image"), System.Drawing.Image)
        Me.ribWindowToolChest.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowToolChest.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribWindowToolChest.SmallImage = CType(resources.GetObject("ribWindowToolChest.SmallImage"), System.Drawing.Image)
        Me.ribWindowToolChest.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowToolChest.Tag = Nothing
        resources.ApplyResources(Me.ribWindowToolChest, "ribWindowToolChest")
        Me.ribWindowToolChest.ToolTip = Nothing
        Me.ribWindowToolChest.ToolTipImage = Nothing
        Me.ribWindowToolChest.ToolTipTitle = Nothing
        '
        'RibbonButton6
        '
        Me.RibbonButton6.AltKey = Nothing
        Me.RibbonButton6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton6.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton6.Image = CType(resources.GetObject("RibbonButton6.Image"), System.Drawing.Image)
        Me.RibbonButton6.SmallImage = CType(resources.GetObject("RibbonButton6.SmallImage"), System.Drawing.Image)
        Me.RibbonButton6.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton6.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton6, "RibbonButton6")
        Me.RibbonButton6.ToolTip = Nothing
        Me.RibbonButton6.ToolTipImage = Nothing
        Me.RibbonButton6.ToolTipTitle = Nothing
        '
        'RibbonButton7
        '
        Me.RibbonButton7.AltKey = Nothing
        Me.RibbonButton7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton7.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton7.Image = CType(resources.GetObject("RibbonButton7.Image"), System.Drawing.Image)
        Me.RibbonButton7.SmallImage = CType(resources.GetObject("RibbonButton7.SmallImage"), System.Drawing.Image)
        Me.RibbonButton7.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton7.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton7, "RibbonButton7")
        Me.RibbonButton7.ToolTip = Nothing
        Me.RibbonButton7.ToolTipImage = Nothing
        Me.RibbonButton7.ToolTipTitle = Nothing
        '
        'ribWindowFunctions
        '
        Me.ribWindowFunctions.AltKey = Nothing
        Me.ribWindowFunctions.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowFunctions.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowFunctions.DropDownItems.Add(Me.RibbonButton9)
        Me.ribWindowFunctions.DropDownItems.Add(Me.RibbonButton10)
        Me.ribWindowFunctions.Image = CType(resources.GetObject("ribWindowFunctions.Image"), System.Drawing.Image)
        Me.ribWindowFunctions.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowFunctions.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribWindowFunctions.SmallImage = CType(resources.GetObject("ribWindowFunctions.SmallImage"), System.Drawing.Image)
        Me.ribWindowFunctions.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowFunctions.Tag = Nothing
        resources.ApplyResources(Me.ribWindowFunctions, "ribWindowFunctions")
        Me.ribWindowFunctions.ToolTip = Nothing
        Me.ribWindowFunctions.ToolTipImage = Nothing
        Me.ribWindowFunctions.ToolTipTitle = Nothing
        '
        'RibbonButton9
        '
        Me.RibbonButton9.AltKey = Nothing
        Me.RibbonButton9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton9.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton9.Image = CType(resources.GetObject("RibbonButton9.Image"), System.Drawing.Image)
        Me.RibbonButton9.SmallImage = CType(resources.GetObject("RibbonButton9.SmallImage"), System.Drawing.Image)
        Me.RibbonButton9.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton9.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton9, "RibbonButton9")
        Me.RibbonButton9.ToolTip = Nothing
        Me.RibbonButton9.ToolTipImage = Nothing
        Me.RibbonButton9.ToolTipTitle = Nothing
        '
        'RibbonButton10
        '
        Me.RibbonButton10.AltKey = Nothing
        Me.RibbonButton10.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton10.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton10.Image = CType(resources.GetObject("RibbonButton10.Image"), System.Drawing.Image)
        Me.RibbonButton10.SmallImage = CType(resources.GetObject("RibbonButton10.SmallImage"), System.Drawing.Image)
        Me.RibbonButton10.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton10.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton10, "RibbonButton10")
        Me.RibbonButton10.ToolTip = Nothing
        Me.RibbonButton10.ToolTipImage = Nothing
        Me.RibbonButton10.ToolTipTitle = Nothing
        '
        'ribWindowIncludes
        '
        Me.ribWindowIncludes.AltKey = Nothing
        Me.ribWindowIncludes.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowIncludes.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowIncludes.Image = CType(resources.GetObject("ribWindowIncludes.Image"), System.Drawing.Image)
        Me.ribWindowIncludes.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowIncludes.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribWindowIncludes.SmallImage = CType(resources.GetObject("ribWindowIncludes.SmallImage"), System.Drawing.Image)
        Me.ribWindowIncludes.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowIncludes.Tag = Nothing
        resources.ApplyResources(Me.ribWindowIncludes, "ribWindowIncludes")
        Me.ribWindowIncludes.ToolTip = Nothing
        Me.ribWindowIncludes.ToolTipImage = Nothing
        Me.ribWindowIncludes.ToolTipTitle = Nothing
        '
        'ribWindowTidy
        '
        Me.ribWindowTidy.AltKey = Nothing
        Me.ribWindowTidy.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribWindowTidy.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribWindowTidy.Image = CType(resources.GetObject("ribWindowTidy.Image"), System.Drawing.Image)
        Me.ribWindowTidy.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribWindowTidy.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribWindowTidy.SmallImage = CType(resources.GetObject("ribWindowTidy.SmallImage"), System.Drawing.Image)
        Me.ribWindowTidy.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribWindowTidy.Tag = Nothing
        resources.ApplyResources(Me.ribWindowTidy, "ribWindowTidy")
        Me.ribWindowTidy.ToolTip = Nothing
        Me.ribWindowTidy.ToolTipImage = Nothing
        Me.ribWindowTidy.ToolTipTitle = Nothing
        '
        'ribWIP
        '
        Me.ribWIP.Panels.Add(Me.ribWIPMain)
        Me.ribWIP.Tag = Nothing
        resources.ApplyResources(Me.ribWIP, "ribWIP")
        '
        'ribWIPMain
        '
        Me.ribWIPMain.ButtonMoreVisible = False
        Me.ribWIPMain.Items.Add(Me.RibbonButton2)
        Me.ribWIPMain.Items.Add(Me.RibbonButton4)
        Me.ribWIPMain.Items.Add(Me.RibbonButton5)
        Me.ribWIPMain.Tag = Nothing
        resources.ApplyResources(Me.ribWIPMain, "ribWIPMain")
        '
        'RibbonButton2
        '
        Me.RibbonButton2.AltKey = Nothing
        Me.RibbonButton2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton2.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton2.DropDownItems.Add(Me.RibbonButton3)
        Me.RibbonButton2.Image = CType(resources.GetObject("RibbonButton2.Image"), System.Drawing.Image)
        Me.RibbonButton2.SmallImage = CType(resources.GetObject("RibbonButton2.SmallImage"), System.Drawing.Image)
        Me.RibbonButton2.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton2.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton2, "RibbonButton2")
        Me.RibbonButton2.ToolTip = Nothing
        Me.RibbonButton2.ToolTipImage = Nothing
        Me.RibbonButton2.ToolTipTitle = Nothing
        '
        'RibbonButton3
        '
        Me.RibbonButton3.AltKey = Nothing
        Me.RibbonButton3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton3.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton3.Image = CType(resources.GetObject("RibbonButton3.Image"), System.Drawing.Image)
        Me.RibbonButton3.SmallImage = CType(resources.GetObject("RibbonButton3.SmallImage"), System.Drawing.Image)
        Me.RibbonButton3.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton3.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton3, "RibbonButton3")
        Me.RibbonButton3.ToolTip = Nothing
        Me.RibbonButton3.ToolTipImage = Nothing
        Me.RibbonButton3.ToolTipTitle = Nothing
        '
        'RibbonButton4
        '
        Me.RibbonButton4.AltKey = Nothing
        Me.RibbonButton4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton4.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton4.Image = CType(resources.GetObject("RibbonButton4.Image"), System.Drawing.Image)
        Me.RibbonButton4.SmallImage = CType(resources.GetObject("RibbonButton4.SmallImage"), System.Drawing.Image)
        Me.RibbonButton4.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton4.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton4, "RibbonButton4")
        Me.RibbonButton4.ToolTip = Nothing
        Me.RibbonButton4.ToolTipImage = Nothing
        Me.RibbonButton4.ToolTipTitle = Nothing
        '
        'RibbonButton5
        '
        Me.RibbonButton5.AltKey = Nothing
        Me.RibbonButton5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton5.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton5.Image = CType(resources.GetObject("RibbonButton5.Image"), System.Drawing.Image)
        Me.RibbonButton5.SmallImage = CType(resources.GetObject("RibbonButton5.SmallImage"), System.Drawing.Image)
        Me.RibbonButton5.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton5.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton5, "RibbonButton5")
        Me.RibbonButton5.ToolTip = Nothing
        Me.RibbonButton5.ToolTipImage = Nothing
        Me.RibbonButton5.ToolTipTitle = Nothing
        '
        'ribHelp
        '
        Me.ribHelp.Panels.Add(Me.ribHelpHelp)
        Me.ribHelp.Tag = Nothing
        resources.ApplyResources(Me.ribHelp, "ribHelp")
        '
        'ribHelpHelp
        '
        Me.ribHelpHelp.ButtonMoreEnabled = False
        Me.ribHelpHelp.ButtonMoreVisible = False
        Me.ribHelpHelp.Items.Add(Me.ribHelpContents)
        Me.ribHelpHelp.Items.Add(Me.ribHelpIndex)
        Me.ribHelpHelp.Items.Add(Me.ribHelpSearch)
        Me.ribHelpHelp.Items.Add(Me.RibbonSeparator1)
        Me.ribHelpHelp.Items.Add(Me.ribHelpAbout)
        Me.ribHelpHelp.Items.Add(Me.ribHelpForum)
        Me.ribHelpHelp.Items.Add(Me.ribHelpReport)
        Me.ribHelpHelp.Tag = Nothing
        resources.ApplyResources(Me.ribHelpHelp, "ribHelpHelp")
        '
        'ribHelpContents
        '
        Me.ribHelpContents.AltKey = Nothing
        Me.ribHelpContents.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHelpContents.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHelpContents.Image = CType(resources.GetObject("ribHelpContents.Image"), System.Drawing.Image)
        Me.ribHelpContents.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHelpContents.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHelpContents.SmallImage = CType(resources.GetObject("ribHelpContents.SmallImage"), System.Drawing.Image)
        Me.ribHelpContents.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHelpContents.Tag = Nothing
        resources.ApplyResources(Me.ribHelpContents, "ribHelpContents")
        Me.ribHelpContents.ToolTip = Nothing
        Me.ribHelpContents.ToolTipImage = Nothing
        Me.ribHelpContents.ToolTipTitle = Nothing
        '
        'ribHelpIndex
        '
        Me.ribHelpIndex.AltKey = Nothing
        Me.ribHelpIndex.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHelpIndex.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHelpIndex.Image = CType(resources.GetObject("ribHelpIndex.Image"), System.Drawing.Image)
        Me.ribHelpIndex.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHelpIndex.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHelpIndex.SmallImage = CType(resources.GetObject("ribHelpIndex.SmallImage"), System.Drawing.Image)
        Me.ribHelpIndex.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHelpIndex.Tag = Nothing
        resources.ApplyResources(Me.ribHelpIndex, "ribHelpIndex")
        Me.ribHelpIndex.ToolTip = Nothing
        Me.ribHelpIndex.ToolTipImage = Nothing
        Me.ribHelpIndex.ToolTipTitle = Nothing
        '
        'ribHelpSearch
        '
        Me.ribHelpSearch.AltKey = Nothing
        Me.ribHelpSearch.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHelpSearch.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHelpSearch.Image = CType(resources.GetObject("ribHelpSearch.Image"), System.Drawing.Image)
        Me.ribHelpSearch.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHelpSearch.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHelpSearch.SmallImage = CType(resources.GetObject("ribHelpSearch.SmallImage"), System.Drawing.Image)
        Me.ribHelpSearch.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHelpSearch.Tag = Nothing
        resources.ApplyResources(Me.ribHelpSearch, "ribHelpSearch")
        Me.ribHelpSearch.ToolTip = Nothing
        Me.ribHelpSearch.ToolTipImage = Nothing
        Me.ribHelpSearch.ToolTipTitle = Nothing
        '
        'RibbonSeparator1
        '
        Me.RibbonSeparator1.AltKey = Nothing
        Me.RibbonSeparator1.Image = Nothing
        Me.RibbonSeparator1.Tag = Nothing
        Me.RibbonSeparator1.Text = Nothing
        Me.RibbonSeparator1.ToolTip = Nothing
        Me.RibbonSeparator1.ToolTipImage = Nothing
        Me.RibbonSeparator1.ToolTipTitle = Nothing
        '
        'ribHelpAbout
        '
        Me.ribHelpAbout.AltKey = Nothing
        Me.ribHelpAbout.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHelpAbout.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHelpAbout.Image = CType(resources.GetObject("ribHelpAbout.Image"), System.Drawing.Image)
        Me.ribHelpAbout.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHelpAbout.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHelpAbout.SmallImage = CType(resources.GetObject("ribHelpAbout.SmallImage"), System.Drawing.Image)
        Me.ribHelpAbout.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHelpAbout.Tag = Nothing
        resources.ApplyResources(Me.ribHelpAbout, "ribHelpAbout")
        Me.ribHelpAbout.ToolTip = Nothing
        Me.ribHelpAbout.ToolTipImage = Nothing
        Me.ribHelpAbout.ToolTipTitle = Nothing
        '
        'ribHelpForum
        '
        Me.ribHelpForum.AltKey = Nothing
        Me.ribHelpForum.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHelpForum.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHelpForum.Image = CType(resources.GetObject("ribHelpForum.Image"), System.Drawing.Image)
        Me.ribHelpForum.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHelpForum.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHelpForum.SmallImage = CType(resources.GetObject("ribHelpForum.SmallImage"), System.Drawing.Image)
        Me.ribHelpForum.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHelpForum.Tag = Nothing
        resources.ApplyResources(Me.ribHelpForum, "ribHelpForum")
        Me.ribHelpForum.ToolTip = Nothing
        Me.ribHelpForum.ToolTipImage = Nothing
        Me.ribHelpForum.ToolTipTitle = Nothing
        '
        'ribHelpReport
        '
        Me.ribHelpReport.AltKey = Nothing
        Me.ribHelpReport.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.ribHelpReport.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.ribHelpReport.Image = CType(resources.GetObject("ribHelpReport.Image"), System.Drawing.Image)
        Me.ribHelpReport.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium
        Me.ribHelpReport.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact
        Me.ribHelpReport.SmallImage = CType(resources.GetObject("ribHelpReport.SmallImage"), System.Drawing.Image)
        Me.ribHelpReport.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.ribHelpReport.Tag = Nothing
        resources.ApplyResources(Me.ribHelpReport, "ribHelpReport")
        Me.ribHelpReport.ToolTip = Nothing
        Me.ribHelpReport.ToolTipImage = Nothing
        Me.ribHelpReport.ToolTipTitle = Nothing
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        resources.ApplyResources(Me.OpenFileDialog1, "OpenFileDialog1")
        '
        'RibbonPanel1
        '
        Me.RibbonPanel1.Tag = Nothing
        Me.RibbonPanel1.Text = Nothing
        '
        'RibbonPanel2
        '
        Me.RibbonPanel2.Tag = Nothing
        Me.RibbonPanel2.Text = Nothing
        '
        'RibbonButton1
        '
        Me.RibbonButton1.AltKey = Nothing
        Me.RibbonButton1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down
        Me.RibbonButton1.DropDownArrowSize = New System.Drawing.Size(5, 3)
        Me.RibbonButton1.Image = CType(resources.GetObject("RibbonButton1.Image"), System.Drawing.Image)
        Me.RibbonButton1.SmallImage = CType(resources.GetObject("RibbonButton1.SmallImage"), System.Drawing.Image)
        Me.RibbonButton1.Style = System.Windows.Forms.RibbonButtonStyle.Normal
        Me.RibbonButton1.Tag = Nothing
        resources.ApplyResources(Me.RibbonButton1, "RibbonButton1")
        Me.RibbonButton1.ToolTip = Nothing
        Me.RibbonButton1.ToolTipImage = Nothing
        Me.RibbonButton1.ToolTipTitle = Nothing
        '
        'RibbonSeparator3
        '
        Me.RibbonSeparator3.AltKey = Nothing
        Me.RibbonSeparator3.Image = Nothing
        Me.RibbonSeparator3.Tag = Nothing
        Me.RibbonSeparator3.Text = Nothing
        Me.RibbonSeparator3.ToolTip = Nothing
        Me.RibbonSeparator3.ToolTipImage = Nothing
        Me.RibbonSeparator3.ToolTipTitle = Nothing
        '
        'RibbonSeparator4
        '
        Me.RibbonSeparator4.AltKey = Nothing
        Me.RibbonSeparator4.Image = Nothing
        Me.RibbonSeparator4.Tag = Nothing
        Me.RibbonSeparator4.Text = Nothing
        Me.RibbonSeparator4.ToolTip = Nothing
        Me.RibbonSeparator4.ToolTipImage = Nothing
        Me.RibbonSeparator4.ToolTipTitle = Nothing
        '
        'frmMain
        '
        Me.AccessibleDescription = Nothing
        Me.AccessibleName = Nothing
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Nothing
        Me.Controls.Add(Me.DockPanel1)
        Me.Controls.Add(Me.Ribbon1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Font = Nothing
        Me.hlpMain.SetHelpKeyword(Me, Nothing)
        Me.hlpMain.SetHelpNavigator(Me, CType(resources.GetObject("$this.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.hlpMain.SetHelpString(Me, Nothing)
        Me.Icon = Nothing
        Me.IsMdiContainer = True
        Me.Name = "frmMain"
        Me.hlpMain.SetShowHelp(Me, CType(resources.GetObject("$this.ShowHelp"), Boolean))
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DockPanel1 As Docking.DockPanel
    Friend WithEvents hlpMain As System.Windows.Forms.HelpProvider
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents sblCurrentLineNumber As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Ribbon1 As System.Windows.Forms.Ribbon
    Friend WithEvents ribHome As System.Windows.Forms.RibbonTab
    Friend WithEvents RibbonPanel1 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel2 As System.Windows.Forms.RibbonPanel
    Friend WithEvents ribHomeEdit As System.Windows.Forms.RibbonPanel
    Friend WithEvents ribHomeEditGoto As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeDebug As System.Windows.Forms.RibbonPanel
    Friend WithEvents ribHomeTools As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonTab1 As System.Windows.Forms.RibbonTab
    Friend WithEvents ribWindowWindows As System.Windows.Forms.RibbonPanel
    Friend WithEvents ribWindowWatch As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowWindowTrace As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowWindowOutput As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowWindowWeb As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeDebugStart As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeDebugStop As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeDebugStepInto As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeDebugStepOver As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsRelease As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsBeta As System.Windows.Forms.RibbonButton
    Friend WithEvents sblAutoItVersion As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ribWIP As System.Windows.Forms.RibbonTab
    Friend WithEvents ribWIPMain As System.Windows.Forms.RibbonPanel
    Friend WithEvents ribHomeView As System.Windows.Forms.RibbonPanel
    Friend WithEvents ribHomeViewNavBack As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeViewNavFwd As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeEditFind As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeEditReplace As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeEditComment As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeEditUnComment As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsContextCheck As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsTidySource As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsOpenInSciTE As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsRunScript As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHelp As System.Windows.Forms.RibbonTab
    Friend WithEvents ribHelpHelp As System.Windows.Forms.RibbonPanel
    Friend WithEvents ribHelpContents As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHelpIndex As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHelpSearch As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonSeparator1 As System.Windows.Forms.RibbonSeparator
    Friend WithEvents ribHelpAbout As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsCompile As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsKoda As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsCodeWizard As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsCompileWithOptions As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowVariables As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHelpReport As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowWindowErrorList As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeViewUserCallTips As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowToolChest As System.Windows.Forms.RibbonButton
    Private WithEvents ribHomeEditGroup1 As System.Windows.Forms.RibbonItemGroup
    Private WithEvents ribHomeEditGroup2 As System.Windows.Forms.RibbonItemGroup
    Friend WithEvents OrmMenuNew As System.Windows.Forms.RibbonOrbMenuItem
    Friend WithEvents OrbMenuOpen As System.Windows.Forms.RibbonOrbMenuItem
    Friend WithEvents OrbMenuSave As System.Windows.Forms.RibbonOrbMenuItem
    Friend WithEvents OrbMenuSaveAll As System.Windows.Forms.RibbonOrbMenuItem
    Friend WithEvents RibbonSeparator2 As System.Windows.Forms.RibbonSeparator
    Friend WithEvents OrbMenuClose As System.Windows.Forms.RibbonOrbMenuItem
    Friend WithEvents OrbOptionButtonExit As System.Windows.Forms.RibbonOrbOptionButton
    Friend WithEvents OrbOptionButtonOptions As System.Windows.Forms.RibbonOrbOptionButton
    Friend WithEvents OrbMenuReloadDoc As System.Windows.Forms.RibbonOrbMenuItem
    Friend WithEvents QATMenuSaveAll As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton1 As System.Windows.Forms.RibbonButton
    Friend WithEvents QATMenuSave As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton2 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton3 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton4 As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHelpForum As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton5 As System.Windows.Forms.RibbonButton
    Friend WithEvents ribHomeToolsExplore As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton6 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton7 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton8 As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowFunctions As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton9 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton10 As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowIncludes As System.Windows.Forms.RibbonButton
    Friend WithEvents ribWindowTidy As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonSeparator3 As System.Windows.Forms.RibbonSeparator
    Friend WithEvents RibbonSeparator4 As System.Windows.Forms.RibbonSeparator
End Class
