<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOptions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.chkDebugIncludeFiles = New System.Windows.Forms.CheckBox
        Me.lblAutoIt = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.ftbSciTEInstallFolder = New FolderTextBox
        Me.ftbBetaIncludeFolder = New FolderTextBox
        Me.ftbReleaseIncludeFolder = New FolderTextBox
        Me.ftbAutoItBeta = New FileTextbox
        Me.ftbAutoItRelease = New FileTextbox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.txtCommandLineArguments = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.chkEnableAutomaticUpdates = New System.Windows.Forms.CheckBox
        Me.chkEnableCallTips = New System.Windows.Forms.CheckBox
        Me.chkEnableAutoComplete = New System.Windows.Forms.CheckBox
        Me.chkAutomaticContextChecking = New System.Windows.Forms.CheckBox
        Me.chkUseVSLexer = New System.Windows.Forms.CheckBox
        Me.chkAutomaticTidy = New System.Windows.Forms.CheckBox
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(372, 277)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'chkDebugIncludeFiles
        '
        Me.chkDebugIncludeFiles.AutoSize = True
        Me.chkDebugIncludeFiles.Location = New System.Drawing.Point(6, 6)
        Me.chkDebugIncludeFiles.Name = "chkDebugIncludeFiles"
        Me.chkDebugIncludeFiles.Size = New System.Drawing.Size(206, 17)
        Me.chkDebugIncludeFiles.TabIndex = 1
        Me.chkDebugIncludeFiles.Text = "Debug files in the AutoIt include library"
        Me.chkDebugIncludeFiles.UseVisualStyleBackColor = True
        '
        'lblAutoIt
        '
        Me.lblAutoIt.AutoSize = True
        Me.lblAutoIt.Location = New System.Drawing.Point(3, 35)
        Me.lblAutoIt.Name = "lblAutoIt"
        Me.lblAutoIt.Size = New System.Drawing.Size(86, 13)
        Me.lblAutoIt.TabIndex = 3
        Me.lblAutoIt.Text = "AutoIt3 Release:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "AutoIt3 Beta:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(102, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Beta Include Folder:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(119, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Release Include Folder:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 140)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "SciTE Install Folder:"
        '
        'ftbSciTEInstallFolder
        '
        Me.ftbSciTEInstallFolder.BasePath = Nothing
        Me.ftbSciTEInstallFolder.FolderPath = ""
        Me.ftbSciTEInstallFolder.Location = New System.Drawing.Point(128, 140)
        Me.ftbSciTEInstallFolder.Name = "ftbSciTEInstallFolder"
        Me.ftbSciTEInstallFolder.ShowRelativePath = False
        Me.ftbSciTEInstallFolder.Size = New System.Drawing.Size(286, 20)
        Me.ftbSciTEInstallFolder.TabIndex = 10
        '
        'ftbBetaIncludeFolder
        '
        Me.ftbBetaIncludeFolder.BasePath = Nothing
        Me.ftbBetaIncludeFolder.FolderPath = ""
        Me.ftbBetaIncludeFolder.Location = New System.Drawing.Point(128, 114)
        Me.ftbBetaIncludeFolder.Name = "ftbBetaIncludeFolder"
        Me.ftbBetaIncludeFolder.ShowRelativePath = False
        Me.ftbBetaIncludeFolder.Size = New System.Drawing.Size(286, 20)
        Me.ftbBetaIncludeFolder.TabIndex = 10
        '
        'ftbReleaseIncludeFolder
        '
        Me.ftbReleaseIncludeFolder.BasePath = Nothing
        Me.ftbReleaseIncludeFolder.FolderPath = ""
        Me.ftbReleaseIncludeFolder.Location = New System.Drawing.Point(128, 87)
        Me.ftbReleaseIncludeFolder.Name = "ftbReleaseIncludeFolder"
        Me.ftbReleaseIncludeFolder.ShowRelativePath = False
        Me.ftbReleaseIncludeFolder.Size = New System.Drawing.Size(286, 20)
        Me.ftbReleaseIncludeFolder.TabIndex = 9
        '
        'ftbAutoItBeta
        '
        Me.ftbAutoItBeta.BasePath = Nothing
        Me.ftbAutoItBeta.DragDropFileFilter = Nothing
        Me.ftbAutoItBeta.FilePath = ""
        Me.ftbAutoItBeta.Filter = Nothing
        Me.ftbAutoItBeta.Location = New System.Drawing.Point(92, 61)
        Me.ftbAutoItBeta.Name = "ftbAutoItBeta"
        Me.ftbAutoItBeta.ShowRelativePath = False
        Me.ftbAutoItBeta.Size = New System.Drawing.Size(322, 20)
        Me.ftbAutoItBeta.TabIndex = 6
        '
        'ftbAutoItRelease
        '
        Me.ftbAutoItRelease.BasePath = Nothing
        Me.ftbAutoItRelease.DragDropFileFilter = Nothing
        Me.ftbAutoItRelease.FilePath = ""
        Me.ftbAutoItRelease.Filter = Nothing
        Me.ftbAutoItRelease.Location = New System.Drawing.Point(92, 35)
        Me.ftbAutoItRelease.Name = "ftbAutoItRelease"
        Me.ftbAutoItRelease.ShowRelativePath = False
        Me.ftbAutoItRelease.Size = New System.Drawing.Size(322, 20)
        Me.ftbAutoItRelease.TabIndex = 4
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(8, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(507, 262)
        Me.TabControl1.TabIndex = 12
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.chkDebugIncludeFiles)
        Me.TabPage1.Controls.Add(Me.lblAutoIt)
        Me.TabPage1.Controls.Add(Me.ftbSciTEInstallFolder)
        Me.TabPage1.Controls.Add(Me.ftbAutoItRelease)
        Me.TabPage1.Controls.Add(Me.ftbBetaIncludeFolder)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.ftbAutoItBeta)
        Me.TabPage1.Controls.Add(Me.ftbReleaseIncludeFolder)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(499, 236)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Debugger Settings"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txtCommandLineArguments)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(499, 236)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Script Settings"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtCommandLineArguments
        '
        Me.txtCommandLineArguments.Location = New System.Drawing.Point(145, 11)
        Me.txtCommandLineArguments.Name = "txtCommandLineArguments"
        Me.txtCommandLineArguments.Size = New System.Drawing.Size(348, 20)
        Me.txtCommandLineArguments.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 14)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Command Line Arguments:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.chkEnableAutomaticUpdates)
        Me.TabPage3.Controls.Add(Me.chkEnableCallTips)
        Me.TabPage3.Controls.Add(Me.chkEnableAutoComplete)
        Me.TabPage3.Controls.Add(Me.chkAutomaticTidy)
        Me.TabPage3.Controls.Add(Me.chkAutomaticContextChecking)
        Me.TabPage3.Controls.Add(Me.chkUseVSLexer)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(499, 236)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "IDE Settings"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'chkEnableAutomaticUpdates
        '
        Me.chkEnableAutomaticUpdates.AutoSize = True
        Me.chkEnableAutomaticUpdates.Location = New System.Drawing.Point(12, 128)
        Me.chkEnableAutomaticUpdates.Name = "chkEnableAutomaticUpdates"
        Me.chkEnableAutomaticUpdates.Size = New System.Drawing.Size(211, 17)
        Me.chkEnableAutomaticUpdates.TabIndex = 18
        Me.chkEnableAutomaticUpdates.Text = "Enable automatic checking for updates"
        Me.chkEnableAutomaticUpdates.UseVisualStyleBackColor = True
        '
        'chkEnableCallTips
        '
        Me.chkEnableCallTips.AutoSize = True
        Me.chkEnableCallTips.Location = New System.Drawing.Point(12, 105)
        Me.chkEnableCallTips.Name = "chkEnableCallTips"
        Me.chkEnableCallTips.Size = New System.Drawing.Size(99, 17)
        Me.chkEnableCallTips.TabIndex = 17
        Me.chkEnableCallTips.Text = "Enable CallTips"
        Me.chkEnableCallTips.UseVisualStyleBackColor = True
        '
        'chkEnableAutoComplete
        '
        Me.chkEnableAutoComplete.AutoSize = True
        Me.chkEnableAutoComplete.Location = New System.Drawing.Point(12, 82)
        Me.chkEnableAutoComplete.Name = "chkEnableAutoComplete"
        Me.chkEnableAutoComplete.Size = New System.Drawing.Size(128, 17)
        Me.chkEnableAutoComplete.TabIndex = 16
        Me.chkEnableAutoComplete.Text = "Enable AutoComplete"
        Me.chkEnableAutoComplete.UseVisualStyleBackColor = True
        '
        'chkAutomaticContextChecking
        '
        Me.chkAutomaticContextChecking.AutoSize = True
        Me.chkAutomaticContextChecking.Location = New System.Drawing.Point(12, 36)
        Me.chkAutomaticContextChecking.Name = "chkAutomaticContextChecking"
        Me.chkAutomaticContextChecking.Size = New System.Drawing.Size(160, 17)
        Me.chkAutomaticContextChecking.TabIndex = 15
        Me.chkAutomaticContextChecking.Text = "Automatic Context Checking"
        Me.chkAutomaticContextChecking.UseVisualStyleBackColor = True
        '
        'chkUseVSLexer
        '
        Me.chkUseVSLexer.AutoSize = True
        Me.chkUseVSLexer.Location = New System.Drawing.Point(12, 13)
        Me.chkUseVSLexer.Name = "chkUseVSLexer"
        Me.chkUseVSLexer.Size = New System.Drawing.Size(279, 17)
        Me.chkUseVSLexer.TabIndex = 14
        Me.chkUseVSLexer.Text = "Use VS styles instead of SciTE styles (requires restart)"
        Me.chkUseVSLexer.UseVisualStyleBackColor = True
        '
        'chkAutomaticTidy
        '
        Me.chkAutomaticTidy.AutoSize = True
        Me.chkAutomaticTidy.Location = New System.Drawing.Point(12, 59)
        Me.chkAutomaticTidy.Name = "chkAutomaticTidy"
        Me.chkAutomaticTidy.Size = New System.Drawing.Size(138, 17)
        Me.chkAutomaticTidy.TabIndex = 15
        Me.chkAutomaticTidy.Text = "Automatically Tidy code"
        Me.chkAutomaticTidy.UseVisualStyleBackColor = True
        '
        'frmOptions
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(530, 318)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmOptions"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Options"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents chkDebugIncludeFiles As System.Windows.Forms.CheckBox
    Friend WithEvents lblAutoIt As System.Windows.Forms.Label
    Friend WithEvents ftbAutoItRelease As FileTextbox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ftbAutoItBeta As FileTextbox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ftbReleaseIncludeFolder As FolderTextBox
    Friend WithEvents ftbBetaIncludeFolder As FolderTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ftbSciTEInstallFolder As FolderTextBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents txtCommandLineArguments As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents chkEnableAutoComplete As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutomaticContextChecking As System.Windows.Forms.CheckBox
    Friend WithEvents chkUseVSLexer As System.Windows.Forms.CheckBox
    Friend WithEvents chkEnableCallTips As System.Windows.Forms.CheckBox
    Friend WithEvents chkEnableAutomaticUpdates As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutomaticTidy As System.Windows.Forms.CheckBox

End Class
