Option Explicit On
Option Strict On
Option Compare Text

Imports WeifenLuo.WinFormsUI.Docking
Imports System.Text.RegularExpressions
Imports System.Xml
Imports System.IO

<System.Runtime.InteropServices.ComVisible(False)> Public Class frmToolChest
    Inherits DockContent

#Region " Variables "
    Public WordList() As String
#End Region

#Region " Base Class Events "

    Friend Sub UpdateForm()
        TreeView1.Nodes.Clear()
        Dim TempNode As Windows.Forms.TreeNode

        TreeView1.BeginUpdate()

        Dim nAutoItBase As Windows.Forms.TreeNode = Treeview1.Nodes.Add("AutoIt", "AutoIt", 1, 2)
        nAutoItBase.Tag = "AutoIt"
        Dim nFunctionsIncludeBase As Windows.Forms.TreeNode = nAutoItBase.Nodes.Add("Includes", "Includes", 1, 2)
        nFunctionsIncludeBase.Tag = "Includes"
        Dim nFunctionsMacrosBase As Windows.Forms.TreeNode = nAutoItBase.Nodes.Add("Macros", "Macros", 1, 2)
        nFunctionsMacrosBase.Tag = "Macros"
        Dim nFunctionsBase As Windows.Forms.TreeNode = nAutoItBase.Nodes.Add("Functions", "Functions", 1, 2)
        nFunctionsBase.Tag = "Functions"
        nAutoItBase.Expand()
        Dim nUDFFunctionsBase As Windows.Forms.TreeNode = TreeView1.Nodes.Add("UDF Functions", "UDF Functions", 1, 2)
        nUDFFunctionsBase.Tag = "UDF Functions"

        If Not WordList Is Nothing Then
            For Each Word As String In WordList

                If Word.StartsWith("#") Then
                    If Word.ToUpper.Contains(tbtFilter.Text.ToUpper) Then
                        TempNode = nFunctionsIncludeBase.Nodes.Add(Word, Word, 5, 5)
                        TempNode.Tag = Word
                    End If

                ElseIf Word.StartsWith("@") Then
                    If Word.ToUpper.Contains(tbtFilter.Text.ToUpper) Then
                        TempNode = nFunctionsMacrosBase.Nodes.Add(Word, Word, 4, 4)
                        TempNode.Tag = Word
                    End If

                ElseIf Word.StartsWith("_") Then
                    Dim sTempWordName As String = Word.Substring(0, Word.IndexOf("("))
                    Dim sTempWordArguments As String = Word.Substring(0, Word.IndexOf(")") + 1)
                    If sTempWordName.ToUpper.Contains(tbtFilter.Text.ToUpper) Then
                        TempNode = nUDFFunctionsBase.Nodes.Add(sTempWordName, sTempWordName, 3, 3)
                        TempNode.Tag = sTempWordArguments
                        TempNode.ToolTipText = Word
                    End If

                ElseIf Word.Contains("(") Then
                    Dim sTempWordName As String = Word.Substring(0, Word.IndexOf("("))
                    Dim sTempWordArguments As String = Word.Substring(0, Word.IndexOf(")") + 1)
                    If sTempWordName.ToUpper.Contains(tbtFilter.Text.ToUpper) Then
                        TempNode = nFunctionsBase.Nodes.Add(sTempWordName, sTempWordName, 3, 3)
                        TempNode.Tag = sTempWordArguments
                        TempNode.ToolTipText = Word
                    End If
                End If
            Next
        End If

        If tbtFilter.Text <> "" Then
            nAutoItBase.ExpandAll()
            nUDFFunctionsBase.ExpandAll()
        End If

        TreeView1.EndUpdate()

    End Sub

    Private Sub frmToolChest_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate

    End Sub

    Private Sub frmToolChest_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

    End Sub

    Private Sub frmToolChest_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveSettings()
    End Sub

    Private Sub frmToolChest_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'lvwFunctions.Dock = Windows.Forms.DockStyle.Fill

        LoadSettings()

        UpdateForm()
    End Sub

#End Region

#Region " Form Controls Event Handlers "

    Private Sub TreeView1_NodeMouseDoubleClick1(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles TreeView1.NodeMouseDoubleClick
        If frmMain.AnyActiveDocument Then
            If e.Node.Tag Is Nothing Then
                frmMain.ActiveDocument.Scintilla1.Selection.Text = e.Node.Text
            Else
                frmMain.ActiveDocument.Scintilla1.Selection.Text = e.Node.Tag.ToString
            End If
        End If
    End Sub

    Private Sub tbtFilter_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tbtFilter.TextChanged
        'Update the timer
        Timer1.Enabled = False
        Timer1.Enabled = True
    End Sub

    Private Sub tsbClearFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbClearFilter.Click
        tbtFilter.Text = ""
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        UpdateForm()
        Timer1.Enabled = False
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        'Treeview1.TreeNodeTextSource = twentynine0677.TreeNodeTextSources.XmlNodeName
        'Treeview1.SaveXmlToDisk("F:\Programming\VB.Net 2005 Projects\AutoIt Debugger\Source\AutoIt Debugger\bin\ToolChest.xml")
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        'Treeview1.TreeNodeTextSource = twentynine0677.TreeNodeTextSources.XmlNodeAttribute
        'Treeview1.XmlAttributeName = "name"
        'Treeview1.LoadXml("F:\Programming\VB.Net 2005 Projects\AutoIt Debugger\Source\AutoIt Debugger\bin\load.xml")
    End Sub

    Private Sub ToolStripButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton3.Click
        Dim MyXMLDoc As XmlDocument
        Dim MyXMLNode As XmlNode
        Dim MyXMLElement As XmlElement

        'MyXMLDoc = Treeview1.sourceXml
        'MyXMLElement = Treeview1.sourceXml.CreateElement("Test")
        'MyXMLDoc.DocumentElement.SelectSingleNode("sqlGroup").AppendChild(MyXMLElement)
    End Sub

    'Private Function Treeview1_onAddNode(ByVal xNode As System.Xml.XmlNode, ByVal tNode As System.Windows.Forms.TreeNode) As System.Windows.Forms.TreeNode Handles Treeview1.onAddNode
    '    If xNode.Name = "List" Then
    '        MsgBox(xNode.Value)
    '    End If
    'End Function
#End Region

#Region " Miscellaneous Code "

    Private Sub LoadSettings()

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")

        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        'tsbVariables.Checked = CBool(profile.GetValue("Tool Chest", "ShowVariables", "True"))
        'tsbFunctions.Checked = CBool(profile.GetValue("Tool Chest", "ShowFunctions", "True"))
        'tsbIncludeFiles.Checked = CBool(profile.GetValue("Tool Chest", "ShowIncludeFiles", "True"))
    End Sub

    Friend Sub SaveSettings()

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")

        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        'profile.SetValue("Tool Chest", "ShowVariables", tsbVariables.Checked)
        'profile.SetValue("Tool Chest", "ShowFunctions", tsbFunctions.Checked)
        'profile.SetValue("Tool Chest", "ShowIncludeFiles", tsbIncludeFiles.Checked)
    End Sub

#End Region

    Private Sub tsbHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbHelp.Click
        Dim sAutoItInstallFolder As String
        If frmMain.bUseAutoItBeta Then
            sAutoItInstallFolder = frmMain.sAutoItBetaInstallFolder
        Else
            sAutoItInstallFolder = frmMain.sAutoItReleaseInstallFolder
        End If

        Dim MyProcess As New Process
        MyProcess.StartInfo.FileName = Path.Combine(sAutoItInstallFolder, "AutoIt3Help.exe")
        MyProcess.StartInfo.Arguments = TreeView1.SelectedNode.Text
        MyProcess.Start()
    End Sub
End Class
