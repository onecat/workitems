﻿Imports System.IO
Imports System.Windows.Forms
Imports WeifenLuo.WinFormsUI
Imports WeifenLuo.WinFormsUI.Docking
Imports ScintillaNet

Public Class frmMain

#Region " Variables "

    Public WithEvents ChildForms As New clsChildFormCollection
    Public WithEvents MyRibbonMRU As New RibbonMRUManager

    Dim au3apiFilePath As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "au3.api")
    Dim au3usercalltipsapiFilePath As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "au3.user.calltips.api")
    Dim ToolChestEntriesFilePath As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "Tool Chest Entries.txt")

    Dim bDevelopmentMode As Boolean = True
    Dim bStepInto As Boolean
    Dim bRunning As Boolean
    'Dim bStepOver As Boolean
    Dim bPause As Boolean
    Friend bFinished As Boolean
    Dim iCurrentLine As Integer
    Dim sCurrentBreakpointFilepath As String
    Dim iStepOverBreakpointLine As Integer
    Dim sStepOverBreakpointFilepath As String
    Dim sAutoItCommandWindowName As String
    Friend MyCallTips As New List(Of String)
    Friend MyAutoCompleteWords As New List(Of String)
    Friend sAutoItBetaInstallFolder As String
    Friend sAutoItReleaseInstallFolder As String

    Friend WithEvents fWatch As New frmWatch
    Private WithEvents fTrace As New frmTrace
    Friend WithEvents fOutput As New frmOutput
    Friend WithEvents fTidy As New frmTidy
    Private WithEvents fErrorList As New frmErrorList
    Private WithEvents fVariables As New frmVariables
    Private WithEvents fFunctions As New frmFunctions
    Private WithEvents fIncludes As New frmIncludes
    Private WithEvents fToolChest As New frmToolChest

    'Creae Script ini file settings
    Friend bUseAutoItBeta As Boolean
    Friend bDebugFilesInIncludeLibrary As Boolean
    Friend bUseVSLexer As Boolean
    Friend bAutomaticContextChecking As Boolean
    Friend bAutomaticTidy As Boolean
    Friend bEnableAutoComplete As Boolean
    Friend bEnableCallTips As Boolean
    Friend sSciTEInstallFolder As String
    Friend sAutoItBetaExecutable As String
    Friend sAutoItReleaseExecutable As String
    Friend sReleaseIncludeFolder As String
    Friend sBetaIncludeFolder As String
    Friend EnableAutomaticUpdates As Boolean

#End Region

#Region " Base Class Events "

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.KeyPreview = True

        bStepInto = True
        bFinished = False

    End Sub

    Protected Overrides Sub Finalize()

        MyBase.Finalize()

        bFinished = True

    End Sub

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Save watch variables
        Dim sDebugINIFile As String = FileBeingDeduggedDocument.DebugIniFilepath

        If File.Exists(sDebugINIFile) Then
            'Read ini settings
            Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sDebugINIFile)
            profile.SetValue("Settings", "Watched_Variables", fWatch.CreateVariablesString())
        End If

        'Close all code windows
        For Each MyForm As frmChildForm In ChildForms
            Dim FormName As String = MyForm.Name
            MyForm.Close()
            'If Not IsNothing(MyForm) Then
            'e.Cancel = True
            'End If
            If ChildForms.Contains(FormName) Then
                e.Cancel = True
            End If
        Next

        'Do stuff if not cancelled
        If e.Cancel = False Then

            fVariables.SaveSettings()
            fFunctions.SaveSettings()
            fIncludes.SaveSettings()

            'Save Settings
            SaveSettings()

            If bDevelopmentMode Then
                ' Save the DockPanel settings
                Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "DockPanel.config")
                DockPanel1.SaveAsXml(configFile)
            Else
                ' Save the DockPanel settings
                Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "DockPanel_Debug.config")
                DockPanel1.SaveAsXml(configFile)
            End If

            'Indicate to the program to quit
            Dim bSendResult As Boolean
            bSendResult = SendMsg_Quit(sAutoItCommandWindowName & " AutoIt Debugger Command Window")
            If Not bSendResult Then
                ScriptFinished()
            End If
        End If
    End Sub

    Private Sub frmMain_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyValue = Keys.F5 Then
            ribHomeDebugStart_Click(Me, New EventArgs)

        ElseIf e.KeyValue = Keys.Escape Then
            'ribHomeDebugStart_Click(Me, New EventArgs)

        ElseIf Not e.Shift And e.KeyValue = Keys.F8 Then
            ribHomeDebugStepInto_Click(Me, New EventArgs)

        ElseIf e.Shift And e.KeyValue = Keys.F8 Then
            ribHomeDebugStepOver_Click(Me, New EventArgs)

        ElseIf e.Control And e.KeyValue = Keys.S Then
            ribHomeFileSave_Click(Me, New EventArgs)

        ElseIf e.Control And e.KeyValue = Keys.O Then
            ribHomeFileOpen_Click(Me, New EventArgs)
        End If

    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' Load the DockPanel settings 
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "DockPanel.config")
        If File.Exists(configFile) Then
            Dim m_deserializeDockContent As DeserializeDockContent

            m_deserializeDockContent = New DeserializeDockContent(AddressOf GetContentFromPersistString)
            DockPanel1.LoadFromXml(configFile, m_deserializeDockContent)
        Else
            ' Load a basic layout
            fTrace.Show(DockPanel1, DockState.DockBottom)
            fOutput.Show(DockPanel1, DockState.DockBottom)
            fTidy.Show(DockPanel1, DockState.DockBottom)
            fErrorList.Show(DockPanel1, DockState.DockBottom)
            fWatch.Show(DockPanel1, DockState.DockRight)
            fVariables.Show(DockPanel1, DockState.DockRight)
            fFunctions.Show(DockPanel1, DockState.DockRight)
            fIncludes.Show(DockPanel1, DockState.DockRight)
            fToolChest.Show(DockPanel1, DockState.DockRight)
        End If

        ' Load settings
        LoadSettings()

        'Select Case My.Application.CommandLineArgs.Count
        '    Case 0
        '        ribHomeFileNew_Click(Me, New EventArgs)
        '    Case 1
        '        OpenFile(My.Application.CommandLineArgs(0))
        'End Select

        Dim fileLineArray() As String = Nothing
        Dim fileLineArray2() As String = Nothing
        fileLineArray = System.IO.File.ReadAllLines(au3apiFilePath)
        fileLineArray2 = System.IO.File.ReadAllLines(au3usercalltipsapiFilePath)
        MyCallTips.AddRange(fileLineArray)
        MyCallTips.AddRange(fileLineArray2)
        MyCallTips.Sort()

        Dim lsTemp As New List(Of String)
        lsTemp.AddRange(fileLineArray)
        lsTemp.AddRange(fileLineArray2)
        lsTemp.Sort()

        For Each MyString As String In lsTemp
            If MyString.Contains("(") Then
                MyAutoCompleteWords.Add(MyString.Substring(0, MyString.IndexOf("(")).TrimEnd)
            Else
                MyAutoCompleteWords.Add(MyString.TrimEnd)
            End If
        Next

        Dim ToolChestEntriesArray() As String = Nothing
        ToolChestEntriesArray = System.IO.File.ReadAllLines(ToolChestEntriesFilePath)
        fToolChest.WordList = ToolChestEntriesArray
        fToolChest.UpdateForm()

        'Set status bar text
        sblCurrentLineNumber.Text = ""

        'Initialise the MRU
        MyRibbonMRU.Initialise(Me, Ribbon1.OrbDropDown)

    End Sub

    Private Sub frmMain_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Select Case My.Application.CommandLineArgs.Count
            Case 0
                ribHomeFileNew_Click(Me, New EventArgs)
            Case 1
                OpenFile(My.Application.CommandLineArgs(0))
        End Select
    End Sub

#End Region

#Region " Form Controls Event Handlers "

    Private Sub fVariables_ChangeVariable(ByVal VariableName As String, ByVal VariableValue As String) Handles fWatch.ChangeVariable
        Dim bSendResult As Boolean
        bSendResult = SendMsg_Variable(sAutoItCommandWindowName & " AutoIt Debugger Command Window", VariableName, VariableValue)
        If Not bSendResult Then
            ScriptFinished()
        End If
    End Sub

    Private Sub ChildForms_ChildFormClosed() Handles ChildForms.ChildFormClosed
        'Check if this is the file to be debugged
        If FileBeingDeduggedDocument() Is Nothing Then
            'Clear variables
            fWatch.DeleteAllVariables()
        End If
    End Sub

    Private Sub ChildForms_ChildFormHasChanged() Handles ChildForms.ChildFormHasChanged
        'Update forms as necessary
        UpdateForms()
    End Sub

    Private Sub ChildForms_LastChildFormClosed() Handles ChildForms.LastChildFormClosed
        'Closed last doc
        OrbMenuOpen.Enabled = True
        OrbMenuSave.Enabled = False
        OrbMenuReloadDoc.Enabled = False
        OrbMenuSaveAll.Enabled = False
        OrbMenuClose.Enabled = False

        Me.Text = "AutoIt Debugger"
    End Sub

    Private Sub DockPanel1_ActiveDocumentChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DockPanel1.ActiveDocumentChanged
        'Update forms as necessary
        UpdateForms()
    End Sub

    Private Sub DockPanel1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DockPanel1.DragDrop
        'Get the filename(s)
        Dim sDropFile As String
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop, True)

        'Use the first filename dropped
        sDropFile = files(0)

        OpenFile(sDropFile)
    End Sub

    Private Sub DockPanel1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DockPanel1.DragEnter
        'Check that a file or files are being dragged over the control
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            'Get the filename(s)
            Dim file() As String = e.Data.GetData(DataFormats.FileDrop, True)

            'Check the file types
            'Select Case UCase(Microsoft.VisualBasic.Right(file(0), 4))
            '    Case sDragDropFile.ToUpper
            e.Effect = DragDropEffects.Copy
            '    Case Else
            'e.Effect = DragDropEffects.None
            'End Select
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub MyRibbonMRU_MRUEntryClicked(ByVal MRUEntry As String) Handles MyRibbonMRU.MRUEntryClicked
        OpenFile(MRUEntry)
    End Sub

#End Region

#Region " Menu Events "

#Region " File Menu Item Events "

    Private Sub ribHomeFileOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrbMenuOpen.Click
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            OpenFile(OpenFileDialog1.FileName)
        End If
    End Sub

    Private Sub ribHomeFileSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrbMenuSave.Click, QATMenuSave.Click
        If AnyActiveDocument() Then
            If ActiveDocument.SaveFile() Then
                'Context Check the file
                If bAutomaticTidy Then
                    ribHomeToolsTidySource_Click(Me, New System.EventArgs)
                End If
                If bAutomaticContextChecking Then
                    ribHomeToolsContextCheck_Click(Me, New System.EventArgs)
                End If
            End If
        End If
    End Sub

    Private Sub ribHomeFileSaveAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrbMenuSaveAll.Click, QATMenuSaveAll.Click
        'Save all documents
        Dim MyDocument As frmDocument
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                MyDocument = CType(MyChildForm, frmDocument)
                MyDocument.SaveFile()
            End If
        Next
    End Sub

    Private Sub ribHomeFileClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrbMenuClose.Click
        If AnyActiveDocument() Then
            ActiveDocument.Close()
        End If
    End Sub

    Private Sub ribHomeFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrbOptionButtonExit.Click
        Me.Close()
    End Sub

    Private Sub ribHomeFileReloadDoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrbMenuReloadDoc.Click
        If AnyActiveDocument() Then
            'Reload the file
            ActiveDocument.ReloadFile()
        End If
    End Sub

    Private Sub ribHomeFileNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrmMenuNew.Click
        Dim MyDocument As New frmDocument
        'MyDocument.Name = "Untitled.au3"
        'ChildForms.Add(MyDocument)
        'MyDocument.AddFile(FilePath)
        MyDocument.Show(DockPanel1, DockState.Document)

        'Update ribbon
        OrbMenuOpen.Enabled = True
        OrbMenuSave.Enabled = True
        OrbMenuReloadDoc.Enabled = True
        OrbMenuSaveAll.Enabled = True
        OrbMenuClose.Enabled = True

    End Sub

#End Region

#Region " Edit Menu Item Events "

    'Private Sub mnuEditGoTo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Dim sResult As String = InputBox("Line number:", "Go To Line", "")
    '    If sResult <> "" Then
    '        Dim iLine As Integer
    '        'Dim iStartIndex As Integer
    '        iLine = CInt(sResult)

    '        If Not ActiveDocument() Is Nothing Then
    '            ActiveDocument.Scintilla1.Lines(iLine - 1).Goto()
    '        End If
    '        'fCode.GetVisibleListView.HighlightLine(iLine - 1).Selected = True
    '        'fCode.GetVisibleListView.EnsureVisible(iLine - 1)
    '        'fCode.GetVisibleListView.Focus()
    '    End If
    'End Sub

    Private Sub ribHomeEditGoto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeEditGoto.Click

        If AnyActiveDocument() Then
            ActiveDocument.Scintilla1.GoTo.ShowGoToDialog()
        End If
        'Dim sResult As String = InputBox("Line number:", "Go To Line", "")
        'If sResult <> "" Then
        '    Dim iLine As Integer
        '    'Dim iStartIndex As Integer
        '    iLine = CInt(sResult)

        '    If Not ActiveDocument() Is Nothing Then
        '        ActiveDocument.Scintilla1.Lines(iLine - 1).Goto()
        '    End If
        '    'fCode.GetVisibleListView.HighlightLine(iLine - 1).Selected = True
        '    'fCode.GetVisibleListView.EnsureVisible(iLine - 1)
        '    'fCode.GetVisibleListView.Focus()
        'End If
    End Sub

    Private Sub ribHomeEditFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeEditFind.Click
        If AnyActiveDocument() Then
            ActiveDocument.Scintilla1.FindReplace.ShowFind()
        End If
    End Sub

    Private Sub ribHomeEditReplace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeEditReplace.Click
        If AnyActiveDocument() Then
            ActiveDocument.Scintilla1.FindReplace.ShowReplace()
        End If
    End Sub

    Private Sub ribHomeEditComment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeEditComment.Click
        If AnyActiveDocument() Then
            ActiveDocument.Scintilla1.Commands.Execute(BindableCommand.LineComment)
        End If
    End Sub

    Private Sub ribHomeEditUnComment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeEditUnComment.Click
        If AnyActiveDocument() Then
            ActiveDocument.Scintilla1.Commands.Execute(BindableCommand.LineUncomment)
        End If
    End Sub

#End Region

#Region " View Menu Item Events "

    Private Sub ribHomeViewNavBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeViewNavBack.Click
        If AnyActiveDocument() Then
            ActiveDocument.Scintilla1.DocumentNavigation.NavigateBackward()
        End If
    End Sub

    Private Sub ribHomeViewNavFwd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeViewNavFwd.Click
        If AnyActiveDocument() Then
            ActiveDocument.Scintilla1.DocumentNavigation.NavigateForward()
        End If
    End Sub

    Private Sub ribHomeViewUserCallTips_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeViewUserCallTips.Click
        OpenFile(au3usercalltipsapiFilePath)
    End Sub

#End Region

#Region " Debug Menu Item Events "

    'Private Sub mnuDebugStartDebugging_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    tsbRun_Click(Me, New EventArgs)

    'End Sub

    'Private Sub mnuDebugStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    tsbStop_Click(Me, New EventArgs)

    'End Sub

    'Private Sub mnuDebugStepInto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    tsbStepInto_Click(Me, New EventArgs)

    'End Sub

    'Private Sub mnuDebugStepOver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    tsbStepOver_Click(Me, New EventArgs)

    'End Sub


    Private Sub ribHomeDebugStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeDebugStart.Click
        ' Clear variable values
        fWatch.MyTree.ClearAllChangeStatusFlags()

        If Not bRunning Then
            RunScript()
            bRunning = True
            bStepInto = False
        Else
            bRunning = True
            bStepInto = False
            'bStepOver = False
            bPause = False

            Dim bSendResult As Boolean
            bSendResult = SendMsg_UnPause(sAutoItCommandWindowName & " AutoIt Debugger Command Window")
            If Not bSendResult Then
                ScriptFinished()
            End If
        End If
    End Sub

    Private Sub ribHomeDebugStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeDebugStop.Click
        'Indicate to the program to quit
        SendMsg_Quit(sAutoItCommandWindowName & " AutoIt Debugger Command Window")

        ScriptFinished()
    End Sub

    Private Sub ribHomeDebugStepInto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeDebugStepInto.Click
        ' Clear variable values
        fWatch.MyTree.ClearAllChangeStatusFlags()

        If Not bRunning Then
            RunScript()
            bRunning = True
            bStepInto = True
        Else
            bRunning = True
            bStepInto = True
            'bStepOver = False
            bPause = False

            Dim bSendResult As Boolean
            bSendResult = SendMsg_UnPause(sAutoItCommandWindowName & " AutoIt Debugger Command Window")
            If Not bSendResult Then
                ScriptFinished()
            End If
        End If
    End Sub

    Private Sub ribHomeDebugStepOver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeDebugStepOver.Click
        ' Clear variable values
        fWatch.MyTree.ClearAllChangeStatusFlags()

        If Not bRunning Then
            RunScript()
            bRunning = True
            bStepInto = False
        Else
            bRunning = True
            bStepInto = False
            'bStepOver = False
            bPause = False

            Dim bSendResult As Boolean
            bSendResult = SendMsg_UnPause(sAutoItCommandWindowName & " AutoIt Debugger Command Window")
            If Not bSendResult Then
                ScriptFinished()
            End If
        End If

        iStepOverBreakpointLine = iCurrentLine
        sStepOverBreakpointFilepath = sCurrentBreakpointFilepath
    End Sub

#End Region

#Region " Tools Menu Item Events "

    Private Sub ribHomeToolsRelease_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsRelease.Click
        bUseAutoItBeta = False
        ribHomeToolsRelease.Checked = True
        ribHomeToolsBeta.Checked = False
        sblAutoItVersion.Text = "Production AutoIt"

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")
        'Save INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        profile.SetValue("Settings", "UseAutoItBeta", bUseAutoItBeta)
    End Sub

    Private Sub ribHomeToolsBeta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsBeta.Click
        bUseAutoItBeta = True
        ribHomeToolsRelease.Checked = False
        ribHomeToolsBeta.Checked = True
        sblAutoItVersion.Text = "Beta AutoIt"

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")
        'Save INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        profile.SetValue("Settings", "UseAutoItBeta", bUseAutoItBeta)

    End Sub

    Private Sub ribHomeToolsOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrbOptionButtonOptions.Click
        Dim fOptions As New frmOptions
        Dim DebugConfigFile As String
        Dim DebugINIProfile As AMS.Profile.Ini

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")
        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        fOptions.chkDebugIncludeFiles.Checked = profile.GetValue("Settings", "DebugFilesInIncludeLibrary", False)
        fOptions.ftbAutoItRelease.FilePath = profile.GetValue("Settings", "AutoItReleaseExecutable", "..\AutoIt3.exe")
        fOptions.ftbAutoItBeta.FilePath = profile.GetValue("Settings", "AutoItBetaExecutable", "..\Beta\AutoIt3.exe")
        fOptions.ftbReleaseIncludeFolder.FolderPath = profile.GetValue("Settings", "ReleaseIncludeFolder", "..\Include")
        fOptions.ftbBetaIncludeFolder.FolderPath = profile.GetValue("Settings", "BetaIncludeFolder", "..\beta\Include")
        fOptions.ftbSciTEInstallFolder.FolderPath = profile.GetValue("Settings", "SciTEInstallFolder", "..\SciTE")
        fOptions.chkUseVSLexer.Checked = profile.GetValue("Settings", "UseVSLexer", False)
        fOptions.chkAutomaticContextChecking.Checked = profile.GetValue("Settings", "AutomaticContextChecking", False)
        fOptions.chkAutomaticTidy.Checked = profile.GetValue("Settings", "AutomaticTidy", False)
        fOptions.chkEnableAutoComplete.Checked = profile.GetValue("Settings", "EnableAutoComplete", True)
        fOptions.chkEnableCallTips.Checked = profile.GetValue("Settings", "EnableCallTips", True)
        fOptions.chkEnableAutomaticUpdates.Checked = profile.GetValue("Settings", "EnableAutomaticUpdates", True)

        If ActiveDocumentSaved() Then
            DebugConfigFile = ActiveDocument.DebugIniFilepath
            DebugINIProfile = New AMS.Profile.Ini(DebugConfigFile)

            'Debug ini
            fOptions.txtCommandLineArguments.Text = DebugINIProfile.GetValue("Settings", "CommandLineArguments", "")
        End If

        If fOptions.ShowDialog = Windows.Forms.DialogResult.OK Then
            'Perform actions on change
            profile.SetValue("Settings", "DebugFilesInIncludeLibrary", fOptions.chkDebugIncludeFiles.Checked)
            profile.SetValue("Settings", "AutoItReleaseExecutable", fOptions.ftbAutoItRelease.FilePath)
            profile.SetValue("Settings", "AutoItBetaExecutable", fOptions.ftbAutoItBeta.FilePath)
            profile.SetValue("Settings", "ReleaseIncludeFolder", fOptions.ftbReleaseIncludeFolder.FolderPath)
            profile.SetValue("Settings", "BetaIncludeFolder", fOptions.ftbBetaIncludeFolder.FolderPath)
            profile.SetValue("Settings", "SciTEInstallFolder", fOptions.ftbSciTEInstallFolder.FolderPath)
            profile.SetValue("Settings", "UseVSLexer", fOptions.chkUseVSLexer.Checked)
            profile.SetValue("Settings", "AutomaticContextChecking", fOptions.chkAutomaticContextChecking.Checked)
            profile.SetValue("Settings", "AutomaticTidy", fOptions.chkAutomaticTidy.Checked)
            profile.SetValue("Settings", "EnableAutoComplete", fOptions.chkEnableAutoComplete.Checked)
            profile.SetValue("Settings", "EnableCallTips", fOptions.chkEnableCallTips.Checked)
            profile.SetValue("Settings", "EnableAutomaticUpdates", fOptions.chkEnableAutomaticUpdates.Checked)

            If ActiveDocumentSaved() Then
                'Debug ini
                DebugINIProfile.SetValue("Settings", "CommandLineArguments", fOptions.txtCommandLineArguments.Text)
            End If

            'Set values in the program
            sSciTEInstallFolder = Path.GetFullPath(Path.Combine(Application.StartupPath, fOptions.ftbSciTEInstallFolder.FolderPath))
            sAutoItBetaExecutable = Path.GetFullPath(Path.Combine(Application.StartupPath, fOptions.ftbAutoItBeta.FilePath))
            sAutoItReleaseExecutable = Path.GetFullPath(Path.Combine(Application.StartupPath, fOptions.ftbAutoItRelease.FilePath))
            sAutoItBetaInstallFolder = New IO.FileInfo(sAutoItBetaExecutable).DirectoryName
            sAutoItReleaseInstallFolder = New IO.FileInfo(sAutoItReleaseExecutable).DirectoryName
            bAutomaticContextChecking = fOptions.chkAutomaticContextChecking.Checked
            bAutomaticTidy = fOptions.chkAutomaticTidy.Checked
            bEnableAutoComplete = fOptions.chkEnableAutoComplete.Checked
            bEnableCallTips = fOptions.chkEnableCallTips.Checked
            EnableAutomaticUpdates = fOptions.chkEnableAutomaticUpdates.Checked

            If AnyActiveDocument() Then
                'Set commandline argument
                ActiveDocument.CommandLineArgument = fOptions.txtCommandLineArguments.Text
            End If
        End If
    End Sub

    Private Sub ribHomeToolsContextCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsContextCheck.Click
        If ActiveDocumentSaved() Then
            'Only context check au3 files
            If ActiveDocument.DocumentPath.ToUpper.EndsWith("AU3") Then
                Dim sAutoItInstallFolder As String
                If bUseAutoItBeta Then
                    sAutoItInstallFolder = sAutoItBetaInstallFolder
                Else
                    sAutoItInstallFolder = sAutoItReleaseInstallFolder
                End If
                Dim sFilename As String = ActiveDocument.DocumentPath

                'Save the file
                ActiveDocument.SaveFile()

                'Set the output window
                fErrorList.ClearText()
                fErrorList.Show()

                Dim sProcessFilename As String = Path.Combine(sAutoItInstallFolder, "Au3Check.exe")
                If Not File.Exists(sProcessFilename) Then
                    MsgBox("The following file does not exist. Check all paths in the program options." & _
                        vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                    Exit Sub
                End If
                Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
                MyProc.sortProcess.StartInfo.FileName = sProcessFilename
                'MyProc.sortProcess.StartInfo.FileName = "C:\Program Files\AutoIt3\SciTE\AutoIt3Wrapper\AutoIt3Wrapper.exe"
                MyProc.sortProcess.StartInfo.Arguments = Chr(34) & sFilename & Chr(34)
                MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
                MyProc.RunProcess()

                'Clear all markers on all documents
                Dim MyDocument As frmDocument
                For Each MyChildForm As frmChildForm In ChildForms
                    If TypeOf (MyChildForm) Is frmDocument Then
                        MyDocument = CType(MyChildForm, frmDocument)
                        MyDocument.Scintilla1.Markers.DeleteAll(1)
                    End If
                Next

                fErrorList.WriteStringBuilder(MyProc.sortOutput)
                fErrorList.ScrollToTop()
            End If
        End If
    End Sub

    Private Sub ribHomeToolsTidySource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsTidySource.Click
        If ActiveDocumentSaved() Then
            Dim sFilename As String = ActiveDocument.DocumentPath

            'Save the file
            ActiveDocument.SaveFile()
            ActiveDocument.WatchForChanges = False

            'Clear the output window
            fTidy.Show()
            fTidy.ClearText()

            Dim sProcessFilename As String = Path.Combine(sSciTEInstallFolder, "Tidy\Tidy.exe")
            If Not File.Exists(sProcessFilename) Then
                MsgBox("The following file does not exist. Check all paths in the program options." & _
                    vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                Exit Sub
            End If
            Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
            MyProc.sortProcess.StartInfo.FileName = sProcessFilename
            MyProc.sortProcess.StartInfo.Arguments = Chr(34) & sFilename & Chr(34)
            MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            MyProc.RunProcess()

            fTidy.WriteStringBuilder(MyProc.sortOutput)

            'Reload the file
            ActiveDocument.ReloadFile()
            ActiveDocument.WatchForChanges = True
        End If
    End Sub

    Private Sub ribHomeToolsOpenInSciTE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsOpenInSciTE.Click
        If ActiveDocumentSaved() Then
            'Save the file
            ActiveDocument.SaveFile()

            'Set the output window
            fOutput.Show()
            fOutput.ClearText()
            fOutput.OutputType = frmOutput.eOutputType.General

            Dim sProcessFilename As String = Path.Combine(sSciTEInstallFolder, "SciTE.exe")
            If Not File.Exists(sProcessFilename) Then
                MsgBox("The following file does not exist. Check all paths in the program options." & _
                    vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                Exit Sub
            End If
            Dim MyProcess As New Process
            MyProcess.StartInfo.FileName = sProcessFilename
            MyProcess.StartInfo.Arguments = """" & ActiveDocument.DocumentPath & """"
            MyProcess.Start()
        End If
    End Sub

    Private Sub ribHomeToolsExplore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsExplore.Click
        If ActiveDocumentSaved() Then
            Dim sFilename As String = ActiveDocument.DocumentPath

            If sFilename = "" Then Exit Sub

            Dim MyFileInfo As New FileInfo(sFilename)
            Dim MyFolder As String = MyFileInfo.DirectoryName

            Dim MyProc As New Process
            MyProc.StartInfo.FileName = MyFolder
            MyProc.StartInfo.Verb = "Explore"
            MyProc.StartInfo.UseShellExecute = True
            MyProc.Start()

        End If
    End Sub

    Private Sub ribHomeToolsRunScript_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsRunScript.Click
        If ActiveDocumentSaved() Then
            Dim sAutoItInstallFolder As String
            If bUseAutoItBeta Then
                sAutoItInstallFolder = sAutoItBetaInstallFolder
            Else
                sAutoItInstallFolder = sAutoItReleaseInstallFolder
            End If
            Dim sFilename As String = ActiveDocument.DocumentPath

            'Save the file
            ActiveDocument.SaveFile()

            'Set the output window
            fOutput.Show()
            fOutput.ClearText()
            fOutput.OutputType = frmOutput.eOutputType.General

            Dim sProcessFilename As String = Path.Combine(sAutoItInstallFolder, "AutoIt3.exe")
            If Not File.Exists(sProcessFilename) Then
                MsgBox("The following file does not exist. Check all paths in the program options." & _
                    vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                Exit Sub
            End If

            Dim MyProc As New Process
            MyProc.StartInfo.FileName = sProcessFilename
            MyProc.StartInfo.Arguments = Chr(34) & sFilename & Chr(34) & " " & ActiveDocument.CommandLineArgument
            MyProc.Start()

        End If
    End Sub

    Private Sub ribHomeToolsCompile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsCompile.Click
        If ActiveDocumentSaved() Then
            Dim sAutoItInstallFolder As String
            If bUseAutoItBeta Then
                sAutoItInstallFolder = sAutoItBetaInstallFolder
            Else
                sAutoItInstallFolder = sAutoItReleaseInstallFolder
            End If
            Dim sFilename As String = ActiveDocument.DocumentPath

            'Save the file
            ActiveDocument.SaveFile()

            'Set the output window
            fOutput.Show()
            fOutput.ClearText()
            fOutput.OutputType = frmOutput.eOutputType.General

            Dim sProcessFilename As String = Path.Combine(sAutoItInstallFolder, "Aut2Exe\Aut2Exe.exe")
            If Not File.Exists(sProcessFilename) Then
                MsgBox("The following file does not exist. Check all paths in the program options." & _
                    vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                Exit Sub
            End If
            Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
            MyProc.sortProcess.StartInfo.FileName = sProcessFilename
            MyProc.sortProcess.StartInfo.Arguments = "/in " & Chr(34) & sFilename & Chr(34)
            MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden

            'Write command
            fOutput.WriteLine(">" & MyProc.sortProcess.StartInfo.FileName & " " & MyProc.sortProcess.StartInfo.Arguments)

            MyProc.RunProcess()

            'Write to the output window
            fOutput.WriteStringBuilder(MyProc.sortOutput)
            fOutput.WriteLine("Finished")
        End If
    End Sub

    Private Sub ribHomeToolsKoda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsKoda.Click
        If ActiveDocumentSaved() Then
            Dim sFilename As String = ActiveDocument.DocumentPath

            'Save the file
            ActiveDocument.SaveFile()

            'Set the output window
            fOutput.Show()
            fOutput.ClearText()
            fOutput.OutputType = frmOutput.eOutputType.General

            Dim sProcessFilename As String = Path.Combine(sSciTEInstallFolder, "Koda\FD.exe")
            If Not File.Exists(sProcessFilename) Then
                MsgBox("The following file does not exist. Check all paths in the program options." & _
                    vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                Exit Sub
            End If

            'Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
            'MyProc.sortProcess.StartInfo.FileName = sProcessFilename
            'MyProc.sortProcess.StartInfo.Arguments = Chr(34) & sFilename & Chr(34)
            'MyProc.RunProcess()

            Dim MyProc As New Process
            MyProc.StartInfo.FileName = sProcessFilename
            MyProc.StartInfo.Arguments = Chr(34) & sFilename & Chr(34)
            MyProc.Start()

            'fOutput.WriteStringBuilder(MyProc.sortOutput)

            'Reload the file
            'ActiveDocument.ReloadFile()
        End If
    End Sub

    Private Sub ribHomeToolsCodeWizard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsCodeWizard.Click
        If ActiveDocumentSaved() Then
            Dim sFilename As String = ActiveDocument.DocumentPath

            'Save the file
            ActiveDocument.SaveFile()

            'Set the output window
            fOutput.Show()
            fOutput.ClearText()
            fOutput.OutputType = frmOutput.eOutputType.General

            Dim sProcessFilename As String = Path.Combine(sSciTEInstallFolder, "CodeWizard\CodeWizard.exe")
            'Dim sProcessFilename As String = Path.Combine(sSciTEInstallFolder, "ACNWrapper\ACNWrapper.exe")
            If Not File.Exists(sProcessFilename) Then
                MsgBox("The following file does not exist. Check all paths in the program options." & _
                    vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                Exit Sub
            End If
            Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
            MyProc.sortProcess.StartInfo.FileName = sProcessFilename
            MyProc.sortProcess.StartInfo.Arguments = "/Out"
            'MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            MyProc.RunProcess()

            'Paste the std output
            ActiveDocument.Scintilla1.Selection.Text = MyProc.sortOutput.ToString
        End If
    End Sub

    Private Sub ribHomeToolsCompileWithOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHomeToolsCompileWithOptions.Click
        Dim sArguments As String

        If ActiveDocumentSaved() Then
            Dim sFilename As String = ActiveDocument.DocumentPath
            sArguments = "/in " & Chr(34) & sFilename & Chr(34)

            Dim sAutoItInstallFolder As String
            If bUseAutoItBeta Then
                sAutoItInstallFolder = sAutoItBetaInstallFolder
                sArguments = sArguments & " /beta"
                sArguments = sArguments & " /Autoit3Dir " & Chr(34) & sAutoItInstallFolder & Chr(34)
            Else
                sAutoItInstallFolder = sAutoItReleaseInstallFolder
                sArguments = sArguments & " /prod"
                sArguments = sArguments & " /Autoit3Dir " & Chr(34) & sAutoItInstallFolder & Chr(34)
            End If

            'Save the file
            ActiveDocument.SaveFile()

            'Set the output window
            fOutput.Show()
            fOutput.ClearText()
            fOutput.OutputType = frmOutput.eOutputType.General

            Dim sProcessFilename As String = Path.Combine(sSciTEInstallFolder, "ACNWrapper\ACNWrapper.exe")
            'Dim sProcessFilename As String = Path.Combine(sSciTEInstallFolder, "AutoIt3Wrapper\AutoIt3Wrapper.exe")
            If Not File.Exists(sProcessFilename) Then
                MsgBox("The following file does not exist. Check all paths in the program options." & _
                    vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
                Exit Sub
            End If
            Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
            MyProc.sortProcess.StartInfo.FileName = sProcessFilename
            MyProc.sortProcess.StartInfo.Arguments = sArguments
            MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden

            'Write command
            fOutput.WriteLine(">" & MyProc.sortProcess.StartInfo.FileName & " " & MyProc.sortProcess.StartInfo.Arguments)

            MyProc.RunProcess()

            'Write to the output window
            fOutput.WriteStringBuilder(MyProc.sortOutput)
        End If
    End Sub

#End Region

#Region " Window Menu Item Events "

    Private Sub ribWindowWatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowWatch.Click
        fWatch.Show(DockPanel1)
    End Sub

    Private Sub ribWindowWindowTrace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowWindowTrace.Click
        fTrace.Show(DockPanel1)
    End Sub

    Private Sub ribWindowWindowOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowWindowOutput.Click
        fOutput.Show(DockPanel1)
    End Sub

    Private Sub ribWindowWindowWeb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowWindowWeb.Click

    End Sub

    Private Sub ribWindowVariables_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowVariables.Click
        fVariables.Show(DockPanel1)
    End Sub

    Private Sub ribWindowWindowErrorList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowWindowErrorList.Click
        fErrorList.Show(DockPanel1)
    End Sub

    Private Sub ribWindowToolChest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowToolChest.Click
        fToolChest.Show(DockPanel1)
    End Sub

#End Region

#Region " Help Menu Item Events "

    Private Sub ribHelpForum_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHelpForum.Click
        Dim MyProc As New Process
        MyProc.StartInfo.FileName = "http://thefoolonthehill.net/phpBB3/viewforum.php?f=1"
        MyProc.StartInfo.UseShellExecute = True
        MyProc.Start()
    End Sub

    Private Sub ribHelpContents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHelpContents.Click
        ' Show the contents of the help file.
        Help.ShowHelp(Me, hlpMain.HelpNamespace)

    End Sub

    Private Sub ribHelpIndex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHelpIndex.Click
        ' Show index of the help file.
        Help.ShowHelpIndex(Me, hlpMain.HelpNamespace)

    End Sub

    Private Sub ribHelpSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHelpSearch.Click
        ' Show the search tab of the help file.
        Help.ShowHelp(Me, hlpMain.HelpNamespace, HelpNavigator.Find, "")

    End Sub

    Private Sub ribHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHelpAbout.Click
        Dim fAbout As New frmAbout
        fAbout.ShowDialog()

    End Sub

    Private Sub ribHelpReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribHelpReport.Click

        Dim ErrorHandler As New ErrorHandler.ErrorHandler
        Dim MyException As New Exception("I have something to report.")
        MyException.Source = My.Application.Info.ProductName
        ErrorHandler.NewError(MyException, False, My.Application.Info.Version.ToString)

    End Sub

    'Private Sub mnuHelpContents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    ' Show the contents of the help file.
    '    Help.ShowHelp(Me, hlpMain.HelpNamespace)

    'End Sub

    'Private Sub mnuHelpIndex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    ' Show index of the help file.
    '    Help.ShowHelpIndex(Me, hlpMain.HelpNamespace)

    'End Sub

    'Private Sub mnuHelpSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    ' Show the search tab of the help file.
    '    Help.ShowHelp(Me, hlpMain.HelpNamespace, HelpNavigator.Find, "")

    'End Sub

    'Private Sub mnuHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    Dim fAbout As New frmAbout
    '    fAbout.ShowDialog()

    'End Sub

#End Region

#Region " WIP Item Events "

    'Private Sub ribWIPMainContextCheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    'End Sub

    'Private Sub ribWIPMainTidy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If AnyActiveDocument() Then
    '        Dim sFilename As String = ActiveDocument.Filepath

    '        'Save the file
    '        ActiveDocument.SaveFile()

    '        Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
    '        MyProc.sortProcess.StartInfo.FileName = Path.Combine(sSciTEInstallFolder, "Tidy\Tidy.exe")
    '        MyProc.sortProcess.StartInfo.Arguments = Chr(34) & sFilename & Chr(34)
    '        MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
    '        MyProc.RunProcess()

    '        'Clear the output window
    '        fOutput.Show()
    '        fOutput.ClearText()
    '        fOutput.OutputType = frmOutput.eOutputType.General
    '        fOutput.WriteStringBuilder(MyProc.sortOutput)

    '        'Reload the file
    '        ActiveDocument.ReloadFile()
    '    End If
    'End Sub

    'Private Sub ribWIPWIPSciTE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If AnyActiveDocument() Then
    '        'Save the file
    '        ActiveDocument.SaveFile()

    '        Dim MyProcess As New Process
    '        MyProcess.StartInfo.FileName = Path.Combine(sSciTEInstallFolder, "SciTE.exe")
    '        MyProcess.StartInfo.Arguments = """" & ActiveDocument.Filepath & """"
    '        MyProcess.Start()
    '    End If
    'End Sub

    'Private Sub ribWIPRunScript_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If AnyActiveDocument() Then
    '        Dim sAutoItInstallFolder As String
    '        If bUseAutoItBeta Then
    '            sAutoItInstallFolder = sAutoItBetaInstallFolder
    '        Else
    '            sAutoItInstallFolder = sAutoItReleaseInstallFolder
    '        End If
    '        Dim sFilename As String = ActiveDocument.Filepath

    '        'Save the file
    '        ActiveDocument.SaveFile()

    '        Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
    '        MyProc.sortProcess.StartInfo.FileName = Path.Combine(sAutoItInstallFolder, "AutoIt3.exe")
    '        MyProc.sortProcess.StartInfo.Arguments = Chr(34) & sFilename & Chr(34)
    '        MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
    '        MyProc.RunProcess()

    '        'Dim MyProc As New ProcessAsyncStreamSamples.ProcessAsyncOutputRedirection
    '        'MyProc.sortProcess.StartInfo.FileName = Path.Combine(sSciTEInstallFolder, "AutoIt3Wrapper\AutoIt3Wrapper.exe")
    '        'MyProc.sortProcess.StartInfo.Arguments = " /run /prod /ErrorStdOut /in " & Chr(34) & sFilename & Chr(34) & " /autoit3dir " & Chr(34) & sAutoItInstallFolder & Chr(34) & " /UserParams"
    '        'MyProc.sortProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
    '        'MyProc.RunProcess()

    '        'Clear the output window
    '        fOutput.Show()
    '        fOutput.ClearText()
    '        fOutput.OutputType = frmOutput.eOutputType.General
    '        fOutput.WriteStringBuilder(MyProc.sortOutput)
    '    End If
    'End Sub

#End Region

#End Region

#Region " Miscellaneous Code "

    ''' <summary>
    ''' Return the active 'Document' type dock panel/window
    ''' </summary>
    ''' <returns>The active form that inherits from frmChildForm</returns>
    ''' <remarks></remarks>
    Friend Function ActiveDocument() As frmDocument
        If TypeOf (DockPanel1.ActiveDocument) Is frmDocument Then
            Return CType(DockPanel1.ActiveDocument, frmDocument)
        Else
            Return Nothing
        End If
    End Function

    ''' <summary>
    ''' Returns the 'Document' of the file being debugged (as shown in the program title)
    ''' </summary>
    ''' <returns>The active form that inherits from frmChildForm</returns>
    ''' <remarks></remarks>
    Friend Function FileBeingDeduggedDocument() As frmDocument
        For Each MyDocument As IDockContent In DockPanel1.Documents
            If TypeOf (MyDocument) Is frmDocument Then
                Dim TempDocument As frmDocument = CType(MyDocument, frmDocument)
                If TempDocument.DocumentPath = sAutoItCommandWindowName Then
                    Return TempDocument
                End If
            End If
        Next
        Return Nothing
    End Function

    ''' <summary>
    ''' Return the whether there is an active document
    ''' </summary>
    ''' <returns>True if a document exists, otherwise false</returns>
    ''' <remarks></remarks>
    Friend Function AnyActiveDocument() As Boolean
        If ActiveDocument() Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    ''' <summary>
    ''' Return whether there is an active document and if it has been saved
    ''' </summary>
    ''' <returns>True if a document exists, otherwise false</returns>
    ''' <remarks></remarks>
    Friend Function ActiveDocumentSaved() As Boolean
        If ActiveDocument() Is Nothing Then
            Return False
        Else
            If ActiveDocument.SaveFile() Then
                Return True
            Else
                Return False
            End If
        End If
    End Function

    ''' <summary>
    ''' Return the whether any document is unsaved
    ''' </summary>
    ''' <returns>True if an unsaved document exists, otherwise false</returns>
    ''' <remarks></remarks>
    Friend Function AnyDocumentUnSaved() As Boolean
        'Set default to all saved
        AnyDocumentUnSaved = False

        If ActiveDocument() Is Nothing Then
            Return True
        Else
            Dim MyDocument As frmDocument
            For Each MyChildForm As frmChildForm In ChildForms
                If TypeOf (MyChildForm) Is frmDocument Then
                    MyDocument = CType(MyChildForm, frmDocument)
                    If Not ActiveDocument.SaveFile() Then
                        Return True
                    End If
                End If
            Next
        End If
    End Function

    Friend Sub OpenFile(ByVal FilePath As String, Optional ByVal bDisableAutomaticChecking As Boolean = False)
        Static sFile As String

        MyRibbonMRU.AddFile(FilePath)

        'Update ribbon
        OrbMenuOpen.Enabled = True
        OrbMenuSave.Enabled = True
        OrbMenuReloadDoc.Enabled = True
        OrbMenuSaveAll.Enabled = True
        OrbMenuClose.Enabled = True

        If Not ChildForms.ContainsKey(FilePath) Then
            Dim MyDocument As New frmDocument
            MyDocument.Name = FilePath
            'ChildForms.Add(MyDocument)
            MyDocument.AddFile(FilePath)
            MyDocument.Show(DockPanel1, DockState.Document)
        Else
            'Show the form
            'ChildForms(FilePath).Activate()
        End If

        'Context Check the file
        If bAutomaticContextChecking And Not bDisableAutomaticChecking Then
            ribHomeToolsContextCheck_Click(Me, New System.EventArgs)
        End If
        'Tidy Check the file
        If bAutomaticTidy And Not bDisableAutomaticChecking Then
            ribHomeToolsTidySource_Click(Me, New System.EventArgs)
        End If

        'If this is the first file, store the file details
        If sFile = "" Then
            sFile = FilePath

            'Set the AutoIt Command Window name
            If sAutoItCommandWindowName = "" Then
                sAutoItCommandWindowName = FilePath
                Me.Text = "AutoIt Debugger - " & sAutoItCommandWindowName
            End If

            'Load variables
            If Not FileBeingDeduggedDocument() Is Nothing Then
                Dim sDebugINIFile As String = FileBeingDeduggedDocument.DebugIniFilepath

                If File.Exists(sDebugINIFile) Then
                    'Read ini settings
                    Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sDebugINIFile)
                    fWatch.LoadVariablesFromString(profile.GetValue("Settings", "Watched_Variables", ""))
                End If
            End If
        End If

        bPause = True
    End Sub

    Friend Sub LoadFile(ByVal FilePath As String)

        If Not ChildForms.ContainsKey(FilePath) Then
            Dim MyDocument As New frmDocument
            MyDocument.Name = FilePath
            'ChildForms.Add(MyDocument)
            MyDocument.AddFile(FilePath)
            MyDocument.Show(DockPanel1, DockState.Document)
        Else
            'Show the form
            ChildForms(FilePath).Activate()
        End If

        bPause = True

        'Continue to next real instruction
        Dim bSendResult As Boolean
        bSendResult = SendMsg_UnPause(sAutoItCommandWindowName & " AutoIt Debugger Command Window")
        If Not bSendResult Then
            ScriptFinished()
        End If
    End Sub

    Friend Sub DebugFile(ByVal DebugFile As String)
        'to do - this can peorbabley be deleted

        'Continue to next real instruction
        Dim bSendResult As Boolean
        bSendResult = SendMsg_UnPause(sAutoItCommandWindowName & " AutoIt Debugger Command Window")
        If Not bSendResult Then
            ScriptFinished()
        End If
    End Sub

    Friend Sub SentVariable(ByVal VariableName As String, ByVal VariableValue As Object)

        'Update the variables form
        fWatch.VariableChanged(VariableName, VariableValue)

        'Add the variable to the trace
        fTrace.MyTree.AddVariable(VariableName, VariableValue)

    End Sub

    Friend Sub NewLine(ByVal Filepath As String, ByVal Filename As String, ByVal LineNumber As Integer, ByVal SkipLine As Boolean)

        'Store the filepath of the script
        sCurrentBreakpointFilepath = Filepath
        iCurrentLine = LineNumber

        'Update the status bar
        sblCurrentLineNumber.Text = Filepath & ": " & LineNumber

        'Change tab
        If ChildForms.ContainsKey(Filepath) Then
            ChildForms(Filepath).Activate()
        Else
            'To do - create a new window
        End If

        'If single stepping then pause
        If bStepInto Then
            If AnyActiveDocument() Then
                ActiveDocument.Scintilla1.Select()
                ActiveDocument.Scintilla1.Lines(iCurrentLine - 1).Goto()
                ActiveDocument.Scintilla1.Markers.DeleteAll(2)
                ActiveDocument.Scintilla1.Lines(iCurrentLine - 1).AddMarker(2)
                ActiveDocument.Scintilla1.Caret.Goto(ActiveDocument.Scintilla1.Lines(iCurrentLine - 1).StartPosition)
                'ActiveDocument.Scintilla1.Caret.HighlightCurrentLine = True
            End If

            bPause = True

        Else
            If AnyActiveDocument() Then
                'Check if this new line has a break point
                If (ActiveDocument.Scintilla1.Lines(iCurrentLine - 1).GetMarkerMask And &H1) = &H1 Then
                    ActiveDocument.Scintilla1.Select()
                    ActiveDocument.Scintilla1.Lines(iCurrentLine - 1).Goto()
                    ActiveDocument.Scintilla1.Caret.Position = ActiveDocument.Scintilla1.Lines(iCurrentLine - 1).StartPosition
                    ActiveDocument.Scintilla1.Markers.DeleteAll(2)
                    ActiveDocument.Scintilla1.Lines(iCurrentLine - 1).AddMarker(2)
                    'ActiveDocument.Scintilla1.Caret.HighlightCurrentLine = True

                    bStepInto = True
                    bPause = True

                Else
                    bPause = False
                    Dim bSendResult As Boolean
                    bSendResult = SendMsg_UnPause(sAutoItCommandWindowName & " AutoIt Debugger Command Window")
                    If Not bSendResult Then
                        ScriptFinished()
                    End If

                End If
            End If

        End If

        If AnyActiveDocument() Then
            fTrace.MyTree.AddLine(Filename, LineNumber, ActiveDocument.Scintilla1.Lines(LineNumber - 1).Text, frmTrace.LineType.BeforeLine)
        End If

    End Sub

    Friend Sub FinishedLine(ByVal Filepath As String, ByVal Filename As String, ByVal LineNumber As Integer, ByVal SkipLine As Boolean)

        'Check if coming off the last line satisfies the step over step type
        If Filepath = sStepOverBreakpointFilepath And LineNumber = iStepOverBreakpointLine Then
            bStepInto = True
            bPause = True
        End If

        If AnyActiveDocument() Then
            fTrace.MyTree.AddLine(Filename, LineNumber, ActiveDocument.Scintilla1.Lines(LineNumber - 1).Text, frmTrace.LineType.AfterLine)
        End If

    End Sub

    Friend Function Paused() As Boolean

        'Return the current pause state
        Paused = bPause

        'Reset variable colours
        'If Not Paused And bStepInto Then
        '    fVariables.ClearAllChangeStatusFlags()
        'End If

        If Paused Then
            Wait(100)
        End If

    End Function

    Friend Function ReadyToQuit() As Boolean

        Return False

    End Function

    Friend Sub ScriptFinished()

        'Update the status bar
        sblCurrentLineNumber.Text = "Script has finished"

        bRunning = False
        bStepInto = False
        bPause = True

        'Clear all highlighted lines
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                Dim MyDocument As frmDocument = CType(MyChildForm, frmDocument)
                MyDocument.Scintilla1.Markers.DeleteAll(1)
                MyDocument.Scintilla1.Caret.HighlightCurrentLine = False
            End If
        Next

        'Test if there are any unsaved docs
        If AnyDocumentUnSaved() Then
            Exit Sub
        End If

        'Switch to development mode
        SwitchToDevelopmentMode()

    End Sub

    Private Sub LoadSettings()
        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")

        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        Me.Left = profile.GetValue("GUI Window", "MainLeft", 100)
        Me.Top = profile.GetValue("GUI Window", "MainTop", 100)
        Me.Width = profile.GetValue("GUI Window", "MainWidth", 550)
        Me.Height = profile.GetValue("GUI Window", "MainHeight", 450)

        bUseAutoItBeta = profile.GetValue("Settings", "UseAutoItBeta", "False")
        bDebugFilesInIncludeLibrary = profile.GetValue("Settings", "DebugFilesInIncludeLibrary", "False")
        bUseVSLexer = profile.GetValue("Settings", "UseVSLexer", "False")
        bAutomaticContextChecking = profile.GetValue("Settings", "AutomaticContextChecking", "False")
        bAutomaticTidy = profile.GetValue("Settings", "AutomaticTidy", "False")
        bEnableAutoComplete = profile.GetValue("Settings", "EnableAutoComplete", "True")
        bEnableCallTips = profile.GetValue("Settings", "EnableCallTips", "True")
        sSciTEInstallFolder = Path.GetFullPath(Path.Combine(Application.StartupPath, profile.GetValue("Settings", "SciTEInstallFolder", "..\SciTE")))
        sAutoItBetaExecutable = Path.GetFullPath(Path.Combine(Application.StartupPath, profile.GetValue("Settings", "AutoItBetaExecutable", "..\Beta\AutoIt3.exe")))
        sAutoItReleaseExecutable = Path.GetFullPath(Path.Combine(Application.StartupPath, profile.GetValue("Settings", "AutoItReleaseExecutable", "..\AutoIt3.exe")))
        sReleaseIncludeFolder = Path.GetFullPath(Path.Combine(Application.StartupPath, profile.GetValue("Settings", "ReleaseIncludeFolder", "..\Include")))
        sBetaIncludeFolder = Path.GetFullPath(Path.Combine(Application.StartupPath, profile.GetValue("Settings", "BetaIncludeFolder", "..\beta\Include")))
        EnableAutomaticUpdates = profile.GetValue("Settings", "EnableAutomaticUpdates", True)

        'Use settings
        If bUseAutoItBeta Then
            sblAutoItVersion.Text = "Debug AutoIt"
            ribHomeToolsRelease.Checked = False
            ribHomeToolsBeta.Checked = True
        Else
            sblAutoItVersion.Text = "Production AutoIt"
            ribHomeToolsRelease.Checked = True
            ribHomeToolsBeta.Checked = False
        End If
        'Define folder names
        sAutoItBetaInstallFolder = New IO.FileInfo(sAutoItBetaExecutable).DirectoryName
        sAutoItReleaseInstallFolder = New IO.FileInfo(sAutoItReleaseExecutable).DirectoryName

        'Check for updates
        If EnableAutomaticUpdates Then
            Dim sUpdateCheckProgram As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "Update Program.exe")
            If IO.File.Exists(sUpdateCheckProgram) Then
                Dim MyProcess As New Process
                MyProcess.StartInfo.FileName = sUpdateCheckProgram
                MyProcess.StartInfo.Arguments = "-Silent"
                MyProcess.Start()
            End If
        End If

    End Sub

    Friend Sub SaveSettings()

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")

        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        If Me.WindowState <> System.Windows.Forms.FormWindowState.Minimized Then
            profile.SetValue("GUI Window", "MainLeft", Me.Left)
            profile.SetValue("GUI Window", "MainTop", Me.Top)
            profile.SetValue("GUI Window", "MainWidth", Me.Width)
            profile.SetValue("GUI Window", "MainHeight", Me.Height)
        End If

        profile.SetValue("Settings", "UseAutoItBeta", bUseAutoItBeta)
        profile.SetValue("Settings", "EnableAutomaticUpdates", EnableAutomaticUpdates)

    End Sub

    Private Function GetContentFromPersistString(ByVal persistString As String) As IDockContent

        GetContentFromPersistString = Nothing
        If persistString = Type.GetType("AutoIt_Debugger.frmWatch").ToString() Then
            fWatch = New frmWatch
            Return fWatch
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmVariables").ToString() Then
            fVariables = New frmVariables
            Return fVariables
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmFunctions").ToString() Then
            fFunctions = New frmFunctions
            Return fFunctions
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmIncludes").ToString() Then
            fIncludes = New frmIncludes
            Return fIncludes
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmToolChest").ToString() Then
            fToolChest = New frmToolChest
            Return fToolChest
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmTrace").ToString() Then
            'If fTrace Is Nothing Then
            fTrace = New frmTrace
            'Return fTrace
            'Else
            Return fTrace
            'End If
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmOutput").ToString() Then
            fOutput = New frmOutput
            Return fOutput
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmTidy").ToString() Then
            fTidy = New frmTidy
            Return fTidy
        ElseIf persistString = Type.GetType("AutoIt_Debugger.frmErrorList").ToString() Then
            fErrorList = New frmErrorList
            Return fErrorList
        End If

    End Function

    Private Sub RunScript()

        'Clear the variables
        'fWatch.ClearVariableTable()

        'Clear the trace
        fTrace.MyTree.ClearTrace()

        If Not AnyActiveDocument() Then
            Exit Sub
        End If

        'Save the file
        ActiveDocument.SaveFile()

        'Test if there are any unsaved docs
        If AnyDocumentUnSaved() Then
            Exit Sub
        End If

        'Create the debug file
        CreateDebugFile(ActiveDocument.DocumentPath, Me)

        'Determine debug file path
        Dim sFile As String = New FileInfo(ActiveDocument.DocumentPath).Name
        Dim sFileExt As String = New FileInfo(ActiveDocument.DocumentPath).Extension
        Dim sFolder As String = New FileInfo(ActiveDocument.DocumentPath).DirectoryName
        Dim sDebugFolder As String = Path.Combine(sFolder, "Debug")
        Dim sDebugFileName As String = sFile.Replace(sFileExt, ".Debug Script" & sFileExt)
        Dim sDebugFilePath As String = Path.Combine(sDebugFolder, sDebugFileName)

        'Run the script
        Dim sAutoItInstallFolder As String
        If bUseAutoItBeta Then
            sAutoItInstallFolder = sAutoItBetaInstallFolder
        Else
            sAutoItInstallFolder = sAutoItReleaseInstallFolder
        End If

        Dim sProcessFilename As String = Path.Combine(sAutoItInstallFolder, "AutoIt3.exe")
        If Not File.Exists(sProcessFilename) Then
            MsgBox("The following file does not exist. Check all paths in the program options." & _
                vbNewLine & sProcessFilename, MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        'Set the output window
        fOutput.Show()
        fOutput.ClearText()
        fOutput.OutputType = frmOutput.eOutputType.General

        'Switch to debug mode
        SwitchToDebugMode()

        Dim MyProc As New Process
        MyProc.StartInfo.FileName = sProcessFilename
        MyProc.StartInfo.Arguments = Chr(34) & sDebugFilePath & Chr(34) & " " & ActiveDocument.CommandLineArgument
        MyProc.Start()

    End Sub

    'Private Sub SortOutputHandler(ByVal sendingProcess As Object, _
    '    ByVal outLine As DataReceivedEventArgs)

    '    ' Collect the sort command output.
    '    If Not String.IsNullOrEmpty(outLine.Data) Then
    '        ' Add the text to the collected output.
    '        fOutput.WriteLine(outLine.Data)
    '    End If
    'End Sub

    Public Sub UpdateForms()
        'Update Function List
        fVariables.UpdateForm()
        fFunctions.UpdateForm()
        fIncludes.UpdateForm()
    End Sub

    Private Sub SwitchToDebugMode()
        'Test if there are any unsaved docs
        If AnyDocumentUnSaved() Then
            Exit Sub
        End If

        'Exit if alreay in debug mode
        If Not bDevelopmentMode Then Exit Sub

        'Switch to Debug Mode
        bDevelopmentMode = False

        'Save watch variables
        Dim sDebugINIFile As String = FileBeingDeduggedDocument.DebugIniFilepath
        If File.Exists(sDebugINIFile) Then
            'Read ini settings
            Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sDebugINIFile)
            profile.SetValue("Settings", "Watched_Variables", fWatch.CreateVariablesString())
        End If

        ' Save the DockPanel settings
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "DockPanel.config")
        DockPanel1.SaveAsXml(configFile)

        'Save the active document path
        Dim sActiveDoc As String = ActiveDocument.DocumentPath

        'Save the document window paths
        Dim FilePaths As New List(Of String)
        Dim MyDocument As frmDocument
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                MyDocument = CType(MyChildForm, frmDocument)
                If MyDocument.DocumentPath <> "" Then
                    FilePaths.Add(MyDocument.DocumentPath)
                End If
            End If
        Next

        'Close all panels
        For i As Integer = DockPanel1.Contents.Count - 1 To 0 Step -1
            Dim con As DockContent = DockPanel1.Contents(i)
            con.Close()
        Next

        ' Load the DockPanel settings 
        configFile = Path.Combine(System.Windows.Forms.Application.StartupPath, "DockPanel_Debug.config")
        If File.Exists(configFile) Then
            Dim m_deserializeDockContent As DeserializeDockContent

            m_deserializeDockContent = New DeserializeDockContent(AddressOf GetContentFromPersistString)
            DockPanel1.LoadFromXml(configFile, m_deserializeDockContent)
        Else
            ' Load a basic layout
            'fTrace.Show(DockPanel1, DockState.DockBottom)
            fOutput.Show(DockPanel1, DockState.DockBottom)
            fTidy.Show(DockPanel1, DockState.DockBottom)
            fErrorList.Show(DockPanel1, DockState.DockBottom)
            fVariables.Show(DockPanel1, DockState.DockRight)
            fFunctions.Show(DockPanel1, DockState.DockRight)
            fIncludes.Show(DockPanel1, DockState.DockRight)
            fToolChest.Show(DockPanel1, DockState.DockRight)
        End If

        'Load the document windows again
        For Each MyString As String In FilePaths
            OpenFile(MyString, True)
        Next

        'Disable editing
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                Dim MyDocument2 As frmDocument = CType(MyChildForm, frmDocument)
                MyDocument2.Scintilla1.UseBackColor = True
                MyDocument2.Scintilla1.BackColor = Drawing.Color.WhiteSmoke
                MyDocument2.Scintilla1.IsReadOnly = True

                'If this was the active doc, then activate it
                If MyDocument2.DocumentPath = sActiveDoc Then
                    MyDocument2.Activate()
                End If
            End If
        Next

        'Make the previously active doc active agsain
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                Dim MyDocument2 As frmDocument = CType(MyChildForm, frmDocument)
                'If this was the active doc, then activate it
                If MyDocument2.DocumentPath = sActiveDoc Then
                    MyDocument2.Activate()
                End If
            End If
        Next

        Me.Text = "AutoIt Debugger - " & sAutoItCommandWindowName

        'Load Watched variables
        If Not FileBeingDeduggedDocument() Is Nothing Then
            Dim sReadDebugINIFile As String = FileBeingDeduggedDocument.DebugIniFilepath

            If File.Exists(sReadDebugINIFile) Then
                'Read ini settings
                Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sReadDebugINIFile)
                fWatch.LoadVariablesFromString(profile.GetValue("Settings", "Watched_Variables", ""))
            End If
        End If
    End Sub

    Private Sub SwitchToDevelopmentMode()
        'Test if there are any unsaved docs
        If AnyDocumentUnSaved() Then Exit Sub

        'Exit if already in Development mode
        If bDevelopmentMode Then Exit Sub

        'Switch to Development Mode
        bDevelopmentMode = True

        'Save watch variables
        Dim sDebugINIFile As String = FileBeingDeduggedDocument.DebugIniFilepath
        If File.Exists(sDebugINIFile) Then
            'Read ini settings
            Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sDebugINIFile)
            profile.SetValue("Settings", "Watched_Variables", fWatch.CreateVariablesString())
        End If

        ' Save the DockPanel settings
        Dim configFile As String = Path.Combine(System.Windows.Forms.Application.StartupPath, "DockPanel_Debug.config")
        DockPanel1.SaveAsXml(configFile)

        'Save the active document path
        Dim sActiveDoc As String = ActiveDocument.DocumentPath

        'Save the document window paths
        Dim FilePaths As New List(Of String)
        Dim MyDocument As frmDocument
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                MyDocument = CType(MyChildForm, frmDocument)
                FilePaths.Add(MyDocument.DocumentPath)
            End If
        Next

        'Close all panels
        For i As Integer = DockPanel1.Contents.Count - 1 To 0 Step -1
            Dim con As DockContent = DockPanel1.Contents(i)
            con.Close()
        Next

        ' Load the DockPanel settings 
        configFile = Path.Combine(System.Windows.Forms.Application.StartupPath, "DockPanel.config")
        If File.Exists(configFile) Then
            Dim m_deserializeDockContent As DeserializeDockContent

            m_deserializeDockContent = New DeserializeDockContent(AddressOf GetContentFromPersistString)
            DockPanel1.LoadFromXml(configFile, m_deserializeDockContent)
        Else
            ' Load a basic layout
            fTrace.Show(DockPanel1, DockState.DockBottom)
            fOutput.Show(DockPanel1, DockState.DockBottom)
            fTidy.Show(DockPanel1, DockState.DockBottom)
            fErrorList.Show(DockPanel1, DockState.DockBottom)
            fWatch.Show(DockPanel1, DockState.DockRight)
            fVariables.Show(DockPanel1, DockState.DockRight)
            fFunctions.Show(DockPanel1, DockState.DockRight)
            fIncludes.Show(DockPanel1, DockState.DockRight)
            fToolChest.Show(DockPanel1, DockState.DockRight)
        End If

        'Load the document winows again
        For Each MyString As String In FilePaths
            OpenFile(MyString, True)
        Next

        'Enable editing
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                Dim MyDocument2 As frmDocument = CType(MyChildForm, frmDocument)
                MyDocument2.Scintilla1.IsReadOnly = False
                MyDocument2.Scintilla1.UseBackColor = False

                'If this was the active doc, then activate it
                If MyDocument2.DocumentPath = sActiveDoc Then
                    MyDocument2.Activate()
                End If
            End If
        Next

        'Make the previously active doc active agsain
        For Each MyChildForm As frmChildForm In ChildForms
            If TypeOf (MyChildForm) Is frmDocument Then
                Dim MyDocument2 As frmDocument = CType(MyChildForm, frmDocument)
                'If this was the active doc, then activate it
                If MyDocument2.DocumentPath = sActiveDoc Then
                    MyDocument2.Activate()
                End If
            End If
        Next

        Me.Text = "AutoIt Debugger - " & sAutoItCommandWindowName

        'Load Watched variables
        If Not FileBeingDeduggedDocument() Is Nothing Then
            Dim sReadDebugINIFile As String = FileBeingDeduggedDocument.DebugIniFilepath

            If File.Exists(sReadDebugINIFile) Then
                'Read ini settings
                Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sReadDebugINIFile)
                fWatch.LoadVariablesFromString(profile.GetValue("Settings", "Watched_Variables", ""))
            End If
        End If
    End Sub

    Private Sub ProcessCommandString(ByVal Command As Integer, ByVal CommandString As String)
        CommandString = CommandString.Trim(Chr(34))
        Console.WriteLine(CommandString & vbNewLine)

        Dim saCommandArray() As String = CommandString.Split("|")

        Dim ifSkipLine As Boolean
        
        Select Case Command
            Case 1 '"New Line"
                '不知道为什么调试时出现Fal，而不是false，只有这样处理了。。。不知道还是否有bug  ( add by ywq111:I do not know why "False" at here is "Fal",So I must Deal with "Fal")
                ifSkipLine = IIf(saCommandArray(3).Equals("Fal"), False, saCommandArray(3))

                NewLine(saCommandArray(0), saCommandArray(1), saCommandArray(2), ifSkipLine)
            Case 2 '"Finished Line"
                ifSkipLine = IIf(saCommandArray(3).Equals("Fal"), False, saCommandArray(3))
                FinishedLine(saCommandArray(0), saCommandArray(1), saCommandArray(2), ifSkipLine)
            Case 3 '"SentVariable"
                'The variable value may contain '|', so this cannot be used to split the string.
                Dim iFirstPipePos As Integer = InStr(CommandString, "|")
                Dim sVariableValue As String = CommandString.Substring(iFirstPipePos)
                SentVariable(saCommandArray(0), sVariableValue)
            Case 4 '"LoadFile"
                LoadFile(saCommandArray(0))
            Case 5 '"ScriptFinished"
                ScriptFinished()
            Case 6 '"DebugFile"
                DebugFile(saCommandArray(0))
            Case 7 '"Console Write"
                fOutput.WriteLine(saCommandArray(0))
                'DebugFile(saCommandArray(0))
        End Select
    End Sub

#End Region

#Region "Subclassing Current Form Only"

    Private Const WM_CLOSE As System.Int32 = &H10
    Private Const WM_QUERYENDSESSION As System.Int32 = &H11
    Private Const SC_CLOSE As System.Int32 = &HF060&
    Private Const WM_SYSCOMMAND As System.Int32 = &H112
    Private Const WM_KEYDOWN As System.Int32 = &H100
    Private Const WM_DESTROY As System.Int32 = &H2
    Private Const SC_MAXIMIZE As System.Int32 = &HF030
    Private Const SC_MINIMIZE As System.Int32 = &HF020
    Private Const SC_RESTORE As System.Int32 = &HF120
    Private Const WM_COPYDATA = &H4A
    'If you want to Subclass the Current Form only, 
    'then just remove these Comments 
    'You can not SubClass any Control using this method

    Protected Overrides Sub WndProc(ByRef m As Message)
        Select Case m.Msg
            'If from Meny Close Is Selected then
            Case Is = WM_SYSCOMMAND
                Select Case m.WParam.ToInt32
                    Case Is = SC_CLOSE
                        'MsgBox("Closing")
                    Case Is = SC_MAXIMIZE
                        'MsgBox("Maximize")
                    Case Is = SC_RESTORE
                        'MsgBox("Restore")
                End Select

            Case Is = WM_DESTROY
                'MsgBox("Destroy")
            Case Is = WM_CLOSE
                'MsgBox("Close")
            Case Is = WM_COPYDATA
                'MsgBox("CopyData")

                Dim cds As COPYDATASTRUCT = New COPYDATASTRUCT()
                cds = System.Runtime.InteropServices.Marshal.PtrToStructure(m.LParam, cds.GetType())
                If (cds.lpData > 0) Then
                    Dim Command As Integer = cds.tyData
                    Dim data(cds.lnData - 1) As Byte
                    Dim source As IntPtr = New IntPtr(cds.lpData)
                    Dim length As Integer = cds.lnData
                    System.Runtime.InteropServices.Marshal.Copy(source, data, 0, length)
                    Dim mytest As COPYDATASTRINGSTRUCT = New COPYDATASTRINGSTRUCT()
                    'ReDim mytest.sData(255)
                    'mytest = System.Runtime.InteropServices.Marshal.PtrToStructure(source, mytest.GetType())

                    'Modify by ywq111:for convert byte to string,solved the problem at deal with Non English string
                    Dim dddd As String = System.Text.Encoding.Default.GetString(data)
                    ProcessCommandString(Command, dddd)

                    'the follow text is comment by ywq111,because it can't deal with non english string 
                    '下面的从byte转化成string的代码在非英语系统下，会出现乱码，故而注释，试用上面的代码，直接转化成string
                    'Dim aChar() As Char
                    'ReDim aChar(cds.lnData - 1)
                    'Dim d As System.Text.Decoder = System.Text.Encoding.UTF8.GetDecoder()
                    'Dim charLen As Integer = d.GetChars(data, 0, data.Length, aChar, 0)

                    'Dim s As String = CStr(aChar)
                    'MsgBox(s)
                    'ProcessCommandString(Command, s)





                    'Dim encText As New System.Text.UTF8Encoding()
                    'Dim btText() As Byte
                    'btText = encText.GetBytes(strText)

                    'Dim stream As System.IO.MemoryStream = New System.IO.MemoryStream(data)
                    'Dim b As System.Runtime.Serialization.Formatters.Binary.BinaryFormatter = New System.Runtime.Serialization.Formatters.Binary.BinaryFormatter()
                    'Dim cdo As CopyDataObjectData = b.Deserialize(stream)

                    'If (channels.Contains(cdo.Channel)) Then
                    '    Dim d As DataReceivedEventArgs = New DataReceivedEventArgs(cdo.Channel, cdo.Data, cdo.Sent)
                    '    OnDataReceived(d)
                    '    m.Result = New IntPtr(1)
                    'End If
                End If

            Case Is = WM_KEYDOWN
                MsgBox(m.HWnd.ToString)
                'MsgBox("Key Down : Virtual Code : " & m.HWnd.ToInt32 
                '& vbCrLf & "Key Data : " & m.LParam.ToInt32)
        End Select

        MyBase.WndProc(m)

    End Sub

#End Region


    Private Sub RibbonButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RibbonButton2.Click
        Dim x As Integer = 5   ' Declare variables.
        Dim y As Integer = 0
        x /= y   ' Cause a "Divide by Zero" error.
    End Sub

    Private Sub RibbonButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RibbonButton4.Click
        If bDevelopmentMode Then
            SwitchToDebugMode()
        Else
            SwitchToDevelopmentMode()
        End If
    End Sub

    Private Sub RibbonButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RibbonButton5.Click
        'Save the file
        ActiveDocument.SaveFile()

        'Create the debug file
        CreateDebugFile(ActiveDocument.DocumentPath, Me)
    End Sub

    Private Sub ribWindowFunctions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowFunctions.Click
        fFunctions.Show(DockPanel1)
    End Sub

    Private Sub ribWindowIncludes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowIncludes.Click
        fIncludes.Show(DockPanel1)
    End Sub

    Private Sub ribWindowTidy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ribWindowTidy.Click
        If fTidy.Visible Then
            fTidy.Hide()
            ribWindowTidy.Checked = False
        Else
            fTidy.Show(DockPanel1)
            ribWindowTidy.Checked = True
        End If
    End Sub
End Class