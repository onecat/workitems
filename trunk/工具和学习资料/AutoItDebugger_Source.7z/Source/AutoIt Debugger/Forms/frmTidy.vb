Imports System.Drawing
Imports WeifenLuo.WinFormsUI.Docking
Imports System.Windows.Forms

Public Class frmTidy
    Inherits DockContent

    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub

    Private Sub frmOutput_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Dock = Windows.Forms.DockStyle.Fill
    End Sub

    Friend Sub ClearText()
        TextBox1.Clear()
        Application.DoEvents()
    End Sub

    Friend Sub ScrollToTop()
        'Set the cursor to the first character in the textbox which will be at the top of the control.
        TextBox1.SelectionStart = 0
        'Make the textbox scroll to the actually caret postition.
        TextBox1.ScrollToCaret()
    End Sub

    Friend Sub WriteStringBuilder(ByVal Text As System.Text.StringBuilder)
        TextBox1.AppendText(Text.ToString())

        'Set markers
        For Each sLine As String In TextBox1.Lines
            If sLine.Contains("ERROR") Or sLine.Contains("WARNING") Then
                'Extract line number
                Dim iLine As Integer = CInt(sLine.Substring(sLine.LastIndexOf("(") + 1, sLine.LastIndexOf(")") - sLine.LastIndexOf("(") - 1))
                Dim sFilename As String = sLine.Substring(0, sLine.LastIndexOf("("))

                Dim MyChildForm As frmChildForm
                Dim MyDocument As frmDocument
                If Not frmMain.ChildForms.ContainsKey(sFilename) Then
                    'Open the file
                    frmMain.OpenFile(sFilename)
                End If

                MyChildForm = frmMain.ChildForms(sFilename)
                If TypeOf (MyChildForm) Is frmDocument Then
                    MyDocument = CType(MyChildForm, frmDocument)
                    MyDocument.Scintilla1.Lines(iLine - 1).AddMarker(1)
                End If
            End If
        Next
    End Sub

    Friend Sub WriteLine(ByVal Text As String)
        If TextBox1.Text = "" Then
            TextBox1.Text = Text
        Else
            TextBox1.AppendText(vbNewLine & Text)
        End If
    End Sub

    Private Sub TextBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.DoubleClick
        'Check if there are any lines
        If TextBox1.Lines.Length = 0 Then
            Exit Sub
        End If

        'Dim CurrentLine As Integer = TextBox1.GetLineFromCharIndex(TextBox1.SelectionStart)
        Dim sLine As String = GetTextBoxLine(TextBox1)

        If sLine.Contains("Error") Or sLine.Contains("Warning") Then
            'MsgBox(sLine)
            'Extract line number

            Dim iLine As Integer = CInt(sLine.Substring(sLine.LastIndexOf("(") + 1, sLine.LastIndexOf(")") - sLine.LastIndexOf("(") - 1))
            Dim sFilename As String = sLine.Substring(0, sLine.LastIndexOf("("))

            Dim MyChildForm As frmChildForm
            Dim MyDocument As frmDocument
            If frmMain.ChildForms.ContainsKey(sFilename) Then
                MyChildForm = frmMain.ChildForms(sFilename)
                If TypeOf (MyChildForm) Is frmDocument Then
                    MyDocument = CType(MyChildForm, frmDocument)
                    MyDocument.Activate()
                    MyDocument.Scintilla1.Lines(iLine - 1).Goto()
                End If
            End If
        End If
    End Sub

    ''' <summary>
    ''' Returns the current line of a TextBox containing the caret
    ''' </summary>
    ''' <param name="txtbox">The textbox to check</param>
    ''' <returns>The visible line, not the logical line in the array</returns>
    ''' <remarks>Returns the visible line, so does not contain any wrapped words.</remarks>
    Private Function GetTextBoxLine(ByVal txtbox As TextBox) As String
        Dim firstIndexOfCurLine As Integer = txtbox.GetFirstCharIndexOfCurrentLine()
        Dim curLineIndex As Integer = txtbox.GetLineFromCharIndex(firstIndexOfCurLine)
        Dim startOfNextLine As Integer = txtbox.GetFirstCharIndexFromLine(curLineIndex + 1)

        If (startOfNextLine < 0) Then
            '-1 means there are no more lines
            Return txtbox.Text.Substring(firstIndexOfCurLine)
        Else
            Return txtbox.Text.Substring(firstIndexOfCurLine, startOfNextLine - firstIndexOfCurLine)
        End If
    End Function

End Class