Imports WeifenLuo.WinFormsUI.Docking

Public MustInherit Class frmChildForm
    Inherits DockContent

    Friend Event FormChangedEvent()

    Public ReadOnly Property PersistString() As String
        Get
            Return Me.GetPersistString
        End Get
    End Property

    Private Sub frmChildForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        'frmMain.ChildForms.Remove(Me.Name)
    End Sub

    Private Sub frmChildForm_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        'Moved to here to allow cancelling of form closing
        frmMain.ChildForms.Remove(Me.Name)
    End Sub

    Private Sub frmChildForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Sub frmChildForm_Load(ByVal sender As Object, _
                            ByVal e As System.EventArgs) _
                            Handles MyBase.Load
        frmMain.ChildForms.Add(Me)
    End Sub

    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
    End Sub

    Public MustOverride Sub UpdateForm()

    Friend Sub FormChanged()
        RaiseEvent FormChangedEvent()
    End Sub

End Class
