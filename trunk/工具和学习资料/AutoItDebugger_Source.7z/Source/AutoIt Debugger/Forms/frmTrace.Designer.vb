Imports WeifenLuo.WinFormsUI.Docking
Imports Aga.Controls.Tree

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTrace
    Inherits DockContent

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TreeColumn1 = New TreeColumn
        Me.TreeColumn2 = New TreeColumn
        Me.TreeColumn3 = New TreeColumn
        Me.TreeColumn4 = New TreeColumn
        Me.clhFile = New System.Windows.Forms.ColumnHeader
        Me.clhLine = New System.Windows.Forms.ColumnHeader
        Me.clhCode = New System.Windows.Forms.ColumnHeader
        Me.TreeViewAdv1 = New TreeViewAdv
        Me._file = New NodeControls.NodeTextBox
        Me._InOut = New NodeControls.NodeTextBox
        Me._line = New NodeControls.NodeTextBox
        Me._Code = New NodeControls.NodeTextBox
        Me.SuspendLayout()
        '
        'TreeColumn1
        '
        Me.TreeColumn1.Header = "File"
        Me.TreeColumn1.SortOrder = System.Windows.Forms.SortOrder.None
        Me.TreeColumn1.TooltipText = Nothing
        Me.TreeColumn1.Width = 150
        '
        'TreeColumn2
        '
        Me.TreeColumn2.Header = "In/Out"
        Me.TreeColumn2.SortOrder = System.Windows.Forms.SortOrder.None
        Me.TreeColumn2.TooltipText = Nothing
        Me.TreeColumn2.Width = 60
        '
        'TreeColumn3
        '
        Me.TreeColumn3.Header = "Line"
        Me.TreeColumn3.SortOrder = System.Windows.Forms.SortOrder.None
        Me.TreeColumn3.TooltipText = Nothing
        Me.TreeColumn3.Width = 100
        '
        'TreeColumn4
        '
        Me.TreeColumn4.Header = "Code"
        Me.TreeColumn4.SortOrder = System.Windows.Forms.SortOrder.None
        Me.TreeColumn4.TooltipText = Nothing
        Me.TreeColumn4.Width = 300
        '
        'clhFile
        '
        Me.clhFile.Text = "File"
        '
        'clhLine
        '
        Me.clhLine.Text = "Line"
        '
        'clhCode
        '
        Me.clhCode.Text = "Code"
        '
        'TreeViewAdv1
        '
        Me.TreeViewAdv1.BackColor = System.Drawing.SystemColors.Window
        Me.TreeViewAdv1.Columns.Add(Me.TreeColumn1)
        Me.TreeViewAdv1.Columns.Add(Me.TreeColumn2)
        Me.TreeViewAdv1.Columns.Add(Me.TreeColumn3)
        Me.TreeViewAdv1.Columns.Add(Me.TreeColumn4)
        Me.TreeViewAdv1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TreeViewAdv1.DefaultToolTipProvider = Nothing
        Me.TreeViewAdv1.DragDropMarkColor = System.Drawing.Color.Black
        Me.TreeViewAdv1.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeViewAdv1.FullRowSelect = True
        Me.TreeViewAdv1.LineColor = System.Drawing.SystemColors.ControlDark
        Me.TreeViewAdv1.Location = New System.Drawing.Point(12, 12)
        Me.TreeViewAdv1.Model = Nothing
        Me.TreeViewAdv1.Name = "TreeViewAdv1"
        Me.TreeViewAdv1.NodeControls.Add(Me._file)
        Me.TreeViewAdv1.NodeControls.Add(Me._InOut)
        Me.TreeViewAdv1.NodeControls.Add(Me._line)
        Me.TreeViewAdv1.NodeControls.Add(Me._Code)
        Me.TreeViewAdv1.SelectedNode = Nothing
        Me.TreeViewAdv1.Size = New System.Drawing.Size(566, 195)
        Me.TreeViewAdv1.TabIndex = 0
        Me.TreeViewAdv1.Text = "TreeViewAdv1"
        Me.TreeViewAdv1.UseColumns = True
        '
        '_file
        '
        Me._file.DataPropertyName = "Column1"
        Me._file.IncrementalSearchEnabled = True
        Me._file.LeftMargin = 3
        Me._file.ParentColumn = Me.TreeColumn1
        '
        '_InOut
        '
        Me._InOut.DataPropertyName = "Column2"
        Me._InOut.IncrementalSearchEnabled = True
        Me._InOut.LeftMargin = 3
        Me._InOut.ParentColumn = Me.TreeColumn2
        '
        '_line
        '
        Me._line.DataPropertyName = "Column3"
        Me._line.IncrementalSearchEnabled = True
        Me._line.LeftMargin = 3
        Me._line.ParentColumn = Me.TreeColumn3
        '
        '_Code
        '
        Me._Code.DataPropertyName = "Column4"
        Me._Code.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Code.IncrementalSearchEnabled = True
        Me._Code.LeftMargin = 3
        Me._Code.ParentColumn = Me.TreeColumn4
        '
        'frmTrace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(590, 219)
        Me.Controls.Add(Me.TreeViewAdv1)
        Me.HideOnClose = True
        Me.Name = "frmTrace"
        Me.TabText = "Program Trace"
        Me.Text = "Trace"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents clhFile As System.Windows.Forms.ColumnHeader
    Friend WithEvents clhLine As System.Windows.Forms.ColumnHeader
    Friend WithEvents clhCode As System.Windows.Forms.ColumnHeader
    Friend WithEvents TreeViewAdv1 As TreeViewAdv
    Friend WithEvents _file As NodeControls.NodeTextBox
    Friend WithEvents _line As NodeControls.NodeTextBox
    Friend WithEvents _Code As NodeControls.NodeTextBox
    Friend WithEvents _InOut As NodeControls.NodeTextBox
    Friend WithEvents TreeColumn1 As TreeColumn
    Friend WithEvents TreeColumn2 As TreeColumn
    Friend WithEvents TreeColumn3 As TreeColumn
    Friend WithEvents TreeColumn4 As TreeColumn
End Class
