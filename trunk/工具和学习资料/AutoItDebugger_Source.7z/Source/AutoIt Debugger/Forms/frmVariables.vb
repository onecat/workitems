Option Explicit On
Option Strict On

Imports WeifenLuo.WinFormsUI.Docking
Imports System.Text.RegularExpressions
Imports System.Collections
Imports System.Windows.Forms

<System.Runtime.InteropServices.ComVisible(False)> Public Class frmVariables

    Inherits DockContent

    Event ChangeVariable(ByVal VariableName As String, ByVal VariableValue As String)

    Private Sub lvwVariables_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvwFunctions.Click

        'Check if there are any lines
        If lvwFunctions.Items.Count = 0 Then
            Exit Sub
        End If

        If Not frmMain.AnyActiveDocument Then
            Exit Sub
        End If

        Dim iLine As Integer

        'Check if any items are selected
        If lvwFunctions.SelectedItems.Count > 0 Then
            Dim MyListViewItem As New MyCustomListViewItem
            MyListViewItem = CType(lvwFunctions.Items(lvwFunctions.SelectedItems(0).Tag.ToString), MyCustomListViewItem)
            iLine = MyListViewItem.NextLine


            frmMain.ActiveDocument.Scintilla1.Lines(frmMain.ActiveDocument.Scintilla1.Lines.Count).Goto()
            frmMain.ActiveDocument.Scintilla1.Lines(iLine).Goto()
            frmMain.ActiveDocument.Scintilla1.Markers.DeleteAll(1)
            frmMain.ActiveDocument.Scintilla1.Lines(iLine).AddMarker(1)
        End If
    End Sub

    Friend Sub UpdateForm()
        Dim MyItem As Windows.Forms.ListViewItem
        If frmMain.AnyActiveDocument Then

            lvwFunctions.Items.Clear()
            lvwFunctions.BeginUpdate()

            With frmMain.ActiveDocument
                For Each MyListViewItem As MyCustomListViewItem In .Variables
                    MyItem = lvwFunctions.Items.Add(MyListViewItem)
                Next
            End With

            lvwFunctions.Sorting = Windows.Forms.SortOrder.Ascending
            If lvwFunctions.Columns.Count > 0 Then
                lvwFunctions.Columns(0).Width = -1
            End If

            lvwFunctions.EndUpdate()

        End If
    End Sub

    Private Sub LoadSettings()

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")

        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

    End Sub

    Friend Sub SaveSettings()

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "Create Debug Script.ini")

        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

    End Sub

    Private Sub frmVariables_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate

    End Sub

    Private Sub frmVariables_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

    End Sub

    Private Sub frmVariables_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveSettings()
    End Sub

    Private Sub frmVariables_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lvwFunctions.Dock = Windows.Forms.DockStyle.Fill

        LoadSettings()
    End Sub

    Private Sub lvwFunctions_ItemDrag(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles lvwFunctions.ItemDrag
        'Check if any items are selected
        If lvwFunctions.SelectedItems.Count > 0 Then
            Dim MyListViewItem As New MyCustomListViewItem
            MyListViewItem = CType(lvwFunctions.Items(lvwFunctions.SelectedItems(0).Tag.ToString), MyCustomListViewItem)

            lvwFunctions.DoDragDrop(MyListViewItem.Name, DragDropEffects.Copy)
        End If
    End Sub

End Class
