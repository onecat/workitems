Imports WeifenLuo.WinFormsUI.Docking
Imports Aga.Controls.Tree

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmErrorList
    Inherits DockContent

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmErrorList))
        Me.clhFile = New System.Windows.Forms.ColumnHeader
        Me.clhLine = New System.Windows.Forms.ColumnHeader
        Me.clhCode = New System.Windows.Forms.ColumnHeader
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Courier New", 9.0!)
        Me.TextBox1.Location = New System.Drawing.Point(19, 22)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox1.Size = New System.Drawing.Size(199, 65)
        Me.TextBox1.TabIndex = 0
        '
        'frmErrorList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(261, 110)
        Me.Controls.Add(Me.TextBox1)
        Me.HideOnClose = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmErrorList"
        Me.TabText = "Error List"
        Me.Text = "Error List"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents clhFile As System.Windows.Forms.ColumnHeader
    Friend WithEvents clhLine As System.Windows.Forms.ColumnHeader
    Friend WithEvents clhCode As System.Windows.Forms.ColumnHeader
    Friend WithEvents _file As NodeControls.NodeTextBox
    Friend WithEvents _line As NodeControls.NodeTextBox
    Friend WithEvents _Code As NodeControls.NodeTextBox
    Friend WithEvents _InOut As NodeControls.NodeTextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
