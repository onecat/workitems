Imports WeifenLuo.WinFormsUI.Docking
Imports System.IO
Imports ScintillaNet
Imports System.Windows.Forms
Imports System.Text.RegularExpressions

Public Class frmDocument
    Inherits frmChildForm
    'Inherits DockContent

    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuUndo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuRedo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuCut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuCopy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPaste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDelete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuSelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Scintilla1 As ScintillaNet.Scintilla
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuBreakpointInsert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BreakpointToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuBreakpointDelete As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Dim sFilepath As String
    Dim sFileName As String
    Dim sCommandLineArguments As String
    Dim sDebugINIFile As String
    Friend WithEvents mnuDebugging As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDebuggingEnable As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDebuggingDisable As System.Windows.Forms.ToolStripMenuItem
    Dim sDebugFolder As String
    Dim calltipParametersEnd As String = ")"
    Dim calltipParametersStart As String = "("
    Dim autoCompleteStartCharacters As String = "#_@abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    Dim calltipWordCharacters As String = "#_@abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    Dim calltipParametersSeparators As String = ","
    Dim startCalltipWord As Integer
    Dim startHighlight As Integer
    Dim endHighlight As Integer
    Friend WithEvents mnuSnippets As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSnippetsInsertSnippet As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSnippetSurroundWith As System.Windows.Forms.ToolStripMenuItem
    Dim functionDefinition As String

    Dim oIncludes As New List(Of MyCustomListViewItem)
    Dim oFunctions As New List(Of MyCustomListViewItem)
    Dim oVariables As New List(Of MyCustomListViewItem)
    Friend WithEvents FileSystemWatcher1 As System.IO.FileSystemWatcher
    Friend WithEvents mnuAddWatch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FileSystemWatcherTimer1 As System.Windows.Forms.Timer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.TabText = "Untitled.au3"
        Scintilla1.Modified = True
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuUndo = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuRedo = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuCut = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuCopy = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuPaste = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuDelete = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuSelectAll = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.BreakpointToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBreakpointInsert = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBreakpointDelete = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuDebugging = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuDebuggingEnable = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuDebuggingDisable = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuSnippets = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuSnippetsInsertSnippet = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuSnippetSurroundWith = New System.Windows.Forms.ToolStripMenuItem
        Me.Scintilla1 = New ScintillaNet.Scintilla
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher
        Me.FileSystemWatcherTimer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuAddWatch = New System.Windows.Forms.ToolStripMenuItem
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.Scintilla1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuUndo, Me.mnuRedo, Me.ToolStripSeparator1, Me.mnuCut, Me.mnuCopy, Me.mnuPaste, Me.mnuDelete, Me.ToolStripSeparator2, Me.mnuSelectAll, Me.ToolStripMenuItem1, Me.mnuAddWatch, Me.ToolStripSeparator4, Me.BreakpointToolStripMenuItem, Me.mnuDebugging, Me.mnuSnippets})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(153, 292)
        '
        'mnuUndo
        '
        Me.mnuUndo.Name = "mnuUndo"
        Me.mnuUndo.Size = New System.Drawing.Size(152, 22)
        Me.mnuUndo.Text = "Undo"
        '
        'mnuRedo
        '
        Me.mnuRedo.Name = "mnuRedo"
        Me.mnuRedo.Size = New System.Drawing.Size(152, 22)
        Me.mnuRedo.Text = "Redo"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(149, 6)
        '
        'mnuCut
        '
        Me.mnuCut.Name = "mnuCut"
        Me.mnuCut.Size = New System.Drawing.Size(152, 22)
        Me.mnuCut.Text = "Cut"
        '
        'mnuCopy
        '
        Me.mnuCopy.Name = "mnuCopy"
        Me.mnuCopy.Size = New System.Drawing.Size(152, 22)
        Me.mnuCopy.Text = "Copy"
        '
        'mnuPaste
        '
        Me.mnuPaste.Name = "mnuPaste"
        Me.mnuPaste.Size = New System.Drawing.Size(152, 22)
        Me.mnuPaste.Text = "Paste"
        '
        'mnuDelete
        '
        Me.mnuDelete.Name = "mnuDelete"
        Me.mnuDelete.Size = New System.Drawing.Size(152, 22)
        Me.mnuDelete.Text = "Delete"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(149, 6)
        '
        'mnuSelectAll
        '
        Me.mnuSelectAll.Name = "mnuSelectAll"
        Me.mnuSelectAll.Size = New System.Drawing.Size(152, 22)
        Me.mnuSelectAll.Text = "Select All"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(149, 6)
        '
        'BreakpointToolStripMenuItem
        '
        Me.BreakpointToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuBreakpointInsert, Me.mnuBreakpointDelete})
        Me.BreakpointToolStripMenuItem.Name = "BreakpointToolStripMenuItem"
        Me.BreakpointToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.BreakpointToolStripMenuItem.Text = "&Breakpoint"
        '
        'mnuBreakpointInsert
        '
        Me.mnuBreakpointInsert.Name = "mnuBreakpointInsert"
        Me.mnuBreakpointInsert.Size = New System.Drawing.Size(167, 22)
        Me.mnuBreakpointInsert.Text = "Insert B&reakpoint"
        '
        'mnuBreakpointDelete
        '
        Me.mnuBreakpointDelete.Name = "mnuBreakpointDelete"
        Me.mnuBreakpointDelete.Size = New System.Drawing.Size(167, 22)
        Me.mnuBreakpointDelete.Text = "D&elete Breakpoint"
        '
        'mnuDebugging
        '
        Me.mnuDebugging.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDebuggingEnable, Me.mnuDebuggingDisable})
        Me.mnuDebugging.Name = "mnuDebugging"
        Me.mnuDebugging.Size = New System.Drawing.Size(152, 22)
        Me.mnuDebugging.Text = "Debugging"
        '
        'mnuDebuggingEnable
        '
        Me.mnuDebuggingEnable.Name = "mnuDebuggingEnable"
        Me.mnuDebuggingEnable.Size = New System.Drawing.Size(194, 22)
        Me.mnuDebuggingEnable.Text = "Enable from this Point"
        '
        'mnuDebuggingDisable
        '
        Me.mnuDebuggingDisable.Name = "mnuDebuggingDisable"
        Me.mnuDebuggingDisable.Size = New System.Drawing.Size(194, 22)
        Me.mnuDebuggingDisable.Text = "Disable from this Point"
        '
        'mnuSnippets
        '
        Me.mnuSnippets.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSnippetsInsertSnippet, Me.mnuSnippetSurroundWith})
        Me.mnuSnippets.Name = "mnuSnippets"
        Me.mnuSnippets.Size = New System.Drawing.Size(152, 22)
        Me.mnuSnippets.Text = "&Snippets"
        '
        'mnuSnippetsInsertSnippet
        '
        Me.mnuSnippetsInsertSnippet.Name = "mnuSnippetsInsertSnippet"
        Me.mnuSnippetsInsertSnippet.Size = New System.Drawing.Size(151, 22)
        Me.mnuSnippetsInsertSnippet.Text = "&Insert Snippet"
        '
        'mnuSnippetSurroundWith
        '
        Me.mnuSnippetSurroundWith.Name = "mnuSnippetSurroundWith"
        Me.mnuSnippetSurroundWith.Size = New System.Drawing.Size(151, 22)
        Me.mnuSnippetSurroundWith.Text = "&Surround With"
        '
        'Scintilla1
        '
        Me.Scintilla1.AllowDrop = True
        Me.Scintilla1.Caret.IsSticky = True
        Me.Scintilla1.Caret.Style = ScintillaNet.CaretStyle.Invisible
        Me.Scintilla1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Scintilla1.HotspotStyle.ActiveUnderline = False
        Me.Scintilla1.HotspotStyle.SingleLine = False
        Me.Scintilla1.LineWrap.PositionCacheSize = 0
        Me.Scintilla1.LineWrap.VisualFlags = ScintillaNet.WrapVisualFlag.[End]
        Me.Scintilla1.Location = New System.Drawing.Point(0, 0)
        Me.Scintilla1.Margins.Margin1.AutoToggleMarkerNumber = 0
        Me.Scintilla1.Margins.Margin1.IsClickable = True
        Me.Scintilla1.Margins.Margin2.Width = 16
        Me.Scintilla1.Name = "Scintilla1"
        Me.Scintilla1.Size = New System.Drawing.Size(305, 297)
        Me.Scintilla1.TabIndex = 1
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "AutoIt Debugger Help.chm"
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'FileSystemWatcherTimer1
        '
        Me.FileSystemWatcherTimer1.Interval = 500
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(149, 6)
        '
        'mnuAddWatch
        '
        Me.mnuAddWatch.Name = "mnuAddWatch"
        Me.mnuAddWatch.Size = New System.Drawing.Size(152, 22)
        Me.mnuAddWatch.Text = "&Add Watch"
        '
        'frmDocument
        '
        Me.ClientSize = New System.Drawing.Size(305, 297)
        Me.Controls.Add(Me.Scintilla1)
        Me.DockAreas = CType(((((WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft Or WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight) _
                    Or WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop) _
                    Or WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom) _
                    Or WeifenLuo.WinFormsUI.Docking.DockAreas.Document), WeifenLuo.WinFormsUI.Docking.DockAreas)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmDocument"
        Me.TabText = "frmDocument"
        Me.Text = "frmDocument"
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.Scintilla1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Base Class Event Handlers "

    Private Sub frmDocument_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'Check for changes
        If (sFilepath <> "" And Modified) Or (sFilepath = "" And Scintilla1.TextLength <> 0) Then
            Dim iResult As DialogResult
            iResult = MessageBox.Show("Save changes to '" & sFileName & "'?", "AutoIt Debugger", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
            Select Case iResult
                Case Windows.Forms.DialogResult.Yes
                    SaveFile()
                Case Windows.Forms.DialogResult.No
                    'Do nothing
                Case Windows.Forms.DialogResult.Cancel
                    e.Cancel = True
            End Select
        End If

        If sFilepath <> "" Then
            'Create the folder if necessary
            If Not Directory.Exists(sDebugFolder) Then
                Dim DebugFolder As DirectoryInfo = Directory.CreateDirectory(sDebugFolder)
                DebugFolder.Attributes = FileAttributes.Hidden
            End If

            'Get breakpoints as array
            Dim sBreakpointLines As String = ""
            For Each MyLine As ScintillaNet.Line In Scintilla1.Lines
                If (MyLine.GetMarkerMask And &H1) = &H1 Then
                    sBreakpointLines = sBreakpointLines & MyLine.Number & ","
                End If
            Next
            sBreakpointLines = sBreakpointLines.TrimEnd(",")

            'Save the breakpoints
            Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sDebugINIFile)
            profile.SetValue(sFileName, "Breakpoints", sBreakpointLines)
            profile.SetValue(sFileName, "CommandLineArguments", sCommandLineArguments)
        End If
    End Sub

    Private Sub frmDocument_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Scintilla1.Dock = Windows.Forms.DockStyle.Fill

        If frmMain.bUseVSLexer Then
            Scintilla1.ConfigurationManager.CustomLocation = Path.Combine(System.Windows.Forms.Application.StartupPath, "VS Lexer")
        Else
            Scintilla1.ConfigurationManager.CustomLocation = Path.Combine(System.Windows.Forms.Application.StartupPath, "SciTE Lexer")
        End If
        Scintilla1.ConfigurationManager.IsBuiltInEnabled = False
        Scintilla1.ConfigurationManager.IsUserEnabled = True
        Scintilla1.ConfigurationManager.Language = "au3"

        'Lexing
        Scintilla1.Lexing.WordChars = "#_$@abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

        'Line numbers
        Scintilla1.Margins.Margin0.Width = 35
        Scintilla1.Margins.Margin0.Type = ScintillaNet.MarginType.Number

        'Breakpoints
        Scintilla1.Margins.Margin1.Type = ScintillaNet.MarginType.Symbol
        Scintilla1.Margins.Margin1.IsMarkerMargin = True
        Scintilla1.Margins.Margin1.IsClickable = True
        Scintilla1.Margins.Margin1.AutoToggleMarkerNumber = 0
        Scintilla1.Margins.Margin1.Mask = 1 'Show Marker 0

        'Margin 2 is the code folding

        'Context checking
        Scintilla1.Margins.Margin3.Width = 16
        Scintilla1.Margins.Margin3.Type = ScintillaNet.MarginType.Symbol
        Scintilla1.Margins.Margin3.IsMarkerMargin = True
        Scintilla1.Margins.Margin3.IsClickable = False
        Scintilla1.Margins.Margin3.AutoToggleMarkerNumber = 1
        Scintilla1.Margins.Margin3.Mask = 6 'Show Marker 1 and 2

        Scintilla1.Markers(0).BackColor = Drawing.Color.Red
        Scintilla1.Markers(1).BackColor = Drawing.Color.Yellow
        Scintilla1.Markers(2).BackColor = Drawing.Color.Yellow
        Scintilla1.Markers(2).Symbol = MarkerSymbol.Background

        'Other settings
        'Scintilla1.ContextMenuStrip = ContextMenuStrip1
        Scintilla1.NativeInterface.UsePopUp(False)
        Scintilla1.Caret.Style = CaretStyle.Line
        Scintilla1.Caret.Width = 1
        Scintilla1.FindReplace.Marker = Scintilla1.Markers(1)
        Scintilla1.AutoComplete.SingleLineAccept = False

        'Load breakpoints
        Dim sBreakpointLines As String = ""

        'Create the folder if necessary
        If Directory.Exists(sDebugFolder) Then
            'Read ini settings
            Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(sDebugINIFile)
            sBreakpointLines = profile.GetValue(sFileName, "Breakpoints", "")
            sCommandLineArguments = profile.GetValue(sFileName, "CommandLineArguments", "")

            If sBreakpointLines <> "" Then
                Dim BreakpointArray() As String = sBreakpointLines.Split(",")

                For Each MyString As String In BreakpointArray
                    Scintilla1.Lines(CInt(MyString)).AddMarker(0)
                Next
            End If
        End If

        'Set dirty by default
        'Scintilla1.Modified = True

        'custom snippet test
        Scintilla1.Snippets.List.Add("Steve Test", "Do " & vbNewLine & vbTab & "$selected$$end$" & vbNewLine & "Until $DropMarker$", "$", True)

    End Sub

    Public Overrides Sub UpdateForm()

    End Sub

#End Region

#Region " Menu Event Handlers "

    Private Sub ContextMenuStrip1_Opening(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening
        mnuUndo.Enabled = Scintilla1.UndoRedo.CanUndo
        mnuRedo.Enabled = Scintilla1.UndoRedo.CanRedo
        mnuCut.Enabled = Scintilla1.Selection.Length > 0
        mnuCopy.Enabled = Scintilla1.Selection.Length > 0
        mnuPaste.Enabled = Scintilla1.Clipboard.CanPaste
        mnuDelete.Enabled = Scintilla1.Selection.Length > 0
    End Sub

    Private Sub mnuUndo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUndo.Click
        Scintilla1.UndoRedo.Undo()
    End Sub

    Private Sub mnuRedo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuRedo.Click
        Scintilla1.UndoRedo.Redo()
    End Sub

    Private Sub mnuCut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCut.Click
        Scintilla1.Clipboard.Cut()
    End Sub

    Private Sub mnuCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCopy.Click
        Scintilla1.Clipboard.Copy()
    End Sub

    Private Sub mnuPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPaste.Click
        Scintilla1.Clipboard.Paste()
    End Sub

    Private Sub mnuDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDelete.Click
        Scintilla1.Selection.Clear()
    End Sub

    Private Sub mnuSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSelectAll.Click
        Scintilla1.Selection.SelectAll()
    End Sub

    Private Sub mnuAddWatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAddWatch.Click
        'Get the currently selected word
        frmMain.fWatch.MyTree.AddVariable(Scintilla1.GetWordFromPosition(Scintilla1.Caret.Position), True)
    End Sub

    Private Sub mnuBreakpointInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuBreakpointInsert.Click
        Scintilla1.Lines.Current.AddMarker(0)
    End Sub

    Private Sub mnuBreakpointDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuBreakpointDelete.Click
        Scintilla1.Lines.Current.DeleteMarker(0)
    End Sub

    Private Sub mnuDebuggingEnable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDebuggingEnable.Click
        Scintilla1.InsertText(Scintilla1.Lines.Current.StartPosition, ";AutoIt_Debugger_Command:Enable_Debug" & vbNewLine)
    End Sub

    Private Sub mnuDebuggingDisable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDebuggingDisable.Click
        Scintilla1.InsertText(Scintilla1.Lines.Current.StartPosition, ";AutoIt_Debugger_Command:Disable_Debug" & vbNewLine)
    End Sub

#End Region

#Region " Form Controls Event Handlers "

    Private Sub Scintilla1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Scintilla1.DragDrop
        'Get the filename(s)
        Dim sDropFile As String
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop, True)

        'Use the first filename dropped
        sDropFile = files(0)

        frmMain.OpenFile(sDropFile)
    End Sub

    Private Sub Scintilla1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Scintilla1.DragEnter
        'Check that a file or files are being dragged over the control
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            'Get the filename(s)
            Dim file() As String = e.Data.GetData(DataFormats.FileDrop, True)

            'Check the file types
            'Select Case UCase(Microsoft.VisualBasic.Right(file(0), 4))
            '    Case sDragDropFile.ToUpper
            e.Effect = DragDropEffects.Copy
            '    Case Else
            'e.Effect = DragDropEffects.None
            'End Select
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub Scintilla1_ModifiedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Scintilla1.ModifiedChanged
        AddOrRemoveAsteric()
    End Sub

    Private Sub Scintilla1_HelpRequested(ByVal sender As Object, ByVal hlpevent As System.Windows.Forms.HelpEventArgs) Handles Scintilla1.HelpRequested
        Dim iPosition As Integer = Scintilla1.Caret.Position
        Dim sWord As String = Scintilla1.GetWordFromPosition(iPosition)
        'MsgBox(sWord)

        'Dim startPosition As Integer = Scintilla1.NativeInterface.WordStartPosition(iPosition, True)
        'Dim endPosition As Integer = Scintilla1.NativeInterface.WordEndPosition(iPosition, True)
        'sWord = Scintilla1.GetRange(startPosition, endPosition).Text
        'MsgBox(sWord)

        Dim sAutoItInstallFolder As String
        If frmMain.bUseAutoItBeta Then
            sAutoItInstallFolder = frmMain.sAutoItBetaInstallFolder
        Else
            sAutoItInstallFolder = frmMain.sAutoItReleaseInstallFolder
        End If

        Dim MyProcess As New Process
        MyProcess.StartInfo.FileName = Path.Combine(sAutoItInstallFolder, "AutoIt3Help.exe")
        MyProcess.StartInfo.Arguments = sWord
        MyProcess.Start()
    End Sub

    Private Sub Scintilla1_CharAdded(ByVal sender As Object, ByVal e As ScintillaNet.CharAddedEventArgs) Handles Scintilla1.CharAdded
        Dim crange As ScintillaNet.CharacterRange
        'crange = Scintilla1.Selection
        Dim selStart As Integer = crange.cpMin
        Dim selEnd As Integer = crange.cpMax
        selStart = Scintilla1.Selection.Start
        selEnd = Scintilla1.Selection.End

        Dim braceCount As Integer
        Dim autoCCausedByOnlyOne As Boolean

        If ((selEnd = selStart) And (selStart > 0)) Then
            If Scintilla1.CallTip.IsActive Then
                If (calltipParametersEnd.Contains(e.Ch)) Then
                    braceCount = braceCount - 1
                    If (braceCount < 1) Then
                        Scintilla1.CallTip.Cancel()
                    Else
                        StartCallTip()
                    End If
                ElseIf (calltipParametersStart.Contains(e.Ch)) Then
                    braceCount = braceCount + 1
                    StartCallTip()
                Else
                    ContinueCallTip()
                End If
            ElseIf Scintilla1.AutoComplete.IsActive Then
                If (calltipParametersStart.Contains(e.Ch)) Then
                    braceCount = braceCount + 1
                    StartCallTip()
                ElseIf (calltipParametersEnd.Contains(e.Ch)) Then
                    braceCount = braceCount - 1
                ElseIf Not Scintilla1.Lexing.WordChars.Contains(e.Ch) Then
                    Scintilla1.AutoComplete.Cancel()
                    If (autoCompleteStartCharacters.Contains(e.Ch)) Then
                        Debug.Print("Call StartAutoComplete")
                        StartAutoComplete()
                    End If
                ElseIf (autoCCausedByOnlyOne) Then
                    StartAutoCompleteWord(True)
                End If
            Else
                If (calltipParametersStart.Contains(e.Ch)) Then
                    braceCount = 1
                    StartCallTip()
                Else
                    autoCCausedByOnlyOne = False
                    'If (indentMaintain) Then
                    '    MaintainIndentation(e.Ch)
                    'AutomaticIndentation(e.Ch)
                    If (autoCompleteStartCharacters.Contains(e.Ch)) Then
                        Debug.Print("Call StartAutoComplete")
                        StartAutoComplete()
                    ElseIf Scintilla1.Lexing.WordChars.Contains(e.Ch) Then
                        Debug.Print("Call StartAutoCompleteWord")
                        StartAutoCompleteWord(True)
                        autoCCausedByOnlyOne = Scintilla1.AutoComplete.IsActive
                    End If
                End If
                'End If
            End If
        End If
    End Sub

    Private Sub FileSystemWatcher1_Changed(ByVal sender As Object, ByVal e As System.IO.FileSystemEventArgs) Handles FileSystemWatcher1.Changed
        FileSystemWatcherTimer1.Enabled = True
    End Sub

    Private Sub FileSystemWatcherTimer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles FileSystemWatcherTimer1.Tick
        FileSystemWatcherTimer1.Enabled = False

        If MsgBox("The file '" & sFileName & "' was changed externally. Reload document? Any unsaved changes will be lost.", MsgBoxStyle.Question Or MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            ReloadFile()
        End If
    End Sub

#End Region

#Region " Class Properties "

    ''' <summary>
    ''' Sets/Returns the Command Line Arguments for the au3 script
    ''' </summary>
    ''' <value></value>
    ''' <returns>The command line argument string</returns>
    ''' <remarks></remarks>
    Public Property CommandLineArgument() As String
        Get
            CommandLineArgument = sCommandLineArguments
        End Get
        Set(ByVal value As String)
            sCommandLineArguments = value
        End Set
    End Property

    ''' <summary>
    ''' Returns the filepath of the file open in the window
    ''' </summary>
    ''' <value></value>
    ''' <returns>The filepath of the file</returns>
    ''' <remarks></remarks>
    Friend ReadOnly Property DocumentPath() As String
        Get
            Return sFilepath
        End Get
    End Property

    ''' <summary>
    ''' Returns/sets the filepath of the file open in the window
    ''' </summary>
    ''' <value></value>
    ''' <returns>The filepath of the file</returns>
    ''' <remarks></remarks>
    Private Property FilePath() As String
        Get
            Return sFilepath
        End Get
        Set(ByVal value As String)

            Dim fs As New FileInfo(value)
            Dim Filename As String = fs.Name

            sFilepath = value
            sFileName = Filename

            Me.TabText = Filename

            'setup file system watcher
            FileSystemWatcher1.Path = fs.DirectoryName
            FileSystemWatcher1.Filter = sFileName

        End Set
    End Property

    ''' <summary>
    ''' Returns the filepath of the debug ini file of the file in the window
    ''' </summary>
    ''' <value></value>
    ''' <returns>The filepath of the file</returns>
    ''' <remarks></remarks>
    Friend ReadOnly Property DebugIniFilepath() As String
        Get
            Return sDebugINIFile
        End Get
    End Property

    ''' <summary>
    ''' Returns whether the document has been modified (not saved)
    ''' </summary>
    ''' <value></value>
    ''' <returns>True if the file has unsaved changes</returns>
    ''' <remarks></remarks>
    Friend ReadOnly Property Modified() As Boolean
        Get
            Return Scintilla1.Modified
        End Get
    End Property

    Public ReadOnly Property Includes() As List(Of MyCustomListViewItem)
        Get
            Return oIncludes
        End Get
    End Property

    Public ReadOnly Property Functions() As List(Of MyCustomListViewItem)
        Get
            Return oFunctions
        End Get
    End Property

    Public ReadOnly Property Variables() As List(Of MyCustomListViewItem)
        Get
            Return oVariables
        End Get
    End Property

    ''' <summary>
    ''' Enable/disable watching for file changes.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property WatchForChanges() As Boolean
        Get
            WatchForChanges = FileSystemWatcher1.EnableRaisingEvents
        End Get
        Set(ByVal value As Boolean)
            FileSystemWatcher1.EnableRaisingEvents = value
        End Set
    End Property

#End Region

#Region " Class Methods "

    Public Sub AddFile(ByVal FileToAdd As String)

        FilePath = FileToAdd

        'Set debug folder/file
        Dim sFolder As String = New FileInfo(FilePath).DirectoryName
        Dim sTempFile As String = New FileInfo(FilePath).Name
        sDebugFolder = Path.Combine(sFolder, "Debug")
        Dim extensionPosition As Integer = sTempFile.LastIndexOf(".")
        Dim filePathNoEx As String = sTempFile.Substring(0, extensionPosition)
        sDebugINIFile = Path.Combine(sDebugFolder, filePathNoEx & ".ini")

        'Load file
        'Dim fs As FileStream = New FileStream(FileToAdd, FileMode.Open)

        ' Dim targetEncoding As System.Text.Encoding = GetEncoding(fs, defaultEncoding)
        '            fs.Close();

        'Dim sEncoding As Encoding = Encoding.ASCII

        '
        'update by ywq111 at 2011-3-27:
        '
        ' use the default encode to Read file,can detect unicode and (utf-8 with BOM)
        'fixed the bug for can't read non english text which is use ASCII Encode
        'now:can not detect files which is utf-8 without BOM Encode. 

        Dim oSR As New StreamReader(FileToAdd, System.Text.Encoding.Default, True)
        ' Add this line to read the file.
        Scintilla1.Text = oSR.ReadToEnd()
        oSR.Close()

        ' Add this line to read the file.
        'Scintilla1.Text = File.ReadAllText(FilePath, System.Text.Encoding.Default)

        UpdateForClassViewer()
        Scintilla1.Modified = False
    End Sub

    ''' <summary>
    ''' Reloads the current file
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ReloadFile()
        If sFilepath <> "" Then
            'Load file

            '
            'modify by ywq111 at 2011-3-27:
            '
            ' use the default encode to Read file,can detect unicode and (utf-8 with BOM)
            'fixed the bug for can't read non english text which is use ASCII Encode
            'now:can not detect files which is utf-8 without BOM Encode. 
            Dim oSR As New StreamReader(FilePath, System.Text.Encoding.Default, True)
            Scintilla1.Text = oSR.ReadToEnd()
            oSR.Close()

            'Scintilla1.Text = File.ReadAllText(FilePath, System.Text.Encoding.Default)
            'Scintilla1.Text = File.ReadAllText(DocumentPath)

            UpdateForClassViewer()
            Scintilla1.Modified = False
        End If
    End Sub

    ''' <summary>
    ''' Saves the current file
    ''' </summary>
    ''' <returns>True if the file has been saved</returns>
    ''' <remarks></remarks>
    Public Function SaveFile() As Boolean

        If sFilepath <> "" Then
            If Scintilla1.Modified Then
                'Save file
                FileSystemWatcher1.EnableRaisingEvents = False
                File.WriteAllText(sFilepath, Scintilla1.Text())
                FileSystemWatcher1.EnableRaisingEvents = True

                Scintilla1.Modified = False
                SaveFile = True
                UpdateForClassViewer()
                MyBase.FormChanged()
            Else
                SaveFile = True
            End If
        Else
            Dim sfdNewFile As New SaveFileDialog
            sfdNewFile.Filter = "AutoIt Files (*.au3)|*.au3"
            sfdNewFile.CheckPathExists = True
            If sfdNewFile.ShowDialog = Windows.Forms.DialogResult.OK Then

                'Save file
                FileSystemWatcher1.EnableRaisingEvents = False
                File.WriteAllText(sfdNewFile.FileName, Scintilla1.Text(), System.Text.Encoding.UTF8) 'File.WriteAllText(sfdNewFile.FileName, Scintilla1.Text())
                FileSystemWatcher1.EnableRaisingEvents = True

                Scintilla1.Modified = False
                SaveFile = True
                MyBase.FormChanged()

                'Load file as if just openned
                AddFile(sfdNewFile.FileName)
            Else
                SaveFile = False
            End If
        End If

    End Function

    Private Sub UpdateForClassViewer()
        oFunctions.Clear()
        oIncludes.Clear()
        oVariables.Clear()

        Dim LinesColl As ScintillaNet.LinesCollection = Scintilla1.Lines
        For Each myLine As ScintillaNet.Line In LinesColl
            Dim sLine As String = myLine.Text

            'Includes
            Dim RegexObj As Regex = New Regex("^\#include\s\<(.*)\>", RegexOptions.IgnoreCase)
            If RegexObj.IsMatch(sLine) Then
                For Each mItem As Match In RegexObj.Matches(sLine)
                    Dim sValue As String = mItem.Groups(1).Value
                    If sValue <> "" Then
                        If Not ListViewItemListContains(sValue, oIncludes) Then
                            Dim MyListViewItem As New MyCustomListViewItem
                            MyListViewItem.Name = sValue
                            MyListViewItem.Tag = sValue
                            MyListViewItem.Text = sValue
                            MyListViewItem.Lines.Add(myLine.Number)
                            MyListViewItem.ImageIndex = 2
                            oIncludes.Add(MyListViewItem)
                        Else
                            Dim MyListViewItem As New MyCustomListViewItem
                            MyListViewItem = ListViewItemListItem(sValue, oIncludes)
                            MyListViewItem.Lines.Add(myLine.Number)
                            MyListViewItem.Text = sValue & " (" & MyListViewItem.Lines.Count & ")"
                        End If
                    End If
                Next
            End If

            'Includes
            Dim Includes2RegexObj As Regex = New Regex("^\#include\s\x22(.*)\x22", RegexOptions.IgnoreCase) 'x22 = "
            If Includes2RegexObj.IsMatch(sLine) Then
                For Each mItem As Match In Includes2RegexObj.Matches(sLine)
                    Dim sIncludeFilename As String = mItem.Groups(1).Value
                    Dim sValue As String
                    If sIncludeFilename.Contains("\") Then
                        sValue = sIncludeFilename.Substring(sIncludeFilename.LastIndexOf("\") + 1)
                    Else
                        sValue = sIncludeFilename
                    End If
                    If sValue <> "" Then
                        If Not ListViewItemListContains(sValue, oIncludes) Then
                            Dim MyListViewItem As New MyCustomListViewItem
                            MyListViewItem.Name = sValue
                            MyListViewItem.Tag = sValue
                            MyListViewItem.Text = sValue
                            MyListViewItem.Lines.Add(myLine.Number)
                            MyListViewItem.ImageIndex = 2
                            oIncludes.Add(MyListViewItem)
                        Else
                            Dim MyListViewItem As New MyCustomListViewItem
                            MyListViewItem = ListViewItemListItem(sValue, oIncludes)
                            MyListViewItem.Lines.Add(myLine.Number)
                            MyListViewItem.Text = sValue & " (" & MyListViewItem.Lines.Count & ")"
                        End If
                    End If
                Next
            End If

            'Functions
            Dim FunctionRegexObj As Regex = New Regex("^\s*Func (\w*)", RegexOptions.IgnoreCase)
            If FunctionRegexObj.IsMatch(sLine) Then
                For Each mItem As Match In FunctionRegexObj.Matches(sLine)
                    Dim sValue As String
                    sValue = mItem.Groups(1).Value
                    If sValue <> "" Then
                        If Not ListViewItemListContains(sValue, oFunctions) Then
                            Dim MyListViewItem As New MyCustomListViewItem
                            MyListViewItem.Name = sValue
                            MyListViewItem.Tag = sValue
                            MyListViewItem.Text = sValue
                            MyListViewItem.Lines.Add(myLine.Number)
                            MyListViewItem.ImageIndex = 1
                            oFunctions.Add(MyListViewItem)
                        Else
                            Dim MyListViewItem As New MyCustomListViewItem
                            MyListViewItem = ListViewItemListItem(sValue, oFunctions)
                            MyListViewItem.Lines.Add(myLine.Number)
                            MyListViewItem.Text = sValue & " (" & MyListViewItem.Lines.Count & ")"
                        End If
                    End If
                Next
            End If

            'Variables
            Dim VariableArray As List(Of String) = GetVariableList(sLine)
            For iVariablesIndex As Integer = 0 To VariableArray.Count - 1
                Dim sValue As String
                sValue = VariableArray(iVariablesIndex)
                If sValue <> "" Then
                    If Not ListViewItemListContains("$" & sValue, oVariables) Then
                        Dim MyListViewItem As New MyCustomListViewItem
                        MyListViewItem.Name = "$" & sValue
                        MyListViewItem.Tag = "$" & sValue
                        MyListViewItem.Text = sValue
                        MyListViewItem.Lines.Add(myLine.Number)
                        MyListViewItem.ImageIndex = 0
                        oVariables.Add(MyListViewItem)
                    Else
                        Dim MyListViewItem As New MyCustomListViewItem
                        MyListViewItem = ListViewItemListItem("$" & sValue, oVariables)
                        MyListViewItem.Lines.Add(myLine.Number)
                        MyListViewItem.Text = sValue & " (" & MyListViewItem.Lines.Count & ")"
                    End If
                End If
            Next
        Next
    End Sub

#End Region

#Region " Miscellaneous Code "

    Private Sub AddOrRemoveAsteric()
        If Scintilla1.Modified Then
            If Not Me.TabText.EndsWith(" *") Then
                Me.TabText = Me.TabText & " *"
            End If
        Else
            If Me.TabText.EndsWith(" *") Then
                Me.TabText = Me.TabText.Substring(0, Me.TabText.Length - 2)
            End If
        End If
    End Sub

    'Private Sub Scintilla1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Scintilla1.KeyPress
    '    If e.KeyChar = "(" Then
    '        Scintilla1.CallTip.Show("FileWriteLine ( filehandle or 'filename', 'line' ) Append a line of text to the end of a previously opened text file.")
    '    Else
    '        Scintilla1.AutoComplete.Show()
    '    End If
    'End Sub

    Private Function StartAutoComplete() As Boolean
        If Not frmMain.bEnableAutoComplete Then Exit Function

        Debug.WriteLine("StartAutoComplete")

        Dim line As String = Scintilla1.Lines.Current.Text
        Dim current As Integer = GetCaretInLine()

        Dim startword As Integer = current

        While (startword > 0) AndAlso (calltipWordCharacters.Contains(line(startword - 1)) OrElse autoCompleteStartCharacters.Contains(line(startword - 1)))
            startword = startword - 1
        End While

        Dim root As String = line.Substring(startword, current - startword)
        Debug.WriteLine("StartAutoComplete Root: " & root)

        Dim words As List(Of String) = GetNearestWords(root)

        If words.Count > 0 Then
            Debug.WriteLine("Show AutoComplete")
            Scintilla1.AutoComplete.Show(root.Length(), words)
        End If

        Return True
    End Function

    Private Function GetNearestWords(ByVal WordStart As String) As List(Of String)
        Dim WordList As New List(Of String)

        For Each MyString As String In frmMain.MyAutoCompleteWords
            If MyString.StartsWith(WordStart, StringComparison.OrdinalIgnoreCase) Then
                WordList.Add(MyString)
            End If
        Next

        Return WordList
    End Function

    Private Function GetCaretInLine() As Integer
        Dim caret As Integer = Scintilla1.Caret.Position
        Dim line As Integer = Scintilla1.Caret.LineNumber
        Dim lineStart As Integer = Scintilla1.Lines(line).StartPosition
        Return caret - lineStart
    End Function

    Private Function StartAutoCompleteWord(ByVal onlyOneWord As Boolean) As Boolean
        If Not frmMain.bEnableAutoComplete Then Exit Function

        '       Dim line As String = Scintilla1.Lines.Current.Text
        '       Dim current As Integer = GetCaretInLine()

        '       Dim startword As Integer = current
        '       ' Autocompletion of pure numbers is mostly an annoyance
        '       Dim allNumber As Boolean = True
        '       While (startword > 0) And (wordCharacters.contains(line(startword - 1)))
        '           startword = startword - 1
        '	if (line(startword) < '0' || line[startword] > '9') then
        '               allNumber = False
        '           End If
        '       End While
        'if (startword == current || allNumber)
        '           Return True
        '           SString(root = line.substr(startword, current - startword))
        '           Int(doclen = LengthDocument())
        'TextToFind ft = {{0, 0}, 0, {0, 0}}
        'ft.lpstrText = const_cast<char*>(root.c_str())
        '           ft.chrg.cpMin = 0
        '           ft.chrg.cpMax = doclen
        '           ft.chrgText.cpMin = 0
        '           ft.chrgText.cpMax = 0
        'const int flags = SCFIND_WORDSTART | (autoCompleteIgnoreCase ? 0 : SCFIND_MATCHCASE)
        '           Int(posCurrentWord = SendEditor(SCI_GETCURRENTPOS) - root.length())
        'unsigned int minWordLength = 0
        'unsigned int nwords = 0

        '           ' wordsNear contains a list of words separated by single spaces and with a space
        '           ' at the start and end. This makes it easy to search for words.
        '           SString(wordsNear)
        '           wordsNear.setsizegrowth(1000)
        '           wordsNear.append(" ")

        'int posFind = SendEditorString(SCI_FINDTEXT, flags, reinterpret_cast<char *>(&ft))
        '           WindowAccessor(acc(wEditor.GetID(), props))
        'while (posFind >= 0 && posFind < doclen) {	' search all the document
        '               Int(wordEnd = posFind + root.length())
        '	if (posFind != posCurrentWord) {
        '                   While (wordCharacters.contains(acc.SafeGetCharAt(wordEnd)))
        '			wordEnd++
        '                       size_t(wordLength = wordEnd - posFind)
        '		if (wordLength > root.length()) {
        '                           SString(word = GetRange(wEditor, posFind, wordEnd))
        '                           word.insert(0, " ")
        '                           word.append(" ")
        '			if (!wordsNear.contains(word.c_str())) {	' add a new entry
        '                               wordsNear += word.c_str() + 1
        '                               If (minWordLength < wordLength) Then
        '                                   minWordLength = wordLength

        '				nwords++
        '				if (onlyOneWord && nwords > 1) {
        '                                       Return True
        '				}
        '			}
        '		}
        '	}
        '                                       ft.chrg.cpMin = wordEnd
        '	posFind = SendEditorString(SCI_FINDTEXT, flags, reinterpret_cast<char *>(&ft))
        '}
        '                                       size_t(length = wordsNear.length())
        'if ((length > 2) && (!onlyOneWord || (minWordLength > root.length()))) {
        '                                           StringList(wl)
        '                                           wl.Set(wordsNear.c_str())
        '	char *words = wl.GetNearestWords("", 0, autoCompleteIgnoreCase)
        '                                           SendEditorString(SCI_AUTOCSHOW, root.length(), words)
        '	delete []words
        '} else {
        '                                           SendEditor(SCI_AUTOCCANCEL)
        '}
        '                                           Return True
    End Function

    Private Function StartCallTip() As Boolean

        If Not frmMain.bEnableCallTips Then Exit Function

        Dim currentCallTip As Integer = 0
        Dim currentCallTipWord As String = ""
        Dim line As String = Scintilla1.Lines.Current.Text
        Dim current As Integer = GetCaretInLine()

        Dim pos As Integer = Scintilla1.Caret.Position

        Dim braces As Integer
        Do
            braces = 0
            While current > 0 AndAlso (braces OrElse Not calltipParametersStart.Contains(line(current - 1)))
                If calltipParametersStart.Contains(line(current - 1)) Then
                    braces -= 1
                ElseIf calltipParametersEnd.Contains(line(current - 1)) Then
                    braces += 1
                End If
                current -= 1
                pos -= 1
            End While
            If current > 0 Then
                current -= 1
                pos -= 1
            Else
                Exit Do
            End If
            While current > 0 AndAlso isspacechar(line(current - 1))
                current -= 1
                pos -= 1
            End While
        Loop While current > 0 AndAlso Not calltipWordCharacters.Contains(line(current - 1))
        If current <= 0 Then
            Return True
        End If

        startCalltipWord = current - 1
        While startCalltipWord > 0 AndAlso calltipWordCharacters.Contains(line(startCalltipWord - 1))
            startCalltipWord -= 1
        End While


        Dim startword As Integer = current

        While (startword > 0) AndAlso (calltipWordCharacters.Contains(line(startword - 1)) OrElse autoCompleteStartCharacters.Contains(line(startword - 1)))
            startword -= 1
        End While

        Dim root As String = line.Substring(startword, current - startword)

        'line.change(current, ControlChars.NullChar)
        'currentCallTipWord = line + startCalltipWord
        'functionDefinition = ""
        'Platform::DebugPrintf("word is [%s] %d %d %d\n", currentCallTipWord.c_str(), currentCallTipWord.length(), pos, pos - rootlen);
        'FillFunctionDefinition(pos)
        For Each MyString As String In frmMain.MyCallTips
            If MyString.StartsWith(root, StringComparison.OrdinalIgnoreCase) Then
                functionDefinition = MyString
                MyString = MyString.Replace(")", ")" & vbLf & " ")
                Scintilla1.CallTip.Show(MyString)
                Exit For
            End If
        Next

        Return True
    End Function

    Private Function isspacechar(ByVal ch As Char) As Boolean
        Char.IsWhiteSpace(ch)
        'return (ch = " ") OR ((ch >= 0x09) AND (ch <= 0x0d))
    End Function

    Private Sub ContinueCallTip()
        If Not frmMain.bEnableCallTips Then Exit Sub

        Dim line As String = Scintilla1.Lines.Current.Text
        Dim current As Integer = GetCaretInLine()

        Dim braces As Integer = 0
        Dim commas As Integer = 0
        For i As Integer = startCalltipWord To current - 1
            If calltipParametersStart.Contains(line(i)) Then
                braces += 1
            ElseIf calltipParametersEnd.Contains(line(i)) AndAlso braces > 0 Then
                braces -= 1
            ElseIf braces = 1 AndAlso calltipParametersSeparators.Contains(line(i)) Then
                commas += 1
            End If
        Next

        Dim startHighlight As Integer = 0
        While Not calltipParametersStart.Contains(functionDefinition(startHighlight))
            startHighlight += 1
        End While
        If calltipParametersStart.Contains(functionDefinition(startHighlight)) Then
            startHighlight += 1
        End If
        While (startHighlight < functionDefinition.Length) And commas > 0
            If calltipParametersSeparators.Contains(functionDefinition(startHighlight)) Then
                commas -= 1
            End If
            ' If it reached the end of the argument list it means that the user typed in more
            ' arguments than the ones listed in the calltip
            If calltipParametersEnd.Contains(functionDefinition(startHighlight)) Then
                commas = 0
            Else
                startHighlight += 1
            End If
        End While
        If calltipParametersSeparators.Contains(functionDefinition(startHighlight)) Then
            startHighlight += 1
        End If
        Dim endHighlight As Integer = startHighlight
        While Not calltipParametersSeparators.Contains(functionDefinition(endHighlight)) AndAlso Not _
            calltipParametersEnd.Contains(functionDefinition(endHighlight))

            endHighlight += 1
        End While

        Scintilla1.CallTip.HighlightStart = startHighlight
        Scintilla1.CallTip.HighlightEnd = endHighlight
    End Sub

    ''' <summary>
    ''' Checks if a value is contained within the given list(of MyCustomListViewItem)
    ''' </summary>
    ''' <param name="Name">The name of the item to find</param>
    ''' <param name="List">The list to check</param>
    ''' <returns>True if the item found, else False</returns>
    ''' <remarks></remarks>
    Private Function ListViewItemListContains(ByVal Name As String, ByVal List As List(Of MyCustomListViewItem)) As Boolean
        For Each MyInclude As MyCustomListViewItem In List
            If MyInclude.Name = Name Then
                Return True
            End If
        Next
        Return False
    End Function

    ''' <summary>
    ''' Returns a MyCustomListViewItem by name from a list(of MyCustomListViewItem)
    ''' </summary>
    ''' <param name="Name">The name of the item to find</param>
    ''' <param name="List">The list to check</param>
    ''' <returns>The MyCustomListViewItem item, or Nothing</returns>
    ''' <remarks></remarks>
    Private Function ListViewItemListItem(ByVal Name As String, ByVal List As List(Of MyCustomListViewItem)) As MyCustomListViewItem
        For Each MyInclude As MyCustomListViewItem In List
            If MyInclude.Name = Name Then
                Return MyInclude
            End If
        Next
        Return Nothing
    End Function

#End Region

    Private Sub mnuSnippetsInsertSnippet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSnippetsInsertSnippet.Click
        Scintilla1.Snippets.ShowSnippetList()
    End Sub

    Private Sub mnuSnippetSurroundWith_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSnippetSurroundWith.Click
        Scintilla1.Snippets.ShowSurroundWithList()
    End Sub

    Private Sub Scintilla1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Scintilla1.MouseClick
        Debug.WriteLine("MouseClick")
        If e.Button = Windows.Forms.MouseButtons.Right Then
            'Check if right click is in a selection
            If (Scintilla1.Selection.Range.Start < Scintilla1.PositionFromPoint(e.X, e.Y)) And (Scintilla1.Selection.Range.End > Scintilla1.PositionFromPoint(e.X, e.Y)) Then
                ContextMenuStrip1.Show(Scintilla1.PointToScreen(New Drawing.Point(e.X, e.Y)))
            Else
                'Move caret
                Scintilla1.Caret.Goto(Scintilla1.PositionFromPoint(e.X, e.Y))
                ContextMenuStrip1.Show(Scintilla1.PointToScreen(New Drawing.Point(e.X, e.Y)))
            End If
        End If
    End Sub

End Class