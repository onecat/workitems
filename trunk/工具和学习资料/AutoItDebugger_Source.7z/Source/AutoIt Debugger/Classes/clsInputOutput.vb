Imports System
Imports IO = System.IO
Imports System.Text
Imports System.Runtime.InteropServices

Namespace InputOutput

    ' <summary>
    ' Methods for manipulating project paths, including both directories
    ' and files. Some synonyms for System.Path methods are included as well.
    ' </summary>
    Public Class Path

        <DllImport("shlwapi.dll")> _
        Private Shared Function PathRelativePathTo(ByVal result As StringBuilder, _
          ByVal from As String, ByVal attrFrom As System.UInt32, ByVal [to] As String, _
          ByVal attrTo As System.UInt32) As Boolean

        End Function 'PathRelativePathTo'


        <DllImport("shlwapi.dll")> _
        Private Shared Function PathCanonicalize(ByVal result As StringBuilder, _
          ByVal path As String) As Boolean

        End Function 'PathCanonicalize'


        <DllImport("shlwapi.dll")> _
        Private Shared Function PathCommonPrefix(ByVal file1 As String, _
          ByVal file2 As String, ByVal result As StringBuilder) As Integer

        End Function 'PathCommonPrefix'


        Private Const FILE_ATTRIBUTE_DIRECTORY As Integer = 16
        Private Const FILE_ATTRIBUTE_NORMAL As Integer = 128
        Private Const MAX_PATH As Integer = 256


        ' <summary>
        ' Returns the relative path from a base directory to another
        ' directory or file.
        ' </summary>
        Public Function RelativePath(ByVal from As String, ByVal [to] As String) As String

            from = Canonicalize(from)
            [to] = Canonicalize([to])

            ' Second argument to PathRelativeTo must be absolute.
            If Not IO.Path.IsPathRooted([to]) Then
                Return [to]
            End If

            Dim sb As StringBuilder = New StringBuilder(MAX_PATH)

            ' Return null if call fails.
            If Not PathRelativePathTo(sb, from, Convert.ToUInt32(FILE_ATTRIBUTE_DIRECTORY), _
              [to], Convert.ToUInt32(FILE_ATTRIBUTE_DIRECTORY)) Then
                Return Nothing
            End If

            ' Remove initial .\ from path if present.
            If sb.Length >= 2 AndAlso sb(0) = "."c AndAlso sb(1) = "\"c Then
                sb.Remove(0, 2)
            End If

            If sb.Length = 0 Then
                Return Nothing
            End If

            Return sb.ToString

        End Function 'RelativePath'


        ' <summary>
        ' Return the canonical form of a path.
        ' </summary>
        Private Function Canonicalize(ByVal path As String) As String

            Dim sb As StringBuilder = New StringBuilder(MAX_PATH)

            If Not PathCanonicalize(sb, path) Then
                Throw New ArgumentException(String.Format("Invalid path passed to PathCanonicalize: {0}", path))
            End If

            Return sb.ToString

        End Function 'Canonicalize'


        ' <summary>
        ' True if the two paths are the same. However, two paths
        ' to the same file or directory using different network
        ' shares or drive letters are not treated as equal.
        ' </summary>
        Public Function SamePath(ByVal path1 As String, ByVal path2 As String) As Boolean

            Return Canonicalize(path1).ToLower = Canonicalize(path2).ToLower

        End Function 'SamePath'


        ' <summary>
        ' True if the two paths are the same or if the second is
        ' directly or indirectly under the first. Note that paths
        ' using different network shares or drive letters are
        ' considered unrelated, even if they end up referencing
        ' the same subtrees in the file system.
        ' </summary>
        Public Function SamePathOrUnder(ByVal path1 As String, ByVal path2 As String) As Boolean

            path1 = Canonicalize(path1)
            path2 = Canonicalize(path2)

            Dim length1 As Integer = path1.Length
            Dim length2 As Integer = path2.Length

            ' If path1 is longer, then path2 can't be under it.
            If length1 > length2 Then
                Return False
            End If

            ' If lengths are the same, check for equality.
            If length1 = length2 Then
                Return path1.ToLower = path2.ToLower
            End If

            ' Path 2 is longer than path 1: see if initial parts match.
            If path1.ToLower <> path2.Substring(0, length1).ToLower Then
                Return False
            End If

            ' Must match through or up to a directory separator boundary.
            Return path2.Chars(length1 - 1) = IO.Path.DirectorySeparatorChar OrElse _
                   path2.Chars(length1) = IO.Path.DirectorySeparatorChar

        End Function 'SamePathOrUnder'

    End Class

End Namespace