Public Class clsVariable

    Public Name As String
    Public Value As Object
    Public ValueChanged As Boolean
    Public NewVariable As Boolean
    Public Show As Boolean
    Public ArrayVariables As New List(Of clsArrayVariable)

    Public Sub New()
        ValueChanged = False
        NewVariable = True
        Value = "Not declared"
    End Sub

    Public Sub New(ByVal VariableName As String, ByVal ShowInListview As Boolean)
        ValueChanged = False
        NewVariable = True
        Value = "Not declared"
        Name = VariableName
        Show = ShowInListview
    End Sub

    ''' <summary>
    ''' Returns if the variable represents an array
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property IsArrayVariable() As Boolean
        Get
            If ArrayVariables.Count = 0 Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

End Class

''' <summary>
''' 
''' </summary>
''' <remarks></remarks>
Public Class clsArrayVariable

    Public Name As String
    Public Value As Object
    Public ValueChanged As Boolean
    Public NewVariable As Boolean

    Public Sub New()
        ValueChanged = False
        NewVariable = True
        Value = "Not declared"
    End Sub

    Public Sub New(ByVal VariableName As String)
        ValueChanged = False
        NewVariable = True
        Value = "Not declared"
        Name = VariableName
    End Sub

End Class

