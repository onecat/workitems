
Public Class clsChildFormCollection
    Implements ICollection

    Event ChildFormClosed()
    Event LastChildFormClosed()
    Event ChildFormHasChanged()

    Dim sl As SortedList
    Dim iIndex As Integer

    Sub New()
        sl = New SortedList
    End Sub

    Public Sub Add(ByVal theChildForm As frmChildForm)
        If theChildForm.Name = "" Or theChildForm.Name = "frmDocument" Then
            AddUnique(theChildForm)
        Else
            sl.Add(theChildForm.Name, theChildForm)
            AddHandler theChildForm.FormChangedEvent, AddressOf FormChanged
        End If
    End Sub

    Private Sub FormChanged()
        'MsgBox("Form changed")
        'Do something
        RaiseEvent ChildFormHasChanged()
    End Sub

    Public Sub AddUnique(ByVal theChildForm As frmChildForm)
        iIndex = iIndex + 1
        theChildForm.Name = theChildForm.Name & Format(iIndex, "0000")
        sl.Add(theChildForm.Name, theChildForm)
        AddHandler theChildForm.FormChangedEvent, AddressOf FormChanged
    End Sub

    Public Function Contains(ByVal sName As String) As Boolean

        Return sl.Contains(sName)
    End Function

    Public Function ContainsKey(ByVal sName As String) As Boolean

        Return sl.ContainsKey(sName)
    End Function

    Public Sub CopyTo(ByVal array As System.Array, ByVal index As Integer) _
                                Implements System.Collections.ICollection.CopyTo
        '        ======
        '
        Dim al() As frmChildForm
        If sl.Count >= index Then
            ReDim al(sl.Count - index)
            Dim de As DictionaryEntry
            Dim nCount As Integer = 0
            Dim nArrIndex As Integer = 0
            For Each de In sl
                If nCount >= index Then
                    al(nArrIndex) = CType(de.Value, frmChildForm)
                    nArrIndex += 1
                End If
                nCount += 1
            Next
        End If
        System.Array.Copy(al, array, sl.Count)
    End Sub

    Public ReadOnly Property Count() As Integer _
                                  Implements System.Collections.ICollection.Count
        '                      =====
        Get
            Return sl.Count
        End Get
    End Property

    Public ReadOnly Property GetByIndex(ByVal nIndex As Integer) As frmChildForm
        Get
            If nIndex < sl.Count Then
                Return CType(sl.GetByIndex(nIndex), frmChildForm)
            Else
                Return Nothing
            End If
        End Get
    End Property

    Public ReadOnly Property IsSynchronized() As Boolean _
                            Implements System.Collections.ICollection.IsSynchronized
        '                      ==============
        Get
            Return False
        End Get
    End Property

    Default Public ReadOnly Property Item(ByVal sName As String) As frmChildForm
        '                              ====
        Get
            If sl.ContainsKey(sName) Then
                Return CType(sl.Item(sName), frmChildForm)
            Else
                Return Nothing
            End If
        End Get
    End Property

    Public Sub Remove(ByVal sName As String)
        sl.Remove(sName)

        'Raise event of this is the last child form
        If sl.Count = 0 Then
            RaiseEvent LastChildFormClosed()
        Else
            RaiseEvent ChildFormClosed()
        End If
    End Sub

    Public ReadOnly Property SyncRoot() As Object _
                                Implements System.Collections.ICollection.SyncRoot
        Get
            Return Me
        End Get
    End Property

    Public Function GetEnumerator() As System.Collections.IEnumerator _
                             Implements System.Collections.IEnumerable.GetEnumerator
        ' Dimension the array to hold the collection
        If sl.Count > 0 Then
            Dim al(sl.Count - 1) As frmChildForm
            Dim de As DictionaryEntry
            Dim nCount As Integer = 0
            For Each de In sl
                al(nCount) = CType(de.Value, frmChildForm)
                nCount += 1
            Next
            Return New Enumerator(al)
        Else
            Dim al() As frmChildForm
            Return New Enumerator(al)
        End If
    End Function

    Class Enumerator
        '   ==========
        ' An object that implements the IEnumerator interface is used to control a 
        ' "For Each .. in ..." loop.
        ' This object is returned by the GetEnumerator() sub of the enclosing class.
        Implements IEnumerator
        Dim theArray() As frmChildForm
        Dim nCursor As Integer
        '=============================================================================
        Sub New(ByVal anArray() As frmChildForm)
            ' ===
            theArray = anArray
            nCursor = -1
        End Sub

        Public ReadOnly Property Current() As Object _
                                    Implements System.Collections.IEnumerator.Current
            '                      =======
            Get
                If ((nCursor < 0) Or (nCursor = theArray.Length)) Then
                    Throw New InvalidOperationException
                Else
                    Return theArray(nCursor)
                End If
            End Get
        End Property

        Public Function MoveNext() As Boolean _
                                    Implements System.Collections.IEnumerator.MoveNext
            '             ========
            If theArray Is Nothing Then Return False
            If nCursor < theArray.Length Then
                nCursor = nCursor + 1
            End If
            If (nCursor = theArray.Length) Then
                Return False
            Else
                Return True
            End If
        End Function

        Public Sub Reset() Implements System.Collections.IEnumerator.Reset
            '        =====
            nCursor = -1
        End Sub

    End Class

End Class

