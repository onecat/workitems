
Public Class MyCustomListViewItem
    Inherits Windows.Forms.ListViewItem
    Implements IComparable

    Friend Lines As New List(Of Integer)
    Friend iNextIndex As Integer = 0

    Friend Function NextLine() As Integer
        NextLine = Lines(iNextIndex)

        iNextIndex = iNextIndex + 1
        If iNextIndex > Lines.Count - 1 Then
            iNextIndex = 0
        End If
    End Function

    Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
        Dim c As MyCustomListViewItem = CType(obj, MyCustomListViewItem)
        Return String.Compare(Me.Text, c.Text)
    End Function

End Class

