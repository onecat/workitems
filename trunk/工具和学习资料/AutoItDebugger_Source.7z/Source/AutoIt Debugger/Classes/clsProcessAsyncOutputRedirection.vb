' Define the namespaces used by this sample.
Imports System
Imports System.Text
Imports System.IO
Imports System.Diagnostics
Imports System.Threading
Imports System.ComponentModel
Imports Microsoft.VisualBasic

Namespace ProcessAsyncStreamSamples

    Class ProcessAsyncOutputRedirection
        ' Define static variables shared by class methods.
        Friend sortOutput As StringBuilder = Nothing
        Friend sortProcess As New Process()

        Public Sub RunProcess()
            'Check if file exists
            If Not File.Exists(sortProcess.StartInfo.FileName) Then
                MsgBox("File '" & sortProcess.StartInfo.FileName & "' does not exist.", MsgBoxStyle.Exclamation)
            Else
                ' Set UseShellExecute to false for redirection.
                sortProcess.StartInfo.UseShellExecute = False
                ' Redirect the standard output of the sort command.  
                ' Read the stream asynchronously using an event handler.
                sortProcess.StartInfo.RedirectStandardOutput = True
                sortOutput = New StringBuilder()

                ' Set our event handler to asynchronously read the sort output.
                AddHandler sortProcess.OutputDataReceived, AddressOf SortOutputHandler

                ' Redirect standard input as well.  This stream is used synchronously.
                sortProcess.StartInfo.RedirectStandardInput = True
                sortProcess.Start()
                ' Start the asynchronous read of the sort output stream.
                sortProcess.BeginOutputReadLine()
                ' Wait for the sort process to write the sorted text lines.
                sortProcess.WaitForExit()

                sortProcess.Close()
            End If

        End Sub

        Private Sub SortOutputHandler(ByVal sendingProcess As Object, _
            ByVal outLine As DataReceivedEventArgs)

            ' Collect the sort command output.
            If Not String.IsNullOrEmpty(outLine.Data) Then
                ' Add the text to the collected output.
                sortOutput.Append(Environment.NewLine + outLine.Data)
            End If
        End Sub
    End Class
End Namespace
