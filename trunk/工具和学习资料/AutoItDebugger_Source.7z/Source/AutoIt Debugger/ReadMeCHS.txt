﻿文件说明：
AutoIt Debugger.exe——主程序，xp用户需要安装.net 2.0,win7和vista用户应该可以直接运行
Create Debug Script.ini——配置文件（重要），需要配置好AutoIt3安装的路径

另外，原来的程序需要有Aotoit3Wrapper.exe，现在已经修改成了ACNWrapper.exe（汉化版的autoit3wrapper
的路径）——这是硬编码在程序里，没有写在配置文件中

另外，程序中还需要用到CodeWizard，CodeWizard应该放置到autoit3\Scite目录下，
路径为如下方式：autoit3\Scite\CodeWizard\CodeWizard.exe


Create Debug Script.ini配置项说明：
AutoItReleaseExecutable=..\AutoIt3\AutoIt3.exe
——表示在bin目录的上层目录，也就是autoit3和bin目录是同级别的,
也可以是写自己安装autoit的目录：
比如安装在：D:\Program Files\autoit3chs，那么这个选项应该设置为：
AutoItReleaseExecutable=D:\Program Files\autoit3chs\AutoIt3.exe
其他配置选项类似

另，程序默认以操作系统默认编码读取源文件，同时支持检测一下编码的文件：UTF-8(BOM)、unicode编码；其中UTF-8(无BOM)不能检测