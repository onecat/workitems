Module mdlMessaging

    <System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)> _
    Public Structure COPYDATASTRUCT
        Public tyData As Integer
        Public lnData As Integer
        Public lpData As Integer
    End Structure

    <System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)> _
    Public Structure COPYDATASTRINGSTRUCT
        Public sData() As Char
        Public iData As Integer
    End Structure

    Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal Hwnd As IntPtr, _
        ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer

    <Runtime.InteropServices.DllImport("user32.dll", SetLastError:=True, CharSet:=Runtime.InteropServices.CharSet.Auto)> _
    Private Function FindWindow( _
         ByVal lpClassName As String, _
         ByVal lpWindowName As String) As IntPtr
    End Function

    Private Declare Function FindWindowEx Lib "user32" (ByVal hWnd1 As IntPtr, ByVal hWnd2 As IntPtr, ByVal lpsz1 As String, ByVal lpsz2 As String) As IntPtr

    Private Declare Auto Function SendMessage Lib "user32" ( _
     ByVal hwnd As IntPtr, _
     ByVal wMsg As Integer, _
     ByVal wParam As Integer, _
     ByRef lParam As COPYDATASTRUCT _
     ) As Integer

    Public Function SendMsg_Variable(ByVal WindowName As String, ByVal VariableName As String, _
        ByVal VariableValue As String) As Boolean
        SendMsg_Variable = True
        Const WM_COPYDATA = &H4A

        Dim hwnd As IntPtr = FindWindow(Nothing, WindowName)
        If hwnd.Equals(IntPtr.Zero) Then
            'MsgBox("Not found!")
            SendMsg_Variable = False
        Else
            'MsgBox("Found!")
            'Dim hwnd2 As IntPtr = FindWindowEx(hwnd, IntPtr.Zero, "WindowsForms10.Window.8.app3", Nothing)
            '    Dim lnglParam As String = (Location.Y * &H10000) + Location.X
            '    SendMessage(hwnd2, WM_LBUTTONDOWN, 1&, lnglParam)
            '    SendMessage(hwnd2, WM_LBUTTONUP, 1&, lnglParam)
            '    MsgBox("I clicked")

            Dim Message As String = VariableName & " " & VariableValue
            Dim dataSize As Integer = Message.Length

            Dim data(dataSize) As Byte

            data = StrToByteArray(Message)

            Dim ptrData As IntPtr = System.Runtime.InteropServices.Marshal.AllocCoTaskMem(dataSize)
            System.Runtime.InteropServices.Marshal.Copy(data, 0, ptrData, dataSize)

            Dim cds As COPYDATASTRUCT = New COPYDATASTRUCT()
            cds.tyData = 0
            cds.lnData = dataSize
            cds.lpData = ptrData
            Dim res As Integer = SendMessage(hwnd, WM_COPYDATA, 1&, cds)
        End If

    End Function

    Public Function SendMsg_UnPause(ByVal WindowName As String) As Boolean
        SendMsg_UnPause = True
        Const WM_COPYDATA = &H4A

        Dim hwnd As IntPtr = FindWindow(Nothing, WindowName)
        If hwnd.Equals(IntPtr.Zero) Then
            'MsgBox("Not found!")
            SendMsg_UnPause = False
        Else
            Dim cds As COPYDATASTRUCT = New COPYDATASTRUCT()
            cds.tyData = 1
            cds.lnData = 0
            cds.lpData = 0
            Dim res As Integer = SendMessage(hwnd, WM_COPYDATA, 1&, cds)
        End If

    End Function

    Public Function SendMsg_Quit(ByVal WindowName As String) As Boolean
        SendMsg_Quit = True
        Const WM_COPYDATA = &H4A

        Dim hwnd As IntPtr = FindWindow(Nothing, WindowName)
        If hwnd.Equals(IntPtr.Zero) Then
            SendMsg_Quit = False
            'MsgBox("Not found!")
        Else
            Dim cds As COPYDATASTRUCT = New COPYDATASTRUCT()
            cds.tyData = 2
            cds.lnData = 0
            cds.lpData = 0
            Dim res As Integer = SendMessage(hwnd, WM_COPYDATA, 1&, cds)
        End If

    End Function

    ' VB.NET to convert a string to a byte array
    Public Function StrToByteArray(ByVal str As String) As Byte()
        'Dim encoding As New System.Text.ASCIIEncoding()
        Dim encoding As System.Text.Encoding
        encoding = System.Text.Encoding.Default
        Return encoding.GetBytes(str)
    End Function 'StrToByteArray

End Module
