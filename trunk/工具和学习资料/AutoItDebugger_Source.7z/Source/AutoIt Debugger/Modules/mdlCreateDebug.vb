Imports System.IO
Imports System.Text

Module mdlCreateDebug

    Dim FilesToProcess As New List(Of String)
    Dim aVariableList As New List(Of String)
    Dim bOnAutoItExitFunctionUsed As Boolean
    Dim fmain As frmMain

    Sub CreateDebugFile(ByVal Filepath As String, ByRef NewfMain As frmMain)
        Dim szInitialScriptDrive As String = ""
        Dim szInitialScriptDir As String = ""
        Dim szInitialScriptFName As String = ""
        Dim szInitialScriptExt As String = ""

        fmain = NewfMain
        FilesToProcess.Clear()
        aVariableList.Clear()

        fmain.fOutput.Show()
        fmain.fOutput.ClearText()

        'Get filename
        Dim OriginalScriptFilePath As String = Filepath

        FileTools.PathSplit(OriginalScriptFilePath, szInitialScriptDrive, szInitialScriptDir, szInitialScriptFName, szInitialScriptExt)
        FilesToProcess.Add(OriginalScriptFilePath)

        ' Create the debug file in the debug folder under the original
        Dim sInitialScriptDebugFile As String
        'Create the debug folder if it does not exist
        If Not IO.File.Exists(szInitialScriptDrive & szInitialScriptDir & "\Debug") Then
            IO.Directory.CreateDirectory(szInitialScriptDrive & szInitialScriptDir & "\Debug")
        End If
        'Set attrib
        Dim x As IO.DirectoryInfo = New IO.DirectoryInfo(szInitialScriptDrive & szInitialScriptDir & "\Debug")
        x.Attributes = IO.FileAttributes.Hidden

        sInitialScriptDebugFile = FileTools.PathMake(szInitialScriptDrive, szInitialScriptDir & "Debug", szInitialScriptFName & ".Debug Script", ".au3")

        ' Check that the inital debug file had changed
        Dim sSessionINIFile = FileTools.PathMake(szInitialScriptDrive, szInitialScriptDir & "Debug", szInitialScriptFName, ".ini")
        'MsgBox(0,"",sSessionINIFile)
        Dim bInitialFileChanged As Boolean = False
        If CheckIfFilehasChanged(OriginalScriptFilePath, sSessionINIFile) Or Not IO.File.Exists(sInitialScriptDebugFile) Then
            bInitialFileChanged = True
        Else
            fmain.fOutput.WriteLine(OriginalScriptFilePath & " has not changed")
        End If

        Dim iCurrentFileIndex As Integer = 0
        Dim bIsFirstFile As Boolean = True
        bOnAutoItExitFunctionUsed = False
        While 1
            'Convert the inital script
            ProcessFile(FilesToProcess(iCurrentFileIndex), bIsFirstFile)

            If iCurrentFileIndex >= FilesToProcess.Count - 1 Then
                Exit While
            Else
                iCurrentFileIndex = iCurrentFileIndex + 1
                bIsFirstFile = False
            End If
        End While

        ' Check that the inital debug file had changed
        If bInitialFileChanged Then
            'Write the final line to the initial debug file
            'Dim file = FileOpen(sInitialScriptDebugFile, 1)
            Using sw As IO.StreamWriter = New IO.StreamWriter(sInitialScriptDebugFile, True)
                'Write out the last lines to the first script file
                sw.WriteLine("")
                sw.WriteLine("Func AutoIt_Debugger_OnAutoItExit()")
                'sw.WriteLine("msgbox(0,'','1')")
                If bOnAutoItExitFunctionUsed Then
                    'Call the real OnAutoItExit function
                    sw.WriteLine("	TempOnAutoItExit()")
                End If
                'sw.WriteLine("msgbox(0,'','2')")
                sw.WriteLine("	AutoIt_Debugger_WaitForExit()")
                sw.WriteLine("EndFunc")
                sw.WriteLine("")
                sw.WriteLine("Func CheckForVariableChange($VariableName, $AutoItDebugger_ArrayIndexString,  $VariableValue)")
                For iVariableChangeIndex As Integer = 0 To aVariableList.Count - 1
                    'Write the variable logic out
                    sw.WriteLine("	If $VariableName = " & Chr(34) & aVariableList(iVariableChangeIndex) & Chr(34) & " Then")
                    sw.WriteLine("		AutoIt_Debugger_GetVariableFromEvent(" & Chr(34) & aVariableList(iVariableChangeIndex) _
                        & Chr(34) & ", " & aVariableList(iVariableChangeIndex) & ", $AutoItDebugger_ArrayIndexString,  $VariableValue)")
                    sw.WriteLine("	EndIf")
                Next
                sw.WriteLine("EndFunc")

                'Write the complete Debugger Command Code (the old AutoIt Debugger Include file)
                ' Create an instance of StreamReader to read from a file.
                Using sr As IO.StreamReader = New IO.StreamReader(IO.Path.Combine(System.Windows.Forms.Application.StartupPath, "_AutoIt Debugger Include.au3"))
                    Dim line As String
                    ' Read and display the lines from the file until the end 
                    ' of the file is reached.
                    Do
                        line = sr.ReadLine()
                        'Console.WriteLine(line)
                        sw.WriteLine(line)
                    Loop Until line Is Nothing
                    sr.Close()
                End Using

                sw.Close()
            End Using
        End If

    End Sub

    Private Sub ProcessFile(ByVal TempOriginalScriptFilepath As String, ByVal bIsFirstFile As Boolean)
        Dim bFileHasChanged As Boolean
        fmain.fOutput.WriteLine("Creating debug file for: " & TempOriginalScriptFilepath)

        Dim sOriginalDrive As String = ""
        Dim sOriginalDir As String = ""
        Dim sOriginalName As String = ""
        Dim szExt As String = ""
        FileTools.PathSplit(TempOriginalScriptFilepath, sOriginalDrive, sOriginalDir, sOriginalName, szExt)
        Dim TempOriginalScriptFileName = FileTools.PathMake("", "", sOriginalName, szExt)
        Dim TempOriginalScriptFileFolder = sOriginalDrive & sOriginalDir.TrimEnd("\")

        'Create the debug folder if it does not exist
        If Not IO.File.Exists(sOriginalDrive & sOriginalDir & "\Debug") Then
            IO.Directory.CreateDirectory(sOriginalDrive & sOriginalDir & "Debug")
        End If
        'Set attrib
        Dim x As IO.DirectoryInfo = New IO.DirectoryInfo(sOriginalDrive & sOriginalDir & "\Debug")
        x.Attributes = IO.FileAttributes.Hidden
        Dim sTempScriptFilePath As String = FileTools.PathMake(sOriginalDrive, sOriginalDir & "Debug", sOriginalName & ".Debug Script", ".au3")

        ' Get the files stats
        Dim fl As IO.FileInfo = New IO.FileInfo(TempOriginalScriptFilepath)
        Dim iNewFileSize As String = fl.Length
        Dim sNewFileModTime As String = fl.LastWriteTime
        Dim eNewFileEncoding As Encoding = DetermineFileEncoding(TempOriginalScriptFilepath)

        fl = New IO.FileInfo(System.Windows.Forms.Application.ExecutablePath)
        Dim sCreateDebugScriptModTime As String = fl.LastWriteTime

        Dim sSessionINIFile As String = FileTools.PathMake(TempOriginalScriptFilepath, sOriginalDir & "Debug", sOriginalName, ".ini")
        If CheckIfFilehasChanged(TempOriginalScriptFilepath, sSessionINIFile) Or Not IO.File.Exists(sTempScriptFilePath) Then
            ' File has changed.
            bFileHasChanged = True
        Else
            ' File has not changed.
            bFileHasChanged = False
            fmain.fOutput.WriteLine(TempOriginalScriptFilepath & " has not changed")

            'Process for Include files only
            'to do - re-enable
            ProcessIncludesOnly(TempOriginalScriptFilepath)

            ' Jump out of function
            'to do - re-enable
            Exit Sub
        End If

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = sSessionINIFile
        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        ' Save the current file stats
        profile.SetValue(sOriginalName & "." & szExt, "FileSize", iNewFileSize)
        profile.SetValue(sOriginalName & "." & szExt, "FileModTime", sNewFileModTime)
        profile.SetValue(sOriginalName & "." & szExt, "CreateDebugScriptModTime", sCreateDebugScriptModTime)
        profile.SetValue(sOriginalName & "." & szExt, "FileWasDebug", fmain.bUseAutoItBeta)

        'Read script in to array
        Dim aScript As New List(Of String)
        FileTools.FileReadToArray(TempOriginalScriptFilepath, aScript)

        'Open a file for writing
        Dim sw As IO.StreamWriter = New IO.StreamWriter(sTempScriptFilePath, False, eNewFileEncoding)

        Dim iScriptFileIndex
        If bIsFirstFile Then
            'Call the debugger function to create the message window
            sw.WriteLine("#Include <winapi.au3>")
            sw.WriteLine("#Include <GUIConstants.au3>")
            sw.WriteLine("#Include <WindowsConstants.au3>")

            sw.WriteLine("Global $AutoItDebugger_Paused = 0")
            sw.WriteLine("Global $AutoItDebugger_Quit = 0")
            sw.WriteLine("Global $AutoItDebuggerCommandWindowName = " & Chr(34) & Chr(34))
            sw.WriteLine("Global $AutoItDebuggerCommandWindow")
            sw.WriteLine("Global $AutoItDebuggerCommandWindowListbox")

            sw.WriteLine("AutoItSetOption(""OnExitFunc"",""AutoIt_Debugger_OnAutoItExit"")")
            sw.WriteLine("AutoIt_Debugger_CreateMessageWindow()")

            sw.WriteLine("$TempOriginalFileBeingDebuggedFileName = " & Chr(34) & TempOriginalScriptFileName & Chr(34))
            sw.WriteLine("$TempOriginalFileBeingDebuggedFileFolder = " & Chr(34) & TempOriginalScriptFileFolder & Chr(34))
            sw.WriteLine("$TempOriginalFileBeingDebuggedFilePath = " & Chr(34) & TempOriginalScriptFilepath & Chr(34))
        End If
        sw.WriteLine("AutoIt_Debugger_LoadFile(" & Chr(34) & TempOriginalScriptFilepath & Chr(34) & ", " & Chr(34) & _
            TempOriginalScriptFileName & Chr(34) & ")")
        sw.WriteLine("AutoIt_Debugger_DebugFile(@ScriptFullPath)")

        Dim bIncludeFileIsFromIncludeLibrary As Boolean

        'Clear the skip block flag
        Dim bSkipBlock As Boolean = False
        Dim bUserSkipBlock As Boolean = False
        Dim bSkipAutoItExitBlock As Boolean = False
        Dim bSkipSelect As Boolean = False

        'Iterate through each line in the Original script file
        For iScriptFileIndex = 0 To aScript.Count - 1
            'Test if this is a blank or comment line
            Dim bSkipLine As Boolean = False

            'Get the current line
            Dim CurrentLine As String = aScript(iScriptFileIndex)

            'Check if this line is the 'OnAutoItExit' function
            If CurrentLine.Contains("OnAutoItExit()") Then
                Debug.Write("Found 'OnAutoItExit' function.")
                'Replace the OnAutoItExit with a temp function name
                CurrentLine = CurrentLine.Replace("OnAutoItExit()", "TempOnAutoItExit()")
                'CurrentLine = CurrentLine & vbNewLine & "AutoIt_Debugger_WaitForExit()"
                bOnAutoItExitFunctionUsed = True
                bSkipAutoItExitBlock = True
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*EndFunc") Then
                bSkipAutoItExitBlock = False 'End of AutoItExit function
                bSkipLine = True 'Skip this line as well
            End If

            If CurrentLine = "" Then
                bSkipLine = True 'Blank line
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*Select") Then
                bSkipSelect = True 'Select
            End If
            If bSkipSelect And RegExp.StringRegExpTest(CurrentLine, "^\s*Case") Then
                bSkipSelect = False
                bSkipLine = True 'Select
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*$") Then
                bSkipLine = True 'Blank line
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*;") Then
                bSkipLine = True ' Comment line
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*\#cs") Then
                bSkipBlock = True ' Start of comment block
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*\#ce") Then
                bSkipBlock = False ' End of comment block
                bSkipLine = True
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*;AutoIt_Debugger_Command:Disable_Debug") Then
                bUserSkipBlock = True
            End If
            If RegExp.StringRegExpTest(CurrentLine, "^\s*;AutoIt_Debugger_Command:Enable_Debug") Then
                bUserSkipBlock = False
                bSkipLine = True
            End If

            Dim IntermediateLine As String
            'Skip the blank lines
            If (Not bSkipLine) And (Not bSkipBlock) And (Not bUserSkipBlock) And (Not bSkipAutoItExitBlock) And Not (bSkipSelect) Then
                'Write the line number first
                sw.WriteLine("")
                sw.WriteLine("AutoIt_Debugger_NextLine(" & Chr(34) & TempOriginalScriptFilepath & Chr(34) & _
                    ", " & Chr(34) & TempOriginalScriptFileName & Chr(34) & ", " & iScriptFileIndex + 1 & ", False, @error, @extended)")

                ' Test if the line continues onto the next line (ends with '_', '_ ' or '_ ;')
                If RegExp.StringRegExpTest(CurrentLine, "(.*)\s_\s+$") Or RegExp.StringRegExpTest(CurrentLine, "(.*)\s_$") _
                    Or RegExp.StringRegExpTest(CurrentLine, "(.*)\s_\s+\;.*$") Then

                    IntermediateLine = ""
                    While RegExp.StringRegExpTest(CurrentLine, "(.*)\s_\s+$") Or RegExp.StringRegExpTest(CurrentLine, "(.*)\s_$") _
                        Or RegExp.StringRegExpTest(CurrentLine, "(.*)\s_\s+\;.*$")

                        Dim sTempReplace As String = RegExp.StringRegExpReplace(CurrentLine, "(\s_\s+\;.*$)", "", 0)
                        Dim sTempReplace2 As String = RegExp.StringRegExpReplace(sTempReplace, "(\s_\s+)", "", 0)
                        Dim sTempReplace3 As String = RegExp.StringRegExpReplace(sTempReplace2, "(\s_$)", "", 0)
                        ' Append the next line to the current line
                        IntermediateLine = IntermediateLine & " " & sTempReplace3
                        ' Increment the line counter
                        iScriptFileIndex = iScriptFileIndex + 1
                        ' Read in the next line of script
                        CurrentLine = aScript(iScriptFileIndex)
                    End While
                    ' The first non continuation line must be the end of the continuation line, so add it on
                    IntermediateLine = IntermediateLine & " " & CurrentLine
                    ' Store the value for return to the regular code
                    CurrentLine = IntermediateLine
                End If
            End If

            ' Update the outputline that will be written out
            Dim OutputLine As String = CurrentLine

            'Check if this is a file# Include
            If OutputLine.ToLower.Trim.StartsWith("#include") And Not _
              OutputLine.ToLower.Trim.StartsWith("#include-") Then

                'Test if the string is a "filename" string or a <filename> string
                Dim aIncludeRegEx As String = ""
                Dim IncludeFile As String = ""
                If StringTools.ReturnTextBetweenChar(OutputLine, Chr(34), Chr(34), False) <> "" Then
                    IncludeFile = StringTools.ReturnTextBetweenChar(OutputLine, Chr(34), Chr(34), False)
                ElseIf StringTools.ReturnTextBetweenChar(OutputLine, "<", ">", False) <> "" Then
                    IncludeFile = StringTools.ReturnTextBetweenChar(OutputLine, "<", ">", False)
                End If

                'Test the filepath to see if it is full, or a system include filepath
                Dim ValidatedIncludeFile As String = ""
                Dim sRelativeIncludeFilePath As String = Path.GetFullPath(Path.Combine(FileTools.PathMake(sOriginalDrive, sOriginalDir), IncludeFile))
                Dim sBetaIncludeFolderIncludeFilePath As String = fmain.sBetaIncludeFolder & "\" & IncludeFile
                Dim sReleaseIncludeFolderIncludeFilePath As String = fmain.sReleaseIncludeFolder & "\" & IncludeFile
                Dim sIncludeSubFolderIncludeFilePath As String = FileTools.PathMake(sOriginalDrive, sOriginalDir & "\Include\", IncludeFile, "")
                Dim sAbsoluteIncludeFilePath As String = IncludeFile

                If IO.File.Exists(sRelativeIncludeFilePath) And Not IO.Directory.Exists(sRelativeIncludeFilePath) Then
                    ValidatedIncludeFile = sRelativeIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = False

                ElseIf fmain.bUseAutoItBeta And IO.File.Exists(sBetaIncludeFolderIncludeFilePath) Then
                    'Test for file in Beta Include folder
                    ValidatedIncludeFile = sBetaIncludeFolderIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = True

                ElseIf (Not fmain.bUseAutoItBeta) And IO.File.Exists(sReleaseIncludeFolderIncludeFilePath) Then
                    'Test for file in Release Include folder
                    ValidatedIncludeFile = sReleaseIncludeFolderIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = True

                ElseIf IO.File.Exists(sIncludeSubFolderIncludeFilePath) And Not IO.Directory.Exists(sIncludeSubFolderIncludeFilePath) Then
                    ValidatedIncludeFile = sIncludeSubFolderIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = False

                ElseIf IO.File.Exists(sAbsoluteIncludeFilePath) And Not IO.Directory.Exists(sAbsoluteIncludeFilePath) Then
                    ValidatedIncludeFile = sAbsoluteIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = True
                Else
                    'File not found
                    bIncludeFileIsFromIncludeLibrary = False
                    MsgBox("Include file '" & IncludeFile & "' could not be located.", MsgBoxStyle.Exclamation, "AutoIt Debugger")
                End If

                'Make sure a valid include file was found
                If ValidatedIncludeFile <> "" Then
                    ' Proceed if the file was not from the include library, or if it was but user wanted it debugged.
                    If Not bIncludeFileIsFromIncludeLibrary Or (bIncludeFileIsFromIncludeLibrary And fmain.bDebugFilesInIncludeLibrary) Then
                        'Check if the file has been parsed alread
                        If Not FilesToProcess.Contains(ValidatedIncludeFile) Then
                            'If @error <> 6 Then '@error = 6 is 'item not found in array'
                            FilesToProcess.Add(ValidatedIncludeFile)
                        End If

                        'Write the new include line
                        Dim sIncludeFileDrive As String = ""
                        Dim sIncludeFileDir As String = ""
                        Dim sIncludeFileFName As String = ""
                        Dim sIncludeFileExt As String = ""
                        FileTools.PathSplit(ValidatedIncludeFile, sIncludeFileDrive, sIncludeFileDir, sIncludeFileFName, sIncludeFileExt)

                        'Set the include file to the original folder as the original, or in Windows temp directory
                        Dim sIncludeDebugFile
                        sIncludeDebugFile = FileTools.PathMake(sIncludeFileDrive, sIncludeFileDir & "Debug", sIncludeFileFName & ".Debug Script", ".au3")

                        OutputLine = "#Include " & Chr(34) & sIncludeDebugFile & Chr(34)
                    Else
                        'Write the existing include line
                        OutputLine = "#Include " & Chr(34) & ValidatedIncludeFile & Chr(34)
                    End If
                End If
            End If

            'Do any necessary replacements
            OutputLine = OutputLine.Replace("@ScriptName", "$TempOriginalFileBeingDebuggedFileName")
            OutputLine = OutputLine.Replace("@ScriptDir", "$TempOriginalFileBeingDebuggedFileFolder")
            OutputLine = OutputLine.Replace("@ScriptFullPath", "$TempOriginalFileBeingDebuggedFilePath")
            OutputLine = OutputLine.Replace("@AutoItExe", "$TempOriginalFileBeingDebuggedFilePath")

            'Write the line to the file
            sw.WriteLine(OutputLine)

            If (Not bSkipLine) And (Not bSkipBlock) And (Not bUserSkipBlock) And (Not bSkipAutoItExitBlock) And Not (bSkipSelect) Then
                'Write the line number first
                sw.WriteLine("AutoIt_Debugger_FinishedLine(" & Chr(34) & TempOriginalScriptFilepath & Chr(34) & ", " & _
                  Chr(34) & TempOriginalScriptFileName & Chr(34) & ", " & iScriptFileIndex + 1 & ", False, @error, @extended)")

                'Check for variables
                Dim bCommentLine = RegExp.StringRegExpTest(OutputLine, "^\s*;")
                If Not bCommentLine Then
                    Dim VariableArray As List(Of String) = GetVariableList(OutputLine)
                    If VariableArray.Count > 0 Then
                        'Match found. Return value is an array of all group values.
                        'If there are no groups in the pattern, the function returns "" (empty string).
                        'Write the variables to the file
                        For iVariablesIndex As Integer = 0 To VariableArray.Count - 1
                            'Add the variables to the variables list
                            If Not aVariableList.Contains(VariableArray(iVariablesIndex)) Then
                                aVariableList.Add(VariableArray(iVariablesIndex))
                            End If

                            'MsgBox(1,"AutoIt Debugger",VariableArray(0))
                            Select Case VariableArray(iVariablesIndex)
                                Case "$TempOriginalFileBeingDebuggedFileName"
                                    'Do nothing
                                Case "$TempOriginalFileBeingDebuggedFilePath"
                                    'Do nothing
                                Case Else
                                    sw.WriteLine("AutoIt_Debugger_SendVariable(" & Chr(34) & VariableArray(iVariablesIndex) & Chr(34) & ", " & VariableArray(iVariablesIndex) & ", @error, @extended)")
                            End Select
                        Next
                    End If
                End If

                'Check for ConsoleWrite command
                If OutputLine.Contains("ConsoleWrite") Then
                    Dim TempConsoleOutput As String
                    Dim RightMostCloseBracket As Integer

                    'Find right most close bracket
                    RightMostCloseBracket = OutputLine.LastIndexOf(")")
                    'Strip off anything after (and including) the right most bracket
                    TempConsoleOutput = OutputLine.Substring(0, RightMostCloseBracket)
                    'Append the error codes
                    TempConsoleOutput = TempConsoleOutput & ", @error, @extended)"

                    If OutputLine.Contains("ConsoleWriteError") Then
                        'Replace the ConsoleWrite command
                        TempConsoleOutput = TempConsoleOutput.Replace("ConsoleWriteError", "AutoIt_Debugger_SendConsoleWrite")
                    Else
                        'Replace the ConsoleWrite command
                        TempConsoleOutput = TempConsoleOutput.Replace("ConsoleWrite", "AutoIt_Debugger_SendConsoleWrite")
                    End If
                    sw.WriteLine(TempConsoleOutput)
                End If

                'Check for ConsoleWriteError command

            End If
        Next

        ' Close the file
        sw.Close()
    End Sub

    Sub ProcessIncludesOnly(ByVal TempOriginalScriptFilepath As String)
        fmain.fOutput.WriteLine("Checking for Include file changes in: " & TempOriginalScriptFilepath)

        Dim sOriginalDrive As String = ""
        Dim sOriginalDir As String = ""
        Dim sOriginalName As String = ""
        Dim szExt As String = ""
        FileTools.PathSplit(TempOriginalScriptFilepath, sOriginalDrive, sOriginalDir, sOriginalName, szExt)
        Dim TempOriginalScriptFileName As String = FileTools.PathMake("", "", sOriginalName, szExt)
        Dim TempOriginalScriptFileFolder As String = sOriginalDrive & "\" & sOriginalDir

        'Read script in to array
        Dim aScript As New List(Of String)
        FileTools.FileReadToArray(TempOriginalScriptFilepath, aScript)

        Dim iScriptFileIndex As Integer
        Dim bIncludeFileIsFromIncludeLibrary As Boolean

        'Iterate through each line in the Original script file
        For iScriptFileIndex = 0 To aScript.Count - 1

            'Get the line to write
            Dim CurrentLine As String = aScript(iScriptFileIndex)
            If IsNothing(CurrentLine) Then CurrentLine = ""

            ' Update the outputline that will be written out
            Dim OutputLine As String = CurrentLine

            'Check if this is a file# Include
            If OutputLine.Trim.StartsWith("#Include", StringComparison.CurrentCultureIgnoreCase) And Not _
              OutputLine.Trim.StartsWith("#Include-", StringComparison.CurrentCultureIgnoreCase) Then

                'Test if the string is a "filename" string or a <filename> string
                Dim sIncludeRegEx As String = ""
                Dim IncludeFile As String = ""
                If StringTools.ReturnTextBetweenChar(OutputLine, Chr(34), Chr(34), False) <> "" Then
                    IncludeFile = StringTools.ReturnTextBetweenChar(OutputLine, Chr(34), Chr(34), False)
                ElseIf StringTools.ReturnTextBetweenChar(OutputLine, "<", ">", False) <> "" Then
                    IncludeFile = StringTools.ReturnTextBetweenChar(OutputLine, "<", ">", False)
                End If

                'Test the filepath to see if it is full, or a system include filepath
                Dim ValidatedIncludeFile As String = ""
                Dim sRelativeIncludeFilePath As String = Path.GetFullPath(Path.Combine(FileTools.PathMake(sOriginalDrive, sOriginalDir), IncludeFile))
                Dim sBetaIncludeFolderIncludeFilePath As String = fmain.sBetaIncludeFolder & "\" & IncludeFile
                Dim sReleaseIncludeFolderIncludeFilePath As String = fmain.sReleaseIncludeFolder & "\" & IncludeFile
                Dim sIncludeSubFolderIncludeFilePath As String = FileTools.PathMake(sOriginalDrive, sOriginalDir & "\Include\", IncludeFile, "")
                Dim sAbsoluteIncludeFilePath As String = IncludeFile

                If IO.File.Exists(sRelativeIncludeFilePath) And Not IO.Directory.Exists(sRelativeIncludeFilePath) Then
                    ValidatedIncludeFile = sRelativeIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = False

                ElseIf fmain.bUseAutoItBeta And IO.File.Exists(sBetaIncludeFolderIncludeFilePath) Then
                    'Test for file in Beta Include folder
                    ValidatedIncludeFile = sBetaIncludeFolderIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = True

                ElseIf (Not fmain.bUseAutoItBeta) And IO.File.Exists(sReleaseIncludeFolderIncludeFilePath) Then
                    'Test for file in Release Include folder
                    ValidatedIncludeFile = sReleaseIncludeFolderIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = True

                ElseIf IO.File.Exists(sIncludeSubFolderIncludeFilePath) And Not IO.Directory.Exists(sIncludeSubFolderIncludeFilePath) Then
                    ValidatedIncludeFile = sIncludeSubFolderIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = False

                ElseIf IO.File.Exists(sAbsoluteIncludeFilePath) And Not IO.Directory.Exists(sAbsoluteIncludeFilePath) Then
                    ValidatedIncludeFile = sAbsoluteIncludeFilePath
                    bIncludeFileIsFromIncludeLibrary = True
                Else
                    'File not found
                    bIncludeFileIsFromIncludeLibrary = False
                    MsgBox("Include file '" & IncludeFile & "' could not be located.", MsgBoxStyle.Exclamation, "AutoIt Debugger")
                End If

                'Make sure a valid include file was found
                If ValidatedIncludeFile <> "" Then
                    ' Proceed if the file was not from the include library, or if it was but user wanted it debugged.
                    If (Not bIncludeFileIsFromIncludeLibrary) Or (bIncludeFileIsFromIncludeLibrary And fmain.bDebugFilesInIncludeLibrary) Then
                        'Check if the file has been parsed alread
                        If Not FilesToProcess.Contains(ValidatedIncludeFile) Then
                            'If @error <> 6 Then '@error = 6 is 'item not found in array'
                            FilesToProcess.Add(ValidatedIncludeFile)
                        End If
                    End If
                End If
            End If
        Next
    End Sub

    Private Function CheckIfFilehasChanged(ByVal TempOriginalScriptFilepath As String, ByVal FileDataINIFile As String) As Boolean
        ' Get the files stats
        Dim fl As IO.FileInfo = New IO.FileInfo(TempOriginalScriptFilepath)
        Dim iNewFileSize As String = fl.Length
        Dim sNewFileModTime As String = fl.LastWriteTime
        fl = New IO.FileInfo(System.Windows.Forms.Application.ExecutablePath)
        Dim sCreateDebugScriptModTime As String = fl.LastWriteTime

        Dim sOriginalDrive As String = ""
        Dim sOriginalDir As String = ""
        Dim sOriginalName As String = ""
        Dim szExt As String = ""
        FileTools.PathSplit(TempOriginalScriptFilepath, sOriginalDrive, sOriginalDir, sOriginalName, szExt)

        ' Find the folder of the AutoIt Debugger installation (not the GUI install folder)
        Dim configFile As String = FileDataINIFile
        'Load INI file settings
        Dim profile As AMS.Profile.Ini = New AMS.Profile.Ini(configFile)

        ' Save the current file stats
        Dim iPreviousFileSize As Integer
        Dim sPreviousFileModTime As String
        Dim sPreviousCreateDebugScriptModTime As String
        Dim bPreviousFileWasDebug As Boolean

        iPreviousFileSize = CInt(profile.GetValue(sOriginalName & "." & szExt, "FileSize", 0))
        sPreviousFileModTime = profile.GetValue(sOriginalName & "." & szExt, "FileModTime", "")
        sPreviousCreateDebugScriptModTime = profile.GetValue(sOriginalName & "." & szExt, "CreateDebugScriptModTime", "")
        bPreviousFileWasDebug = profile.GetValue(sOriginalName & "." & szExt, "FileWasDebug", False)

        ' Test against the new file stats. Create debug file if stats are different, or the file does not exist, or Beat vs Release
        If (iNewFileSize <> iPreviousFileSize) Or (sNewFileModTime <> sPreviousFileModTime) Or _
            (bPreviousFileWasDebug <> fmain.bUseAutoItBeta) Or (sCreateDebugScriptModTime <> sPreviousCreateDebugScriptModTime) Then

            ' File has changed.
            Return 1
        Else
            ' File has not changed.
            Return 0
        End If
    End Function

End Module
