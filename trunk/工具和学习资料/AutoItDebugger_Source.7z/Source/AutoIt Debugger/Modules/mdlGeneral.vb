Imports System.IO
Imports System.Text

Module mdlGeneral

    ''' <summary>
    ''' Generates a variable list from a string
    ''' </summary>
    ''' <param name="Line">The string to test for variables</param>
    ''' <returns>A list(of string) containing the variables</returns>
    ''' <remarks></remarks>
    Function GetVariableList(ByVal Line As String) As List(Of String)
        Dim VariableArray As New List(Of String)
        Dim InVariable As Boolean = False
        Dim InDoubleQuoteComment As Boolean = False
        Dim InSingleQuoteComment As Boolean = False
        Dim CurrentVariable As String = ""
        Dim CurrentChar As String
        Dim AfterSemiColon As Boolean = False

        'Check if the line contains a $
        If Line.Contains("$") Then
            'Step through each char
            For iIndex As Integer = 0 To Line.Length - 1
                CurrentChar = Line(iIndex)
                Select Case CurrentChar
                    Case "$"
                        'Already in variable
                        If InVariable Then
                            VariableArray.Add(CurrentVariable)

                            CurrentVariable = CurrentChar
                        Else
                            If Not InDoubleQuoteComment And Not InSingleQuoteComment And Not AfterSemiColon Then
                                InVariable = True
                                CurrentVariable = CurrentVariable & CurrentChar
                            End If
                        End If
                    Case Chr(34) ' "
                        If InVariable Then
                            VariableArray.Add(CurrentVariable)
                            CurrentVariable = ""
                            InVariable = False
                        End If
                        InDoubleQuoteComment = Not InDoubleQuoteComment
                    Case "'"
                        If InVariable Then
                            VariableArray.Add(CurrentVariable)
                            CurrentVariable = ""
                            InVariable = False
                        End If
                        InSingleQuoteComment = Not InSingleQuoteComment
                    Case ";"
                        If InVariable Then
                            VariableArray.Add(CurrentVariable)
                            CurrentVariable = ""
                            InVariable = False
                        End If
                        If Not InDoubleQuoteComment And Not InSingleQuoteComment Then
                            AfterSemiColon = Not AfterSemiColon
                        End If
                    Case "A" To "Z", "a" To "z", "0" To "9", "_"
                        If InVariable And Not InDoubleQuoteComment And Not InSingleQuoteComment And Not AfterSemiColon Then
                            CurrentVariable = CurrentVariable & CurrentChar
                        End If
                    Case Else
                        If InVariable Then
                            VariableArray.Add(CurrentVariable)
                            CurrentVariable = ""
                            InVariable = False
                        End If
                End Select
            Next

            'Finish final variable
            If InVariable Then
                VariableArray.Add(CurrentVariable)
            End If
        End If

        Return VariableArray
    End Function

    ''' <summary>
    ''' Determine the encoding of a text file.
    ''' </summary>
    ''' <param name="aFileName">The path of the file to be checked.</param>
    ''' <returns>The encoding of the file.</returns>
    ''' <remarks></remarks>
    Public Function DetermineFileEncoding(ByVal aFileName As String) As Encoding
        Dim sEncoding As Encoding
        'Dim sEncoding As Encoding = Encoding.ASCII

        'modify by ywq111: because it can't detect the Encode correctly before
        Dim oSR As New StreamReader(aFileName, System.Text.Encoding.Default, True)
        oSR.ReadToEnd()
        ' Add this line to read the file.
        sEncoding = oSR.CurrentEncoding

        oSR.Close()

        Return sEncoding
    End Function

End Module
