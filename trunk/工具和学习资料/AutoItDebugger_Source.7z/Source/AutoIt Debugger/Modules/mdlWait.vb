Imports System
Imports System.Environment
Imports System.Windows.Forms

Public Module mdlWait
    Public Sub Wait(ByVal milliSecWaitTime As Double)

        Dim d1 As DateTime = DateTime.Now
        Dim d2 As DateTime = d1.AddMilliseconds(milliSecWaitTime)

        While 1
            d1 = DateTime.Now
            If d1 > d2 Then
                Exit While
            End If
            Application.DoEvents()
        End While

    End Sub
End Module