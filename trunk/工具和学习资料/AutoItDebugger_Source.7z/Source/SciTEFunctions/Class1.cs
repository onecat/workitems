using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using ScintillaNet;


    public class SciTEBase
    {

        String calltipParametersStart =  "(";
	    String calltipParametersEnd = ")";

        //Scintilla MyScintillaNet();

/**
 * Upon a character being added, SciTE may decide to perform some action
 * such as displaying a completion list or auto-indentation.
 */
        void CharAdded(char ch, Scintilla MyScintillaNet)
        {
            //CharacterRange crange = GetSelection();
            int selStart = MyScintillaNet.Selection.Start;
	        int selEnd = MyScintillaNet.Selection.End;

	        if ((selEnd == selStart) && (selStart > 0)) {
                if (MyScintillaNet.CallTip.IsActive)
                {
			        if (calltipParametersEnd.Contains(ch)) {
				        braceCount--;
				        if (braceCount < 1)
					        SendEditor(SCI_CALLTIPCANCEL);
				        else
					        StartCallTip();
			        } else if (calltipParametersStart.Contains(ch)) {
				        braceCount++;
				        StartCallTip();
			        } else {
				        ContinueCallTip();
			        }
		        } else if (SendEditor(SCI_AUTOCACTIVE)) {
			        if (calltipParametersStart.contains(ch)) {
				        braceCount++;
				        StartCallTip();
			        } else if (calltipParametersEnd.contains(ch)) {
				        braceCount--;
			        } else if (!wordCharacters.contains(ch)) {
				        SendEditor(SCI_AUTOCCANCEL);
				        if (autoCompleteStartCharacters.contains(ch)) {
					        StartAutoComplete();
				        }
			        } else if (autoCCausedByOnlyOne) {
				        StartAutoCompleteWord(true);
			        }
		        } else {
			        if (calltipParametersStart.contains(ch)) {
				        braceCount = 1;
				        StartCallTip();
			        } else {
				        autoCCausedByOnlyOne = false;
				        if (indentMaintain)
					        MaintainIndentation(ch);
				        else if (props.GetInt("indent.automatic"))
					        AutomaticIndentation(ch);
				        if (autoCompleteStartCharacters.contains(ch)) {
					        StartAutoComplete();
				        } else if (props.GetInt("autocompleteword.automatic") && wordCharacters.contains(ch)) {
					        StartAutoCompleteWord(true);
					        autoCCausedByOnlyOne = SendEditor(SCI_AUTOCACTIVE);
				        }
			        }
		        }
	        }
        }

    }
