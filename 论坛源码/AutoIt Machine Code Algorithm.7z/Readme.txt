AutoIt Machine Code Algorithm Collection
----------------------------------------

This UDF collection contain a lot of machine code verstion of 
'time consumer' algorithm subroutines. They are compiled into
both x86 and x64 mode and can be direct called by AutoIt.

Most of the source code are download from internet. Although 
I modified most of them, but only in binary level. Since I didn't
modify the real source, so the source code it not provide ine the 
package. If someone is interested in the source code, try google 
them.

All of the subroutines have one or more examples to demonstrate
the usage. Since the function and usage of subroutine are easy 
to understand. A complete subroutines and parameters list are
unavailability now. Sorry for my lazy.

I already did my best to test all the UDFs, and I hope that they 
will be useful, but WITHOUT ANY WARRANTY. Please use at your own 
risk. Thanks.


    Ward, 2010/11, Taiwan